<?php
	session_start();
	require('connect.php');	
	require('session_load.php');
	require('page_load.php');
	$notice = "";
	$notice_update = "";
	if($member_admin != 1 && $member_super_admin != 1){
		header('Location: index.php');
	}
	//Check if account is enabled/disabled
	if($member_id != "" && $query_member['status'] == 0){
		header('Location: index.php?action=Logout&code=1');
	}
	
	//Update Check
	$query_key = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM site_settings WHERE id='1'"));
	$query_key = $query_key['software_key'];
	
	$url = "http://afr-cpr.com/update/version_new.xml";

	
	$xml = simplexml_load_file($url) or die("Error: Cannot create object");
	foreach($xml->update as $update){
		$new_version = $update->version;
		$file_url = $update->file_url;
	}
	if($new_version > $page_load_site_version){
		$notice_update = "<br><div class='warning'>A new software update is available</div>";
	}
	
	//Update Process
	if($_POST['submit_update']){
		$notice = "";
		if(file_put_contents('update.zip', file_get_contents($file_url))){
		
			$file = 'update.zip';

			$zip = new ZipArchive;
			$res = $zip->open($file);
			if ($res === TRUE) {
				// extract it to the path we determined above
				$zip->extractTo("./");
				$zip->close();
				$notice = "<div class='confirm'>Update to version ".$new_version." has been complete</div>";
				
				$page_load_site_version = $new_version;
				//database changes, if any
				if(file_exists("./update_sql.php")){
					require('update_sql.php');
					unlink("./update_sql.php");
				}
				unlink("./update.zip");
				mysqli_query($con,"UPDATE site_settings SET site_version='$new_version' WHERE id='1'");
				//Update Check
				$query_key = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM site_settings WHERE id='1'"));
				$query_key = $query_key['software_key'];

				$url = "http://afr-cpr.com/update/version_new.xml";


				$xml = simplexml_load_file($url) or die("Error: Cannot create object");
				foreach($xml->update as $update){
					$new_version = $update->version;
					$file_url = $update->file_url;
				}
				if($new_version > $page_load_site_version){
					$notice_update = "<br><div class='warning'>A new software update is available</div>";
				}
				
				$marker = time();
				$notification = "A software update for version <font color='blue'>".$new_version."</font> has been installed by <font color='blue'>".$member_handle."</font>.";
				$notification = mysqli_real_escape_string($con,$notification);
				mysqli_query($con,"INSERT INTO notifications_admin VALUES ('','$notification','8','$swc_date_time','$marker')");
			} else {
			  $notice = "<div class='error'>Update failed</div>";
			}
		}else{
			$notice = "<div class='error'>File download failed</div>";
		}
	}
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php require('head.php'); ?>
<?php require('main.css.php'); ?>
</head>

<body>
	<div id="container">
	<!-- Header Start-->
		<?php echo $page_load_header; ?>
		<!-- Header End and Menu Start-->  
		<div id="menu">
			<ul>
				<?php 
					echo $public_links;
					echo $member_links;
					echo $admin_link; 
				?> 
			</ul>
			<?php echo $searchbar; ?>
		<!-- Menu End and Content Start-->
		</div>
		<div id="content">
		<!-- Left content Start-->
			<div id="leftcontent">
			<!-- Navigation Start-->
				<div class="navigation">
					<div class="navhead">Member's Area</div>
					<?php echo $user_panel; ?>						
				</div>
				
				<!-- Dynamically Generated Panels-->
				<?php echo $page_load_side_panels; ?>
			</div>
			
			<!-- Left content ends and right content starts-->
			
			<div id="rightcontent">
				<div id="breadcrumbs"> <a href="admin.php">Admin</a> -> <a href="admin_update.php">Update</a></div>
				<!-- Post starts here-->
				<center><h1>Update</h1></center>
				<?php echo $notice; ?>
				<?php echo $notice_update; ?>
				<div class="postcontent">
					<center>
						<?php
						//Display new version information
						$url = "http://afr-cpr.com/update/version_new.xml";
						$xml = simplexml_load_file($url) or die("Error: Cannot create object");
						
						foreach($xml->update as $update){
							echo "<div style='width:300px;background-color:#555555;border:1px solid black;font-size:18px;padding:5px;'>Current Version: ".$page_load_site_version."</div><br>";
							echo "<div style='width:300px;background-color:#555555;border:1px solid black;font-size:18px;padding:5px;'>Latest Version: ".$new_version."</div><br>";
							if($new_version > $page_load_site_version){
								echo "<form action='admin_update.php' method='post'><input type='submit' name='submit_update' value='Update' style='width:100px;padding:5px;border-radius:5px;'></form>";
							}else{
								echo "The latest software version is already installed.<br>";
							}
							echo "<br>
							<table class='format_1'><tr><th width='500'><h2>New Changelog</h2></h2></tr>";
							foreach($xml->update->changelog->item as $changelog){
								echo "<tr><td style='color:white;'>- ".$changelog."</td></tr>";
							}
							echo "</table>";
						}
						
						echo "<br><br>";
						
						//Display old update logs
						echo "<h2>Old Versions/Changes</h2><textarea style='width:500px;height:250px;overflow:auto;'>";
						$url = "http://afr-cpr.com/update/version_old.xml";
						$xml = simplexml_load_file($url) or die("Error: Cannot create object");
						
						foreach($xml->update as $update){
							echo "****** Version: ".$update->version." ******";
							echo "\r\n";
							foreach($update->changelog->item as $changelog){
								echo "- ".$changelog."\r\n";
							}
							echo "\r\n\r\n";
						}
						echo "</textarea>";
						
						?>
					</center>
				</div>
			</div>
			<!-- Right content Ends here-->
		</div>
		
		<!-- Content Ends here and footer started-->
  
		<div class="footclear">&nbsp;</div>
		<?php echo $page_load_footer; ?>
		<!-- footer Ends here-->
	</div>
	<!-- Container Ends here-->
</body>

</html>

<?php mysqli_close($con); ?>
