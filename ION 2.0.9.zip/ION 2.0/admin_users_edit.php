<?php
	session_start();
	require('connect.php');	
	require('session_load.php');
	require('page_load.php');
	$notice = "";
	if($member_admin != 1 && $member_super_admin != 1){
		header('Location: index.php');
	}
	
	//Check if account is enabled/disabled
	if($member_id != "" && $query_member['status'] == 0){
		header('Location: index.php?action=Logout&code=1');
	}
	
	if(!$_GET['id']){
		header('Location: admin_users.php');
	}else{
		$edit_id = mysqli_real_escape_string($con,$_GET['id']);
		$edit_username = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM members WHERE id='$edit_id'"));
		$edit_username = $edit_username['handle'];
	}
	
	$query_super_admin = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM site_settings"));
	$query_super_admin = $query_super_admin['super_admin'];
	if($edit_id == $query_super_admin && $member_super_admin == 0){
		header('Location: admin_users.php?errCode=2');
	}
	
	if($_POST['edit_submit']){
		$edit_username = mysqli_real_escape_string($con,$_POST['edit_username']);
		$edit_email = mysqli_real_escape_string($con,$_POST['edit_email']);
		$edit_usergroup = mysqli_real_escape_string($con,$_POST['edit_usergroup']);
		$edit_pass = mysqli_real_escape_string($con,$_POST['edit_pass']);
		$edit_pass_confirm = mysqli_real_escape_string($con,$_POST['edit_pass_confirm']);
		if($edit_username != "" && $edit_email != ""){
			if (!filter_var($edit_email, FILTER_VALIDATE_EMAIL) === false) {
				if($edit_pass != "" && $edit_pass_confirm != ""){
					if($edit_pass === $edit_pass_confirm){
						$edit_password_hash = md5(md5("xjke5p".$edit_pass."jruc3e"));
						mysqli_query($con,"UPDATE members SET id_usergroup='$edit_usergroup', handle='$edit_username', email='$edit_email', password='$edit_password_hash' WHERE id='$edit_id'");
						$notice = "<div class='confirm'>The user account ".$edit_username." has been changed. Password set as \"".$edit_pass."\"</div>";
						
						$query_usergroup_name = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM members_usergroups WHERE id='$edit_usergroup'"));
						$usergroup_name = $query_usergroup_name['name'];
						$marker = time();
						$notification = "The user <font color='blue'>".$edit_username."</font> has been edited by <font color='blue'>".$member_handle."</font>.";
						if($edit_usergroup != 0 && $edit_usergroup != ""){
							$notification = "".$notification." User added to usergroup <font color='blue'>".$usergroup_name."</font>.";
						}
						$notification = mysqli_real_escape_string($con,$notification);
						mysqli_query($con,"INSERT INTO notifications_admin VALUES ('','$notification','0','$swc_date_time','$marker')");
					}else{
						$notice = "<div class='error'>The password and confirm password do not match each other.</div>";
					}
				}else{
					mysqli_query($con,"UPDATE members SET id_usergroup='$edit_usergroup', handle='$edit_username', email='$edit_email' WHERE id='$edit_id'");
					$notice = "<div class='confirm'>The user account ".$edit_username." has been changed.</div>";
					
					$query_usergroup_name = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM members_usergroups WHERE id='$edit_usergroup'"));
					$usergroup_name = $query_usergroup_name['name'];
					$marker = time();
					$notification = "The user <font color='blue'>".$edit_username."</font> has been edited by <font color='blue'>".$member_handle."</font>.";
					if($edit_usergroup != 0 && $edit_usergroup != ""){
						$notification = "".$notification." User added to usergroup <font color='blue'>".$usergroup_name."</font>.";
					}
					$notification = mysqli_real_escape_string($con,$notification);
					mysqli_query($con,"INSERT INTO notifications_admin VALUES ('','$notification','0','$swc_date_time','$marker')");
				}
			} else {
				$notice = "<div class='error'>Email format is invalid.</div>";
			}
		}else{
			$notice = "<div class='error'>Both the username and email are required to be filled out.</div>";
		}
	}
	
	$query_user = mysqli_query($con,"SELECT * FROM members WHERE id='$edit_id'");
	if(mysqli_num_rows($query_user) != 0){
		$query_user = mysqli_fetch_assoc($query_user);
	}else{
		$notice = "<div class='warning'>There is no user with that ID number.</div>";
	}
	
	if($_POST['delete_user']){
		$notice = "<div class='warning'>Are you sure you want to delete this user? <a href='admin_users_edit.php?id=".$edit_id."&delete=1'>[Yes]</a> - <a href='admin_users_edit.php?id=".$edit_id."'>[No]</a></div>";
	}else if($_GET['delete']){
		if($edit_id != $member_id){
			mysqli_query($con,"DELETE FROM members WHERE id='$edit_id'");
			$marker = time();
			$notification = "The user <font color='blue'>".$edit_username."</font> has been deleted by <font color='blue'>".$member_handle."</font>.";
			$notification = mysqli_real_escape_string($con,$notification);
			mysqli_query($con,"INSERT INTO notifications_admin VALUES ('','$notification','0','$swc_date_time','$marker')");
			header('Location: admin_users.php?errCode=1');
		}else{
			$notice = "<div class='error'>You cannot delete your own account.</div>";
		}
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php require('head.php'); ?>
<?php require('main.css.php'); ?>
</head>

<body>
	<div id="container">
	<!-- Header Start-->
		<?php echo $page_load_header; ?>
		<!-- Header End and Menu Start-->  
		<div id="menu">
			<ul>
				<?php 
					echo $public_links;
					echo $member_links;
					echo $admin_link; 
				?> 
			</ul>
			<?php echo $searchbar; ?>
		<!-- Menu End and Content Start-->
		</div>
		<div id="content">
		<!-- Left content Start-->
			<div id="leftcontent">
			<!-- Navigation Start-->
				<div class="navigation">
					<div class="navhead">Member's Area</div>
					<?php echo $user_panel; ?>						
				</div>
				
				<!-- Dynamically Generated Panels-->
				<?php echo $page_load_side_panels; ?>
			</div>
			
			<!-- Left content ends and right content starts-->
			
			<div id="rightcontent">
				<div id="breadcrumbs"> <a href="admin.php">Admin</a> -> <a href="admin_users.php">User Admin</a> -> <a href="">Edit User</a></div>
				<!-- Post starts here-->
				<center><h1>Edit User</h1></center>
				<?php echo $notice; ?>
				<div class="postcontent">
					<center>
					<form class="foorm" method="post" action="">
					<table>
						<tr>
							<td align="left">Username:</td>
							<td align="center"><input type="text" name="edit_username" value="<?php if($query_user['handle']){echo $query_user['handle'];} ?>"></td>
						</tr>
						<tr>
							<td align="left">Email:</td>
							<td align="center"><input type="text" name="edit_email" value="<?php if($query_user['email']){echo $query_user['email'];} ?>"></td>
						</tr>
						<tr>
							<td align="left">Usergroup:</td>
							<td align="center">
								<select style="width:175px;" name="edit_usergroup">
									<option value="0">(No Usergroup)</option>
									<?php
										$query_groups = mysqli_query($con,"SELECT * FROM members_usergroups ORDER BY name ASC");
										while($row = mysqli_fetch_assoc($query_groups)){
											if($row['id'] == $query_user['id_usergroup']){
												echo "<option value=".$row['id']." SELECTED>".$row['name']."</option>";
											}else{
												echo "<option value=".$row['id'].">".$row['name']."</option>";
											}
										}
									?>
								</select>
							</td>
						</tr>
						<tr>
							<td align="left">Set Password:</td>
							<td align="center"><input type="password" name="edit_pass" value=""></td>
						</tr>
						<tr>
							<td align="left">Confirm Password:</td>
							<td align="center"><input type="password" name="edit_pass_confirm" value=""></td>
						</tr>
						<tr>
							<td align="center" colspan="2"><input class="button" type="submit" name="edit_submit" value="Submit"></td>
						</tr>
					</table>
					</form>
					<br /><hr />
					<form class="foorm" method="post" action="">
					Delete User? <input class="button" type="submit" name="delete_user" value="Delete">
					</form>
					</center>
				</div>
			</div>
			<!-- Right content Ends here-->
		</div>
		
		<!-- Content Ends here and footer started-->
  
		<div class="footclear">&nbsp;</div>
		<?php echo $page_load_footer; ?>
		<!-- footer Ends here-->
	</div>
	<!-- Container Ends here-->
</body>

</html>

<?php mysqli_close($con); ?>
