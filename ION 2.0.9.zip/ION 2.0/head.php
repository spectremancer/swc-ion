<?php

echo '

<title>'.$page_load_site_title.'</title>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />

';

?>