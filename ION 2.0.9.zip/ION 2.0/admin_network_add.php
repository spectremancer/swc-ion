<?php
	session_start();
	require('connect.php');	
	require('session_load.php');
	require('page_load.php');
	$notice = "";
	if($member_admin != 1 && $member_super_admin != 1){
		header('Location: index.php');
	}
	//Check if account is enabled/disabled
	if($member_id != "" && $query_member['status'] == 0){
		header('Location: index.php?action=Logout&code=1');
	}
	
	if($_GET['delete']){
		$node_id = mysqli_real_escape_string($con,$_GET['delete']);
		$node_name = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM site_network WHERE id='$node_id'"));
		$node_name = $node_name['name'];
		if($_GET['confirm'] == 0){
			$notice = "<div class='warning'>Are you sure you want to delete this node? <a href='admin_network.php?delete=".$node_id."&confirm=1'>[Yes]</a> - <a href='admin_network.php'>[No]</a></div>";
		}elseif($_GET['confirm'] == 1){
			$marker = time();
			$notification = "The network node <font color='blue'>".$node_name."</font> has been deleted by <font color='blue'>".$member_handle."</font>.";
			$notification = mysqli_real_escape_string($con,$notification);
			mysqli_query($con,"INSERT INTO notifications_admin VALUES ('','$notification','8','$swc_date_time','$marker')");
			mysqli_query($con,"DELETE FROM site_network WHERE id='$node_id'");
			$notice = "<div class='error'>The node \"".$node_name."\" has been deleted</div>";
		}
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php require('head.php'); ?>
<?php require('main.css.php'); ?>
</head>

<body>
	<div id="container">
	<!-- Header Start-->
		<?php echo $page_load_header; ?>
		<!-- Header End and Menu Start-->  
		<div id="menu">
			<ul>
				<?php 
					echo $public_links;
					echo $member_links;
					echo $admin_link; 
				?> 
			</ul>
			<?php echo $searchbar; ?>
		<!-- Menu End and Content Start-->
		</div>
		<div id="content">
		<!-- Left content Start-->
			<div id="leftcontent">
			<!-- Navigation Start-->
				<div class="navigation">
					<div class="navhead">Member's Area</div>
					<?php echo $user_panel; ?>						
				</div>
				
				<!-- Dynamically Generated Panels-->
				<?php echo $page_load_side_panels; ?>
			</div>
			
			<!-- Left content ends and right content starts-->
			
			<div id="rightcontent">
				<div id="breadcrumbs"> <a href="admin.php">Admin</a> -> <a href="admin_network.php">Network</a> -> <a href="admin_network_add.php">Add Node</a></div>
				<!-- Post starts here-->
				<center><h1>Add Network Node</h1></center>
				<?php echo $notice; ?>
				<div class="postcontent">
					<center>
					<form action="admin_network.php" method="post">
					<table border="0" class="format_1">
						<tr>
							<td style="color:white;">Name:</td><td align="center" width="200"><input type="text" name="node_name" style="width:200px;"></td>
							<td style="color:white;">URL:</td><td align="center" width="300"><input type="text" name="node_url" style="width:300px;"></td>
							<td align="center"><input type="submit" name="add_node" value="Add" style="height:20px;width:80px;"></td>
						</tr>
					</table>
					</form>
					</center>
				</div>
			</div>
			<!-- Right content Ends here-->
		</div>
		
		<!-- Content Ends here and footer started-->
  
		<div class="footclear">&nbsp;</div>
		<?php echo $page_load_footer; ?>
		<!-- footer Ends here-->
	</div>
	<!-- Container Ends here-->
</body>

</html>

<?php mysqli_close($con); ?>
