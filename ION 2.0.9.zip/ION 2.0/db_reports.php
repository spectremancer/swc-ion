<?php
	session_start();
	require('connect.php');	
	require('session_load.php');
	require('page_load.php');
	$notice = "";
	if($_GET['action']){
		if($_GET['action'] == 1){
			$notice = "<div class='confirm'>The report has been submitted.</div>";
		}
	}
	
	//Check if account is enabled/disabled
	if($member_id != "" && $query_member['status'] == 0){
		header('Location: index.php?action=Logout&code=1');
	}elseif($member_db_reports_1 != 1 && $member_db_reports_2 != 1 && $member_db_reports_3 != 1){
		header('Location: index.php');
	}
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php require('head.php');?>
<?php require('main.css.php');?>
</head>

<body>
	<div id="container">
	<!-- Header Start-->
		<?php echo $page_load_header; ?>
		<!-- Header End and Menu Start-->  
		<div id="menu">
			<ul>
				<?php 
					echo $public_links;
					echo $member_links;
					echo $admin_link; 
				?> 
			</ul>
			<?php echo $searchbar; ?>
		<!-- Menu End and Content Start-->
		</div>
		<div id="content">
		<!-- Left content Start-->
			<div id="leftcontent">
			<!-- Navigation Start-->
				<div class="navigation">
					<div class="navhead">Member's Area</div>
					<?php echo $user_panel;?>
				</div>
				
				<!-- Dynamically Generated Panels-->
				<?php echo $page_load_side_panels; ?>
			</div>
			
			<!-- Left content ends and right content starts-->
			
			<div id="rightcontent">
				<div id="breadcrumbs"> <a href="db_reports.php">Reports</a></div>
				<!-- Post starts here-->
				<center><h1>Reports</h1></center>
				<?php echo $notice; ?>
				<div class="postcontent">
					<center>
						<table border="0" class="format_1">
							<tr class="rowdark">
								<?php if($member_clearance >= 1 && $member_db_reports_1 == 1){ echo "<td width='100' height='100' align='center'><a href='db_reports_add.php'><img src='./images/icons/add_reports.png'><br>Add Report</a></td>"; }?>
								<?php if($member_clearance >= 1){ echo "<td width='100' height='100' align='center'><a href='db_reports_search.php'><img src='./images/icons/search_reports.png'><br>Search Reports</a></td>"; }?>
								<?php if($member_clearance >= 1 && $member_db_reports_4 == 1){ echo "<td width='100' height='100' align='center'><a href='db_reports_tasks_add.php'><img src='./images/icons/add_tasks.png'><br>Add Task</a></td>"; }?>
								<?php if($member_clearance >= 1){ echo "<td width='100' height='100' align='center'><a href='db_reports_tasks_search.php'><img src='./images/icons/search_tasks.png'><br>Search Tasks</a></td>"; }?>
								<?php if($member_clearance >= 1 && $member_db_reports_1 == 1){ echo "<td width='100' height='100' align='center'><a href='db_reports_upload.php'><img src='./images/icons/upload_xml.png'><br>Upload XML File</a></td>"; }?>
							</tr>
						</table>
						<br/><br/>
						<div style="border:1px solid white;text-align:left;">
						<center><h2>Tasks vs Reports<h2></center>
						<p>Tasks are identified requirements to help organize intelligence collection and reporting in order to make the most use out of limited manpower and to avoid wasting efforts on unnecessary collection and reporting. When a task is created it is provided with a serial number. This allows reports to be linked to a task in order to keep them organized, much like documents (reports) being stacked together with a coversheet (task) on top of it.</p>
						<p>Reports may be submitted without the need for any tasks, but they will be generated as "General Reports".</p>
						</div>
					</center>
				</div>
			</div>
			<!-- Right content Ends here-->
		</div>
		
		<!-- Content Ends here and footer started-->
  
		<div class="footclear">&nbsp;</div>
		<?php echo $page_load_footer; ?>
		<!-- footer Ends here-->
	</div>
	<!-- Container Ends here-->
</body>

</html>

<?php mysqli_close($con); ?>
