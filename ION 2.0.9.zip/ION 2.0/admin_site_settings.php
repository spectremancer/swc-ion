<?php
	session_start();
	require('connect.php');	
	require('session_load.php');
	
	$notice = "";
	if($member_admin != 1 && $member_super_admin != 1){
		header('Location: index.php');
	}
	//Check if account is enabled/disabled
	if($member_id != "" && $query_member['status'] == 0){
		header('Location: index.php?action=Logout&code=1');
	}
	
	if($_POST['set_submit']){
		if($member_super_admin == 1){
			$set_title = mysqli_real_escape_string($con,$_POST['set_title']); if($set_title == ""){$set_title = "[title]";}
			$set_subtitle = mysqli_real_escape_string($con,$_POST['set_subtitle']); if($set_subtitle == ""){$set_subtitle = "[subtitle]";}
			$set_name = mysqli_real_escape_string($con,$_POST['set_name']); if($set_name == ""){$set_name = "[site_name]";}
			$set_acronym = mysqli_real_escape_string($con,$_POST['set_acronym']); if($set_acronym == ""){$set_acronym = "[acronym]";}
			$set_header_img = mysqli_real_escape_string($con,$_POST['set_header_img']);
			$set_footer = mysqli_real_escape_string($con,$_POST['set_footer']);
			$set_results_scan = mysqli_real_escape_string($con,$_POST['set_results_scan']);
			$set_super_admin = mysqli_real_escape_string($con,$_POST['set_super_admin']);
			
			if($set_header_img != ""){
				$imgExts = array("gif", "jpg", "jpeg", "png", "tiff", "tif");
				$urlExt = pathinfo($set_header_img, PATHINFO_EXTENSION);
				if (in_array($urlExt, $imgExts)) {
					$file_headers = @get_headers($set_header_img);
					if($file_headers[0] == 'HTTP/1.1 404 Not Found') {
						$notice = "<div class='error'>Image URL does not exist</div>";
					}
					else {
						mysqli_query($con,"UPDATE site_settings SET site_title='$set_title', site_subtitle='$set_subtitle', site_name='$set_name', site_acronym='$set_acronym', site_footer='$set_footer', site_banner='$set_header_img', super_admin='$set_super_admin', results_scanner='$set_results_scan' WHERE id='1'");
						$notice = "<div class='confirm'>Site Settings have been updated</div>";
					}
				}
			}else{
				mysqli_query($con,"UPDATE site_settings SET site_title='$set_title', site_subtitle='$set_subtitle', site_name='$set_name', site_acronym='$set_acronym', site_footer='$set_footer', site_banner='$set_header_img', super_admin='$set_super_admin', results_scanner='$set_results_scan' WHERE id='1'");
				$notice = "<div class='confirm'>Site Settings have been updated</div>";
			}
		}else{
			$notice = "<div class='warning'>Only the super admin can change site settings</div>";
		}
	}
	
	require('page_load.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php require('head.php'); ?>
<?php require('main.css.php'); ?>
</head>

<body>
	<div id="container">
	<!-- Header Start-->
		<?php echo $page_load_header; ?>
		<!-- Header End and Menu Start-->  
		<div id="menu">
			<ul>
				<?php 
					echo $public_links;
					echo $member_links;
					echo $admin_link; 
				?> 
			</ul>
			<?php echo $searchbar; ?>
		<!-- Menu End and Content Start-->
		</div>
		<div id="content">
		<!-- Left content Start-->
			<div id="leftcontent">
			<!-- Navigation Start-->
				<div class="navigation">
					<div class="navhead">Member's Area</div>
					<?php echo $user_panel; ?>						
				</div>
				
				<!-- Dynamically Generated Panels-->
				<?php echo $page_load_side_panels; ?>
			</div>
			
			<!-- Left content ends and right content starts-->
			
			<div id="rightcontent">
				<div id="breadcrumbs"> <a href="admin.php">Admin</a> -> <a href="admin_site_settings.php">Site Settings</a></div>
				<!-- Post starts here-->
				<center><h1>Site Settings</h1></center>
				<?php echo $notice; ?>
				<div class="postcontent">
					<center>
					<form action="admin_site_settings.php" method="post">
					<table class="format_1">
						<tr>
							<th colspan="2">General Settings</th>
						</tr>
						<tr>
							<td style="color:white;width:140px;">Site Title:</td>
							<td style="color:white;width:275px;" align="center"><input type="text" name="set_title" value="<?php echo $page_load_site_title;?>" style="width:275px;height:18px;"></td>
						</tr>
						<tr>
							<td style="color:white;width:140px;">Site Subtitle:</td>
							<td style="color:white;width:275px;" align="center"><input type="text" name="set_subtitle" value="<?php echo $page_load_site_subtitle;?>" style="width:275px;height:18px;"></td>
						</tr>
						<tr>
							<td style="color:white;width:140px;">Site Name:</td>
							<td style="color:white;width:275px;" align="center"><input type="text" name="set_name" value="<?php echo $page_load_site_name;?>" style="width:275px;height:18px;"></td>
						</tr>
						<tr>
							<td style="color:white;width:140px;">Site Acronym:</td>
							<td style="color:white;width:275px;" align="center"><input type="text" name="set_acronym" value="<?php echo $page_load_site_acronym;?>" style="width:275px;height:18px;"></td>
						</tr>
						<tr>
							<td style="color:white;width:140px;">Header Image:</td>
							<td style="color:white;width:275px;height:125px;" align="center">
								<input type="text" name="set_header_img" value="<?php echo $page_load_site_banner;?>" style="width:275px;height:18px;"><br><br>Example:<br>
								<img src="<?php echo $page_load_site_banner;?>" style="max-width:250px;height:auto;"><br>
								Image must be 900px x 135px
							</td>
						</tr>
						<tr>
							<td style="color:white;width:140px;">Software Version:</td>
							<td style="color:white;width:275px;" align="center"><?php echo $page_load_site_version;?></td>
						</tr>
						<tr>
							<td style="color:white;width:140px;">Footer Text:</td>
							<td style="color:white;width:275px;" align="center"><textarea name="set_footer" style="width:275px;height:200px;"><?php echo $page_load_site_footer;?></textarea></td>
						</tr>
						<tr>
							<th colspan="2">Database Settings</th>
						</tr>
						<tr>
							<td style="color:white;width:140px;">Scan results per page:</td>
							<td style="color:white;width:275px;" align="center">
								<select name="set_results_scan" style="width:275px;">
									<?php if($page_load_site_results_scanner == 50){echo '<option value="50" selected>50</option>';}else{echo '<option value="50">50</option>';}?>
									<?php if($page_load_site_results_scanner == 100){echo '<option value="100" selected>100</option>';}else{echo '<option value="100">100</option>';}?>
									<?php if($page_load_site_results_scanner == 250){echo '<option value="250" selected>250</option>';}else{echo '<option value="250">250</option>';}?>
									<?php if($page_load_site_results_scanner == 500){echo '<option value="500" selected>500</option>';}else{echo '<option value="500">500</option>';}?>
								</select>
							</td>
						</tr>
						<tr>
							<th colspan="2">Admin Settings</th>
						</tr>
						<tr>
							<td style="color:white;width:140px;">Super Admin:</td>
							<td style="color:white;width:275px;" align="center">
								<select name="set_super_admin" style="width:275px;">
									<?php
										$check_super = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM site_settings WHERE id='1'"));
										$check_super = $check_super['super_admin'];
										$query_members = mysqli_query($con,"SELECT * FROM members ORDER BY handle DESC");
										while($row = mysqli_fetch_assoc($query_members)){
											if($check_super == $row['id']){
												echo "<option value='".$row['id']."' selected>".$row['handle']."</option>";
											}else{
												echo "<option value='".$row['id']."'>".$row['handle']."</option>";
											}
										}
									?>
								</select>
							</td>
						</tr>
						<tr>
							<th colspan="2" align="center"><hr style="width:90%;"></th>
						</tr>
						<tr>
							<td colspan="2" align="center"><input type="submit" name="set_submit" value="Submit" style="height:20px;width:100px;"></td>
						</tr>
					</table>
					</form>
					</center>
				</div>
			</div>
			<!-- Right content Ends here-->
		</div>
		
		<!-- Content Ends here and footer started-->
  
		<div class="footclear">&nbsp;</div>
		<?php echo $page_load_footer; ?>
		<!-- footer Ends here-->
	</div>
	<!-- Container Ends here-->
</body>

</html>

<?php mysqli_close($con); ?>
