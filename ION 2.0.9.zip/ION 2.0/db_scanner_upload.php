<?php
	session_start();
	require('connect.php');	
	require('session_load.php');
	require('page_load.php');
	$notice = "";
	
	//Check if account is enabled/disabled
	if($member_id != "" && $query_member['status'] == 0){
		header('Location: index.php?action=Logout&code=1');
	}elseif($member_db_scanner_1 != 1 && $member_db_scanner_2 != 1 && $member_db_scanner_3 != 1){
		header('Location: index.php');
	}
	
	
	//Upload Script
	if($_POST['submit_upload']){
		$len = count($_FILES['file']['tmp_name']);
		
		$scan_complete = 0;
		$count_report = "";
		
		for($i = 0; $i < $len; $i++) {
			$file = $_FILES['file']['tmp_name'][$i];
		
			if ($_FILES["file"]["error"][$i] > 0){
				$notice = "<div class='error'>Error: ".$_FILES["file"]["error"][$i]."</div>";
			}
			else{
				
				if(($_FILES['file']['type'][$i] == "text/xml") || ($_FILES['file']['type'][$i] == "application/xml") || ($_FILES['file']['type'][$i] == "application/vnd.openstack.compute.v2+xml")){
					$xml_file = file_get_contents($file);
					$xml_file = str_replace("R&D","R&amp;D",$xml_file);
					//$xml_file = str_replace("&","&amp;",$xml_file);
					preg_match("/Year ([0-9]{1,2}) Day ([0-9]{1,3}), ([0-9]{1,2})\:([0-9]{1,2})\:/",$xml_file,$date_inv);
					if(strlen($date_inv[2]) == 2){$inv_date_day = "0".$date_inv[2]."";}elseif(strlen($date_inv[2]) == 1){$inv_date_day = "00".$date_inv[2]."";}
					$inv_date = "".$date_inv[1]."".$inv_date_day."";
					$inv_time = "".$date_inv[3]."".$date_inv[4]."";
		
					$xml = new SimpleXMLElement($xml_file);

					foreach($xml->channel as $channel){
						
						$title = $channel->title;
						preg_match("/Scan of coords (.*), (.*) at/si",$title,$match_coords);
						$scan_coords_x = $match_coords[1];
						$scan_coords_y = $match_coords[2];
						$title_coords = substr_count($title,"Scan of coords");
						$title = str_replace("Star Wars Combine - Scan of ","",$title);
						$title = str_replace("Star Wars Combine - ","",$title);
						$title_check = substr_count($title,"Focus");
						$title = str_replace(" (",",(",$title);
						$title = explode(',',$title);
						$title = $title[0];
						if($title == "deepspace coords"){
							$title = "Deepspace";
						}
						$description = $channel->description;
					}
					
					$contribute = 0;
					
					if($description == "scanner output"){
						
						foreach($xml->channel->cgt as $cgt){
							$year = mysqli_real_escape_string($con,$cgt->years);
							$day = mysqli_real_escape_string($con,$cgt->days);
							if(strlen($day) == 1){
								$day = "00".$day."";
							}elseif(strlen($day) == 2){
								$day = "0".$day."";
							}
							$hour = mysqli_real_escape_string($con,$cgt->hours);
							if(strlen($hour) == 1){
								$hour = "0".$hour."";
							}
							$minute = mysqli_real_escape_string($con,$cgt->minutes);
							if(strlen($minute) == 1){
								$minute = "0".$minute."";
							}
							
							$scanDate = "".$year."".$day."";
							$scanTime = "".$hour."".$minute."";
						}

						if($title_coords != 0){
							foreach($xml->channel->location as $location){
								$galx = mysqli_real_escape_string($con,$location->galX);
								$galy = mysqli_real_escape_string($con,$location->galY);
									$query_sector = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM resources_map_systems WHERE galx='$galx' AND galy='$galy'"));
									$query_num_sector = mysqli_num_rows(mysqli_query($con,"SELECT * FROM resources_map_systems WHERE galx='$galx' AND galy='$galy'"));
									if($query_num_sector == 0){
										$sector = "";
									}else{
										$sector = mysqli_real_escape_string($con,$query_sector['sector']);
									}
								if(!isset($location->surfX) && !isset($location->groundX)){
									$entity_sysx = $scan_coords_x;
									$entity_sysy = $scan_coords_y;
								}elseif(isset($location->surfX) && !isset($location->groundX)){
									$entity_sysx = mysqli_real_escape_string($con,$location->sysX);
									$entity_sysy = mysqli_real_escape_string($con,$location->sysY);
									$entity_surfx = $scan_coords_x;
									$entity_surfy = $scan_coords_y;
								}else{
									$entity_sysx = mysqli_real_escape_string($con,$location->sysX);
									$entity_sysy = mysqli_real_escape_string($con,$location->sysY);
									$entity_surfx = mysqli_real_escape_string($con,$location->surfX);
									$entity_surfy = mysqli_real_escape_string($con,$location->surfY);
									$entity_groundx = $scan_coords_x;
									$entity_groundy = $scan_coords_y;
								}
							}
						}else{
							foreach($xml->channel->location as $location){
								$galx = mysqli_real_escape_string($con,$location->galX);
								$galy = mysqli_real_escape_string($con,$location->galY);
									$query_sector = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM resources_map_systems WHERE galx='$galx' AND galy='$galy'"));
									$query_num_sector = mysqli_num_rows(mysqli_query($con,"SELECT * FROM resources_map_systems WHERE galx='$galx' AND galy='$galy'"));
									if($query_num_sector == 0){
										$sector = "Deepspace";
									}else{
										$sector = mysqli_real_escape_string($con,$query_sector['sector']);
									}
								$sysx = mysqli_real_escape_string($con,$location->sysX);
								$sysy = mysqli_real_escape_string($con,$location->sysY);
								$surfx = mysqli_real_escape_string($con,$location->surfX);
								$surfy = mysqli_real_escape_string($con,$location->surfY);
								$groundx = mysqli_real_escape_string($con,$location->groundX);
								$groundy = mysqli_real_escape_string($con,$location->groundY);
									if($groundx != "" && $groundy != ""){
										if($title_check != 0){
											$city = $title;
										}else{
											$city = "";
										}
									}
							}
						}
						
						$count_new = 0;
						$count_updated = 0;
						$count_outdated = 0;
						
						foreach($xml->channel->item as $item){
							$entity_name = mysqli_real_escape_string($con,$item->name);
							$entity_type = mysqli_real_escape_string($con,$item->typeName);
							$entity_id = mysqli_real_escape_string($con,$item->entityID);
							if($title_coords != 0){
								null;
							}else{
								if($groundx != ""){
									$entity_groundx = mysqli_real_escape_string($con,$item->x);
									$entity_groundy = mysqli_real_escape_string($con,$item->y);
									$entity_surfy = $surfy;
									$entity_surfx = $surfx;
									$entity_sysx = $sysx;
									$entity_sysy = $sysy;
								}elseif($surfx != ""){
									$entity_groundx = "";
									$entity_groundy = "";
									$entity_surfx = mysqli_real_escape_string($con,$item->x);
									$entity_surfy = mysqli_real_escape_string($con,$item->y);
									$entity_sysx = $sysx;
									$entity_sysy = $sysy;
								}else{
									$entity_groundx = "";
									$entity_groundy = "";
									$entity_surfx = "";
									$entity_surfy = "";
									$entity_sysx = mysqli_real_escape_string($con,$item->x);
									$entity_sysy = mysqli_real_escape_string($con,$item->y);
								}
							}
							
							$entity_owner = mysqli_real_escape_string($con,$item->ownerName);
							
							//FILTER ENTITY TYPE TO REMOVE USELESS ENTITIES
							$query_type = mysqli_num_rows(mysqli_query($con,"SELECT * FROM tool_entity_types WHERE type_name='$entity_type'"));
							if($query_type != 0){
								
								//Image Extractor Script
								$entity_image = mysqli_real_escape_string($con,$item->image);
								$entity_category = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM tool_entity_types WHERE type_name='$entity_type'"));
								$entity_category = $entity_category['type_category'];
								if(preg_match("/http\:\/\/img\.swcombine\.com\/[facilities|ships|vehicles|stations]{5,10}\/(.*?)\/.*\..*/si",$entity_image,$match_id)){
								}else{
									$query_custom_img = mysqli_num_rows(mysqli_query($con,"SELECT * FROM tool_entity_records_custom_img WHERE entity_id='$entity_id' AND entity_type='$entity_type'"));
									if($query_custom_img == 1){
										mysqli_query($con,"UPDATE tool_entity_records_custom_img SET image='$entity_image' WHERE entity_id='$entity_id' AND entity_type='$entity_type'");
									}else{
										mysqli_query($con,"INSERT INTO tool_entity_records_custom_img VALUES ('','$entity_id','$entity_type','$entity_image')");
										$contribute = 1;
									}
								}
								$cargo_true = 0;
								if($xml->channel->item->cargo){
									foreach($xml->channel->item->cargo as $cargo){
										$entity_passengers = mysqli_real_escape_string($con,$cargo->passengers);
										$entity_ships = mysqli_real_escape_string($con,$cargo->ships);
										$entity_vehicles = mysqli_real_escape_string($con,$cargo->vehicles);
									}
									$query_add = "'$entity_passengers','$entity_ships','$entity_vehicles',";
									$cargo_true = 1;
								}else{
									$query_add = "";
								}
								if($entity_category != ""){
									$entity_class = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM tool_entity_types WHERE type_name='$entity_type'"));
									$entity_class = $entity_class['type_class'];
									$query_records = mysqli_num_rows(mysqli_query($con,"SELECT * FROM tool_entity_records_".$entity_category." WHERE entity_id='$entity_id'"));
									$type_digraph = substr($entity_category,0,2);
									$entId = "".$type_digraph."".$entity_id."";
									if($query_records > 0){
										$query_records_1 = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM tool_entity_records_".$entity_category." WHERE entity_id='$entity_id'"));
										$query_records_id = $query_records_1['entity_id'];
										$query_records_date = $query_records_1['date'];
										$query_records_time = $query_records_1['time'];
										$query_records_dtg = "".$query_records_date."".$query_records_time."";
										$scanDTG = "".$scanDate."".$scanTime."";
										if(($query_records_id == $entity_id) && ($query_records_dtg < $scanDTG)){
											if($query_records > 0){
												$clearance = 1;
												mysqli_query($con,"UPDATE tool_entity_records_".$entity_category." SET entId='$entId', date='$scanDate', time='$scanTime', name='$entity_name', type='$entity_type', class='$entity_class', sector='$sector', galx='$galx', galy='$galy', sysx='$entity_sysx', sysy='$entity_sysy', surfx='$entity_surfx', surfy='$entity_surfy', groundx='$entity_groundx', groundy='$entity_groundy', owner='$entity_owner', clearance='$clearance' WHERE entity_id='$entity_id'");
												if($xml->channel->item->cargo){
													$check_cargo = mysqli_num_rows(mysqli_query($con,"SELECT * FROM tool_entity_records_".$entity_category."_cargo WHERE entity_id='$entity_id'"));
													if($check_cargo != 0){
														mysqli_query($con,"UPDATE tool_entity_records_".$entity_category."_cargo SET date='$scanDate', time='$scanTime', cargo_passengers='$entity_passengers', cargo_ships='$entity_ships', cargo_vehicles='$entity_vehicles', cargo_materials='$entity_materials' WHERE entity_id='$entity_id'");
														$contribute = 1;
													}else{
														mysqli_query($con,"INSERT INTO tool_entity_records_".$entity_category."_cargo VALUES ('$entity_id','$scanDate','$scanTime','$entity_passengers','$entity_ships','$entity_vehicles','$entity_materials')");
														$contribute = 1;
													}
												}
												$count_updated = $count_updated + 1;
											}
										}else{
											if($xml->channel->item->cargo){
												$check_cargo = mysqli_num_rows(mysqli_query($con,"SELECT * FROM tool_entity_records_".$entity_category."_cargo WHERE entity_id='$entity_id'"));
												if($check_cargo != 0){
													mysqli_query($con,"UPDATE tool_entity_records_".$entity_category."_cargo SET date='$scanDate', time='$scanTime', cargo_passengers='$entity_passengers', cargo_ships='$entity_ships', cargo_vehicles='$entity_vehicles', cargo_materials='$entity_materials' WHERE entity_id='$entity_id'");
													$contribute = 1;
												}else{
													mysqli_query($con,"INSERT INTO tool_entity_records_".$entity_category."_cargo VALUES ('$entity_id','$scanDate','$scanTime','$entity_passengers','$entity_ships','$entity_vehicles','$entity_materials')");
													$contribute = 1;
												}
												$count_updated = $count_updated + 1;
											}else{
												$count_outdated = $count_outdated + 1;
											}
										}
									}else{
										$clearance = 1;
										mysqli_query($con,"INSERT INTO tool_entity_records_".$entity_category." VALUES ('$entity_id','$entId','$scanDate','$scanTime','$entity_name','$entity_type','$entity_class','$sector','$galx','$galy','$entity_sysx','$entity_sysy','$entity_surfx','$entity_surfy','$entity_groundx','$entity_groundy','$entity_owner','$clearance')");
										$contribute = 1;
										if($xml->channel->item->cargo){
											$check_cargo = mysqli_num_rows(mysqli_query($con,"SELECT * FROM tool_entity_records_".$entity_category."_cargo WHERE entity_id='$entity_id'"));
											if($check_cargo != 0){
												mysqli_query($con,"UPDATE tool_entity_records_".$entity_category."_cargo SET date='$scanDate', time='$scanTime', cargo_passengers='$entity_passengers', cargo_ships='$entity_ships', cargo_vehicles='$entity_vehicles' WHERE entity_id='$entity_id'");
												$contribute = 1;
											}else{
												mysqli_query($con,"INSERT INTO tool_entity_records_".$entity_category."_cargo VALUES ('$entity_id','$scanDate','$scanTime','$entity_passengers','$entity_ships','$entity_vehicles')");
												$contribute = 1;
											}
										}
										$count_new = $count_new + 1;
									}
								}else{
									
								}
								$scan_complete = 2;
							}
						}
						
					//INPUT INVENTORY SCAN	
					}elseif($description != "scanner output"){
						$clearance = 2;
						
						$count_new = 0;
						$count_updated = 0;
						$count_outdated = 0;
						
						foreach($xml->ENTITY as $entity){
							$entity_name = mysqli_real_escape_string($con,$entity->NAME);
							$entity_type = mysqli_real_escape_string($con,$entity->TYPE);
							$entity_class = mysqli_real_escape_string($con,$entity->CLASS_NAME);
							$entity_id = mysqli_real_escape_string($con,$entity->ID);
							$entity_sector = mysqli_real_escape_string($con,$entity->SECTOR);
							$entity_galx = mysqli_real_escape_string($con,$entity->GALX);
							$entity_galy = mysqli_real_escape_string($con,$entity->GALY);
							$entity_sysx = mysqli_real_escape_string($con,$entity->SYSX);
							$entity_sysy = mysqli_real_escape_string($con,$entity->SYSY);
							$entity_surfx = mysqli_real_escape_string($con,$entity->SURFX);
							$entity_surfy = mysqli_real_escape_string($con,$entity->SURFY);
							$entity_groundx = mysqli_real_escape_string($con,$entity->GROUNDX);
							$entity_groundy = mysqli_real_escape_string($con,$entity->GROUNDY);
							$entity_owner = mysqli_real_escape_string($con,$entity->OWNER);
							$entity_category = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM tool_entity_types WHERE type_name='$entity_type'"));
							$entity_category = mysqli_real_escape_string($con,$entity_category['type_category']);
							$type_digraph = substr($entity_category,0,2);
							$entId = "".$type_digraph."".$entity_id."";
							if($entity_category != ""){
								$query_records = mysqli_query($con,"SELECT * FROM tool_entity_records_".$entity_category." WHERE entity_id='$entity_id'");
								if(mysqli_num_rows($query_records) != 0){
									mysqli_query($con,"UPDATE tool_entity_records_".$entity_category." SET date='$inv_date', time='$inv_time', owner='$entity_owner', sector='$entity_sector', name='$entity_name', galx='$entity_galx', galy='$entity_galy', sysx='$entity_sysx', sysy='$entity_sysy', surfx='$entity_surfx', surfy='$entity_surfx', groundx='$entity_groundx', 'groundy='$entity_groundy' WHERE entity_id='$entity_id'");
									$count_updated = $count_updated + 1;
									$contribute = 1;
								}
								else{
									mysqli_query($con,"INSERT INTO tool_entity_records_".$entity_category." VALUES ('$entity_id','$entId','$inv_date','$inv_time','$entity_name','$entity_type','$entity_class','$entity_sector','$entity_galx','$entity_galy','$entity_sysx','$entity_sysy','$entity_surfx','$entity_surfy','$entity_groundx','$entity_groundy','$entity_owner','$clearance')");
									$count_new = $count_new + 1;
									$contribute = 1;
								}
							}else{
								$count_unprocessed = $count_unprocessed + 1;
							}
						}
					}else{
						$notice = "<div class='error'>Unknown error occurred.</div>";
					}
					$scan_complete = 2;
				}else{
					$scan_complete = 1;
				}
			}//NON-ERROR BLOCK
			
			if($scan_complete == 2){							
				if($count_new != 0 || $count_updated != 0){$contribute = 1;}
				$count_report = "".$count_report."
				<br><br><br><u>Report for ".$_FILES['file']['name'][$i].":</u>
				<br>".$count_new." new records have been added.
				<br>".$count_updated." existing records have been updated.
				<br>".$count_outdated." existing records were outdated and not added to the database.
				";

				if($contribute == 1){
					$query_system = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM resources_map_systems WHERE galx='$galx' AND galy='$galy'"));
					$system = $query_system['system'];
					if($system == ""){$system = "Deepspace";}
					$clearance = 1;
					if($description == "scanner output"){
						$notification_member = mysqli_real_escape_string($con,"New data for the system \"<font color='blue'>".$system."</font>\" (".$galx.", ".$galy.") has been uploaded to the Scanner Database with ".$count_new." new records & ".$count_updated." updated records. The collection date is ".$scanDate." at ".$scanTime.".");
						$notification_admin = mysqli_real_escape_string($con,"New data for the system \"<font color='blue'>".$system."</font>\" (".$galx.", ".$galy.") has been uploaded to the Scanner Database with ".$count_new." new records & ".$count_updated." updated records. The collection date is ".$scanDate." at ".$scanTime.". Submitted by <font color='blue'>".$member_handle."</font>.");
					}else{
						$notification_member = mysqli_real_escape_string($con,"New Scanner Data has been uploaded from a <font color='blue'>special access source</font> to the Scanner Database with ".$count_new." new records & ".$count_updated." updated records. The collection date is ".$inv_date." at ".$inv_time.".");
						$notification_admin = mysqli_real_escape_string($con,"New Scanner Data has been uploaded from a <font color='blue'>special access source</font> to the Scanner Database with ".$count_new." new records & ".$count_updated." updated records. The collection date is ".$inv_date." at ".$inv_time.". Submitted by <font color='blue'>".$member_handle."</font>.");
					}
					$marker = time();
					if($cargo_true != 1){
						mysqli_query($con,"INSERT INTO notifications_members VALUES ('','$notification_member','$clearance',6,'$swc_date_time','$marker')");
						mysqli_query($con,"INSERT INTO notifications_admin VALUES ('','$notification_admin',6,'$swc_date_time','$marker')");
					}
				}
				$notice = "<div class='confirm'>Files have been uploaded successfully.</div>";
				
			}elseif($scan_complete == 1){
				$notice = "<div class='error'>Incorrect filetype. xml files are allowed only.</div>";
			}elseif($error == 1){
				$notice = "<div class='error'>".$error_msg."</div>";
			}
			
		}//END FILE LOOP
	}
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php require('head.php');?>
<?php require('main.css.php');?>
</head>

<body>
	<div id="container">
	<!-- Header Start-->
		<?php echo $page_load_header; ?>
		<!-- Header End and Menu Start-->  
		<div id="menu">
			<ul>
				<?php 
					echo $public_links;
					echo $member_links;
					echo $admin_link; 
				?> 
			</ul>
			<?php echo $searchbar; ?>
		<!-- Menu End and Content Start-->
		</div>
		<div id="content">
		<!-- Left content Start-->
			<div id="leftcontent">
			<!-- Navigation Start-->
				<div class="navigation">
					<div class="navhead">Member's Area</div>
					<?php echo $user_panel;?>
				</div>
				
				<!-- Dynamically Generated Panels-->
				<?php echo $page_load_side_panels; ?>
			</div>
			
			<!-- Left content ends and right content starts-->
			
			<div id="rightcontent">
				<div id="breadcrumbs"> <a href="db_scanner.php">Scanner Data</a> -> <a href="db_scanner_upload.php">Upload Scan File</a></div>
				<!-- Post starts here-->
				<center><h1>Upload Scan File</h1></center>
				<?php echo $notice; ?>
				<div class="postcontent">
					
					<center>
						Note: Use ctrl + left click to select multiple files for upload.
						<form method="post" action="db_scanner_upload.php" enctype="multipart/form-data">
						<table class="format_1">
						<tr>
							<td width="650">
								<input type="file" name="file[]" style="width:500px;color:white;" multiple>
								<input type="submit" name="submit_upload" value="Upload" style="width:100px;color:black;height:20px;">
							</td>
						</tr>
						</table>
						</form>
						<br><br><br>
						<?php
							echo $count_report;
						?>
					</center>
					
				</div>
			</div>
			<!-- Right content Ends here-->
		</div>
		
		<!-- Content Ends here and footer started-->
  
		<div class="footclear">&nbsp;</div>
		<?php echo $page_load_footer; ?>
		<!-- footer Ends here-->
	</div>
	<!-- Container Ends here-->
</body>

</html>

<?php mysqli_close($con); ?>
