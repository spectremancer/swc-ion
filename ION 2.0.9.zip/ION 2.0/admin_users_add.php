<?php
	session_start();
	require('connect.php');	
	require('session_load.php');
	require('page_load.php');
	$notice = "";
	if($member_admin != 1 && $member_super_admin != 1){
		header('Location: index.php');
	}
	//Check if account is enabled/disabled
	if($member_id != "" && $query_member['status'] == 0){
		header('Location: index.php?action=Logout&code=1');
	}
	
	//echo "".$_SERVER['SERVER_NAME']."".$_SERVER['PHP_SELF']."";
	if($_POST['add_submit']){
		$add_username = mysqli_real_escape_string($con,$_POST['add_username']);
		$add_email = mysqli_real_escape_string($con,$_POST['add_email']);
		$add_usergroup = mysqli_real_escape_string($con,$_POST['add_usergroup']);
		$add_pass = mysqli_real_escape_string($con,$_POST['add_pass']);
		$add_pass_confirm = mysqli_real_escape_string($con,$_POST['add_pass_confirm']);
		$query_existing_users = mysqli_num_rows(mysqli_query($con,"SELECT * FROM members WHERE (handle='$add_username') OR (email='$add_email')"));
		if($query_existing_users == 0){
			if($add_username != "" && $add_email != ""){
				if (!filter_var($add_email, FILTER_VALIDATE_EMAIL) === false) {
					if($add_pass != "" && $add_pass_confirm != ""){
						if($add_pass === $add_pass_confirm){
							$add_password_hash = md5(md5("xjke5p".$add_pass."jruc3e"));
							mysqli_query($con,"INSERT INTO members VALUES('','$add_usergroup','$add_username','$add_email','$add_password_hash','','','','1','0','0','0')");
							$notice = "<div class='confirm'>The user account ".$add_username." has been added. Password set as \"".$add_pass."\"</div>";
							
							$query_usergroup_name = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM members_usergroups WHERE id='$add_usergroup'"));
							$usergroup_name = $query_usergroup_name['name'];
							$marker = time();
							$notification = "The user <font color='blue'>".$add_username."</font> has been added by <font color='blue'>".$member_handle."</font>.";
							if($add_usergroup != 0 && $add_usergroup != ""){
								$notification = "".$notification." User added to usergroup <font color='blue'>".$usergroup_name."</font>.";
							}
							$notification = mysqli_real_escape_string($con,$notification);
							mysqli_query($con,"INSERT INTO notifications_admin VALUES ('','$notification','0','$swc_date_time','$marker')");
							
							$site_url = "".$_SERVER['SERVER_NAME']."".$_SERVER['PHP_SELF']."/index.php";
							$site_url = str_replace("admin_users_add.php","",$site_url);
							$to = $add_email;
							$subject = "User Registration";
							$txt = "Welcome to ".$page_load_site_name.". This email is a notification to let you know that the user ".$add_username." has been created  by a system administrator and registered to this email address.\r\n\r\nAccount Details\r\n-----------------\r\nUsername: ".$add_username."\r\nPassword: ".$add_pass."\n\r\n\rSite Link: ".$site_url."";
							$headers = "From: noreply@".$_SERVER['SERVER_NAME']."";
							mail($to,$subject,$txt,$headers);
						}else{
							$notice = "<div class='error'>The password and confirm password do not match each other.</div>";
						}
					}else{
						$add_pass = substr(md5($add_email),0,12);
						$add_password_hash = md5(md5("xjke5p".$add_pass."jruc3e"));
						mysqli_query($con,"INSERT INTO members VALUES('','$add_usergroup','$add_username','$add_email','$add_password_hash','','','','1','0','0','0')");
						$notice = "<div class='confirm'>The user account ".$add_username." has been added. Password set as \"".$add_pass."\"</div>";
						
						$query_usergroup_name = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM members_usergroups WHERE id='$add_usergroup'"));
						$usergroup_name = $query_usergroup_name['name'];
						$marker = time();
						$notification = "The user <font color='blue'>".$add_username."</font> has been added by <font color='blue'>".$member_handle."</font>.";
						if($add_usergroup != 0 && $add_usergroup != ""){
							$notification = "".$notification." User added to usergroup <font color='blue'>".$usergroup_name."</font>.";
						}
						$notification = mysqli_real_escape_string($con,$notification);
						mysqli_query($con,"INSERT INTO notifications_admin VALUES ('','$notification','0','$swc_date_time','$marker')");
						
						$site_url = "".$_SERVER['SERVER_NAME']."".$_SERVER['PHP_SELF']."/index.php";
						$site_url = str_replace("admin_users_add.php","",$site_url);
						$to = $add_email;
						$subject = "User Registration";
						$txt = "Welcome to ".$page_load_site_name.". This email is a notification to let you know that the user ".$add_username." has been created  by a system administrator and registered to this email address.\r\n\r\nAccount Details\r\n-----------------\r\nUsername: ".$add_username."\r\nPassword: ".$add_pass."\n\r\n\rSite Link: ".$site_url."";
						$headers = "From: noreply@".$_SERVER['SERVER_NAME']."";
						mail($to,$subject,$txt,$headers);
					}
				} else {
					$notice = "<div class='error'>Email format is invalid.</div>";
				}
			}else{
				$notice = "<div class='error'>Both the username and email are required to be filled out.</div>";
			}
		}else{
			$notice = "<div class='error'>A user already exists with either that username or email address.</div>";
		}
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php require('head.php'); ?>
<?php require('main.css.php'); ?>
</head>

<body>
	<div id="container">
	<!-- Header Start-->
		<?php echo $page_load_header; ?>
		<!-- Header End and Menu Start-->  
		<div id="menu">
			<ul>
				<?php 
					echo $public_links;
					echo $member_links;
					echo $admin_link; 
				?> 
			</ul>
			<?php echo $searchbar; ?>
		<!-- Menu End and Content Start-->
		</div>
		<div id="content">
		<!-- Left content Start-->
			<div id="leftcontent">
			<!-- Navigation Start-->
				<div class="navigation">
					<div class="navhead">Member's Area</div>
					<?php echo $user_panel; ?>						
				</div>
				
				<!-- Dynamically Generated Panels-->
				<?php echo $page_load_side_panels; ?>
			</div>
			
			<!-- Left content ends and right content starts-->
			
			<div id="rightcontent">
				<div id="breadcrumbs"> <a href="admin.php">Admin</a> -> <a href="admin_users.php">User Admin</a> -> <a href="admin_users_add.php">Add User</a></div>
				<!-- Post starts here-->
				<center><h1>Add User</h1></center>
				<?php echo $notice; ?>
				<div class="postcontent">
					<center>
					<p><i>Note: If password left blank, a random one will be generated for the user.</i></p>
					<form class="foorm" method="post" action="admin_users_add.php">
					<table>
						<tr>
							<td align="left">Username:<font color="red">*</font></td>
							<td align="center"><input type="text" name="add_username" value=""></td>
						</tr>
						<tr>
							<td align="left">Email:<font color="red">*</font></td>
							<td align="center"><input type="text" name="add_email" value=""></td>
						</tr>
						<tr>
							<td align="left">Usergroup:</td>
							<td align="center">
								<select style="width:175px;" name="add_usergroup">
									<option value="0" SELECTED>(No Usergroup)</option>
									<?php
										$query_groups = mysqli_query($con,"SELECT * FROM members_usergroups ORDER BY name ASC");
										while($row = mysqli_fetch_assoc($query_groups)){
											echo "<option value=".$row['id'].">".$row['name']."</option>";
										}
									?>
								</select>
							</td>
						</tr>
						<tr>
							<td align="left">Set Password:</td>
							<td align="center"><input type="password" name="add_pass" value=""></td>
						</tr>
						<tr>
							<td align="left">Confirm Password:</td>
							<td align="center"><input type="password" name="add_pass_confirm" value=""></td>
						</tr>
						<tr>
							<td align="center" colspan="2"><input class="button" type="submit" name="add_submit" value="Submit"></td>
						</tr>
					</table>
					</form>
					</center>
				</div>
			</div>
			<!-- Right content Ends here-->
		</div>
		
		<!-- Content Ends here and footer started-->
  
		<div class="footclear">&nbsp;</div>
		<?php echo $page_load_footer; ?>
		<!-- footer Ends here-->
	</div>
	<!-- Container Ends here-->
</body>

</html>

<?php mysqli_close($con); ?>
