<?php
require('connect.php');

//Version 2.0.7
mysqli_query($con,"
	CREATE TABLE IF NOT EXISTS `site_network` (
	`id` int(255) NOT NULL AUTO_INCREMENT,
	`name` varchar(255) NOT NULL,
	`url` varchar(255) NOT NULL,
	PRIMARY KEY (`id`)
	)
");

//Version 2.0.9
mysqli_query($con,"ALTER TABLE `members_usergroups` DROP COLUMN `db_comms`");
mysqli_query($con,"ALTER TABLE `members_usergroups` ADD `db_reports_1` ENUM('0','1') NOT NULL DEFAULT '0'");
mysqli_query($con,"ALTER TABLE `members_usergroups` ADD `db_reports_2` ENUM('0','1') NOT NULL DEFAULT '0'");
mysqli_query($con,"ALTER TABLE `members_usergroups` ADD `db_reports_3` ENUM('0','1') NOT NULL DEFAULT '0'");
mysqli_query($con,"ALTER TABLE `members_usergroups` ADD `db_reports_4` ENUM('0','1') NOT NULL DEFAULT '0'");
mysqli_query($con,"ALTER TABLE `members_usergroups` ADD `db_reports_5` ENUM('0','1') NOT NULL DEFAULT '0'");
mysqli_query($con,"ALTER TABLE `members_usergroups` DROP COLUMN `db_reports`");
mysqli_query($con,"ALTER TABLE `members_usergroups` ADD `db_scanner_1` ENUM('0','1') NOT NULL DEFAULT '0'");
mysqli_query($con,"ALTER TABLE `members_usergroups` ADD `db_scanner_2` ENUM('0','1') NOT NULL DEFAULT '0'");
mysqli_query($con,"ALTER TABLE `members_usergroups` ADD `db_scanner_3` ENUM('0','1') NOT NULL DEFAULT '0'");
mysqli_query($con,"ALTER TABLE `members_usergroups` ADD `db_scanner_4` ENUM('0','1') NOT NULL DEFAULT '0'");
mysqli_query($con,"ALTER TABLE `members_usergroups` DROP COLUMN `db_scanner`");
mysqli_query($con,"ALTER TABLE `members_usergroups` ADD `db_factions_1` ENUM('0','1') NOT NULL DEFAULT '0'");
mysqli_query($con,"ALTER TABLE `members_usergroups` ADD `db_factions_2` ENUM('0','1') NOT NULL DEFAULT '0'");
mysqli_query($con,"ALTER TABLE `members_usergroups` ADD `db_factions_3` ENUM('0','1') NOT NULL DEFAULT '0'");
mysqli_query($con,"ALTER TABLE `members_usergroups` ADD `db_factions_4` ENUM('0','1') NOT NULL DEFAULT '0'");
mysqli_query($con,"ALTER TABLE `members_usergroups` DROP COLUMN `db_factions`");
mysqli_query($con,"ALTER TABLE `members_usergroups` ADD `db_sentients_1` ENUM('0','1') NOT NULL DEFAULT '0'");
mysqli_query($con,"ALTER TABLE `members_usergroups` ADD `db_sentients_2` ENUM('0','1') NOT NULL DEFAULT '0'");
mysqli_query($con,"ALTER TABLE `members_usergroups` ADD `db_sentients_3` ENUM('0','1') NOT NULL DEFAULT '0'");
mysqli_query($con,"ALTER TABLE `members_usergroups` ADD `db_sentients_4` ENUM('0','1') NOT NULL DEFAULT '0'");
mysqli_query($con,"ALTER TABLE `members_usergroups` DROP COLUMN `db_sentients`");

mysqli_query($con,"
	CREATE TABLE IF NOT EXISTS `tool_reports` (
	`report_id` bigint(255) NOT NULL AUTO_INCREMENT,
	`report_serial` varchar(255) NOT NULL,
	`task_serial` varchar(255) NOT NULL,
	`member_id` varchar(255) NOT NULL,
	`date` varchar(255) NOT NULL,
	`time` varchar(255) NOT NULL,
	`subject` varchar(255) NOT NULL,
	`content` mediumtext NOT NULL,
	`clearance` varchar(255) NOT NULL,
	PRIMARY KEY (`report_id`)
	)
");

mysqli_query($con,"
	CREATE TABLE IF NOT EXISTS `tool_reports_tasks` (
	`task_id` bigint(255) NOT NULL AUTO_INCREMENT,
	`task_serial` varchar(255) NOT NULL,
	`member_id` varchar(255) NOT NULL,
	`date` varchar(255) NOT NULL,
	`time` varchar(255) NOT NULL,
	`subject` varchar(255) NOT NULL,
	`category` varchar(255) NOT NULL,
	`content` mediumtext NOT NULL,
	`clearance` varchar(255) NOT NULL,
	PRIMARY KEY (`task_id`)
	)
");
?>