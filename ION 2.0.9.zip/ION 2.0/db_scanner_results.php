<?php
	session_start();
	require('connect.php');	
	require('session_load.php');
	require('page_load.php');
	$notice = "";
	
	//Check if account is enabled/disabled
	if($member_id != "" && $query_member['status'] == 0){
		header('Location: index.php?action=Logout&code=1');
	}
	if($member_db_scanner_2 != 1 && $member_db_scanner_3 != 1){
		header('Location: index.php');
	}
	if($_SESSION['search_scanner']){
		$query_final = $_SESSION['search_scanner'];
	}
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php require('head.php');?>
<?php require('main.css.php');?>
</head>

<body>
	<div id="container">
	<!-- Header Start-->
		<?php echo $page_load_header; ?>
		<!-- Header End and Menu Start-->  
		<div id="menu">
			<ul>
				<?php 
					echo $public_links;
					echo $member_links;
					echo $admin_link; 
				?> 
			</ul>
			<?php echo $searchbar; ?>
		<!-- Menu End and Content Start-->
		</div>
		<div id="content">
		<!-- Left content Start-->
			<div id="leftcontent">
			<!-- Navigation Start-->
				<div class="navigation">
					<div class="navhead">Member's Area</div>
					<?php echo $user_panel;?>
				</div>
				
				<!-- Dynamically Generated Panels-->
				<?php echo $page_load_side_panels; ?>
			</div>
			
			<!-- Left content ends and right content starts-->
			
			<div id="rightcontent">
				<div id="breadcrumbs"> <a href="db_scanner.php">Scanner Data</a> -> <a href="db_scanner_search.php">Search Scanner Data</a> -> <a href="db_scanner_results.php">Search Results</a></div>
				<!-- Post starts here-->
				<center><h1>Search Results</h1></center>
				<?php echo $notice; ?>
				<div class="postcontent">
					<center>
						<?php
						
						if(mysqli_num_rows(mysqli_query($con,$query_final)) != 0){
							
							if(isset($_GET['page'])){
								$page = mysqli_real_escape_string($con,$_GET['page']);
							}else{
								$page = 1;
							}
							$current_page = intval($page);
							
							//GENERATE PAGINATION DATA
							$query_number = mysqli_num_rows(mysqli_query($con,$query_final));
							$per_page = $page_load_site_results_scanner;
							$pages = ceil($query_number/$per_page);
							if($page > $pages){$current_page = $pages;}elseif($page < 1){$current_page = 1;}
							$start = abs(($current_page-1)*$per_page);

							$query_string = "".$query_final." LIMIT ".$start.",".$per_page."";
							$query_results = mysqli_query($con,$query_string);
							
							//PAGINATION TOP
							if($query_number > $per_page){
								echo "
									<div style='width:600px;'>
									<table border='1' cellspacing='0' cellpadding='5' style='background-color:#555555;color:white;'>
										<tr>
											<td align='center' width='100' height='25' style='border:1px solid black;'>
								";
								if($current_page > 1){
									$page_subtract = $current_page - 1;
									echo "<a href='db_scanner_results.php?page=".$page_subtract."' style='color:#9999ff;'>Back</a>";
								}
								echo "
									</td>
									<td align='center' width='400' height='25' style='border:1px solid black;'>
								";
								
								if($pages <= 20){
									$current_page_count = 1;
									while($current_page_count <= $pages){
										if($current_page_count == $current_page){
											echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
										}else{
											echo "<span style='margin-right:5px;'><a href='db_scanner_results.php?page=".$current_page_count."' style='color:#9999ff;'>".$current_page_count."</a></span>";
										}
										$current_page_count++;
									}
									echo "
										</td>
										<td align='center' width='100' height='25' style='border:1px solid black;'>
									";
									if($current_page < ($current_page_count - 1)){
										$page_add = $current_page + 1;
										echo "<a href='db_scanner_results.php?page=".$page_add."' style='color:#9999ff;'>Next</a>";
									}
									echo "
										</td>
										</tr>
										</table></div><br><br>
									";
								}else{
									if($current_page >= 9){
										$count_initial = 1;
										while($count_initial <= 3){
											echo "<span style='margin-right:5px;'><a href='db_scanner_results.php?page=".$current_initial."' style='color:#9999ff;'>".$count_initial."</a></span>";
											$count_initial++;
										}
										echo "... ";
									}
									if($current_page == 7){$modifier = 6;}elseif($current_page == 8){$modifier = 7;}else{$modifier = 5;}
									if($current_page > 6){$current_page_count = $current_page - $modifier;}else{$current_page_count = 1;}
									if($current_page >= 1 && $current_page <= 9){
										while($current_page_count <= 15){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='db_scanner_results.php?page=".$current_page_count."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}elseif($current_page >= $pages - 7){
										$current_page_count = $pages - 12;
										while($current_page_count <= $pages){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='db_scanner_results.php?page=".$current_page_count."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}else{
										while($current_page_count <= ($current_page + 5)){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='db_scanner_results.php?page=".$current_page_count."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}
									if($current_page < ($pages - 7)){
										echo " ...";
										$count_final = $pages - 2;
										while($count_final <= $pages){
											echo "<span style='margin-right:5px;'><a href='db_scanner_results.php?page=".$count_final."' style='color:#9999ff;'>".$count_final."</a></span>";
											$count_final++;
										}
									}
									echo "
										</td>
										<td align='center' width='100' height='25' style='border:1px solid black;'>
									";
									if($current_page < ($current_page_count - 1)){
										$page_add = $current_page + 1;
										echo "<a href='db_scanner_results.php?page=".$page_add."' style='color:#9999ff;'>Next</a>";
									}
									echo "
										</td>
										</tr>
										</table></div><br><br>
									";
								}
							}
							
							//OUTPUT Results
							echo "You search returned ".$query_number." results";
							echo "
								<br><br>
								<table class='format_1'>
									<tr>
										<th width='30'>#</th>
										<th width='40'>Date</th>
										<th width='30'>Time</th>
										<th width='100'>Image</th>
										<th colspan='2'>Overview</th>
										<th>Location</th>
										<th colspan='2'>Cargo</th>
									</tr>
							";
							$count_rows = $start + 1;
							while($row = mysqli_fetch_assoc($query_results)){
								$entity_id = $row['entity_id'];
								$entity_type = $row['type'];
								$query_image = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM tool_entity_records_custom_img WHERE entity_id='$entity_id'"));
								$query_image = $query_image['image'];
								if($query_image == ""){
									$query_image = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM tool_entity_types WHERE type_name='$entity_type'"));
									$query_image = $query_image['image'];
								}
								
								$entity_sector = $row['sector'];
								if($entity_sector == ""){
									$entity_sector = "[No Sector]";
								}else{
									$sector_id = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM resources_map_sectors WHERE sector='$entity_sector'"));
									$sector_id = $sector_id['id'];
									$entity_sector = "<a href='http://www.swcombine.com/rules/?Galaxy_Map&sectorID=".$sector_id."' target='blank'>".$entity_sector."</a>";
								}
								
								$query_system = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM resources_map_systems WHERE galx='$row[galx]' AND galy='$row[galy]'"));
								$entity_system = $query_system['system'];
								if($entity_system == ""){
									$entity_system = "Deepspace";
								}else{
									$system_id = $query_system['system_id'];
									$entity_system = "<a href='http://www.swcombine.com/rules/?Galaxy_Map&systemID=".$system_id."' target='blank'>".$entity_system."</a>";
								}
								
								$query_planet = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM resources_map_planets WHERE galx='$row[galx]' AND galy='$row[galy]' AND sysx='$row[sysx]' AND sysy='$row[sysy]'"));
								$entity_planet = $query_planet['planet'];
								if($entity_planet == ""){
									$entity_planet = "Space";
								}else{
									$planet_id = $query_planet['planet_id'];
									$entity_planet = "<a href='http://www.swcombine.com/rules/?Galaxy_Map&planetID=".$planet_id."' target='blank'>".$entity_planet."</a>";
								}
								
								if($row['surfx'] != ""){$atmo = "Atmosphere (".$row['surfx'].", ".$row['surfy'].")";}else{$atmo = "";}
								if($row['groundx'] != ""){$ground = "Ground (".$row['groundx'].", ".$row['groundy'].")";}else{$ground = "";}
								
								$query_cargo = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM tool_entity_records_ship_cargo WHERE entity_id='$entity_id'"));
									$cargo_date = $query_cargo['date'];
									$cargo_time = $query_cargo['time'];
									$cargo_passengers = $query_cargo['cargo_passengers'];
										if($cargo_passengers == ""){
											$cargo_passengers = "";
											$passengers_img = "";
										}else{
											$passengers_img = "<img src='images/passengers.png' title='Passengers'>";
										}
									$cargo_ships = $query_cargo['cargo_ships'];
										if($cargo_ships == ""){
											$cargo_ships = "";
											$dockingBay_img = "";
										}else{
											$dockingBay_img = "<img src='images/dockingBay.png' title='Ships'>";
										}
									$cargo_vehicles = $query_cargo['cargo_vehicles'];
										if($cargo_vehicles == ""){
											$cargo_vehicles = "";
											$hangarBay_img = "";
										}else{
											$hangarBay_img = "<img src='images/hangarBay.png' title='Vehicles'>";
										}
								
								echo "
									<tr>
										<td rowspan='4' style='color:white;' align='center'>".$count_rows."</td>
										<td rowspan='4' style='color:white;' align='center'>".$row['date']."</td>
										<td rowspan='4' style='color:white;' align='center'>".$row['time']."</td>
										<td rowspan='4' align='center'><img src='".$query_image."' width='100' height='100' style='width:auto;height:100px;max-width:100px;'></td>
										<td style='color:white;' width='45'>ID:</td><td style='color:white;' width='140'>#".$entity_id."</td>
										<td style='color:white;' width='155' rowspan='4'>
											".$entity_sector."<br>
											".$entity_system." (".$row['galx'].", ".$row['galy'].")<br>
											".$entity_planet." (".$row['sysx'].", ".$row['sysy'].")<br>
											".$atmo."<br>
											".$ground."
										</td>
										<td width='80' colspan='2' style='color:white;' align='center'>".$cargo_date." ".$cargo_time."</td>
									</tr>
									<tr>
										<td style='color:white;' width='45'>Owner:</td><td style='color:yellow;' width='140'>".$row['owner']."</td>
										<td width='30'>".$passengers_img."</td><td style='color:white;' width='50' align='right'>".$cargo_passengers."</td>
									</tr>
									<tr>
										<td style='color:white;' width='45'>Name:</td><td style='color:white;' width='140'>".$row['name']."</td>
										<td width='30'>".$dockingBay_img."</td><td style='color:white;' width='50' align='right'>".$cargo_ships."</td>
									</tr>
									<tr>
										<td style='color:white;' width='45'>Type:</td><td style='color:white;' width='140'>".$row['type']."</td>
										<td width='30'>".$hangarBay_img."</td><td style='color:white;' width='50' align='right'>".$cargo_vehicles."</td>
									</tr>
								";
								$count_rows++;
							}
							echo "
								</table>
							";
							
							//PAGINATION BOTTOM
							if($query_number > $per_page){
								echo "
									<br><br>
									<div style='width:600px;'>
									<table border='1' cellspacing='0' cellpadding='5' style='background-color:#555555;color:white;'>
										<tr>
											<td align='center' width='100' height='25' style='border:1px solid black;'>
								";
								if($current_page > 1){
									$page_subtract = $current_page - 1;
									echo "<a href='db_scanner_results.php?page=".$page_subtract."' style='color:#9999ff;'>Back</a>";
								}
								echo "
									</td>
									<td align='center' width='400' height='25' style='border:1px solid black;'>
								";
								
								if($pages <= 20){
									$current_page_count = 1;
									while($current_page_count <= $pages){
										if($current_page_count == $current_page){
											echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
										}else{
											echo "<span style='margin-right:5px;'><a href='db_scanner_results.php?page=".$current_page_count."' style='color:#9999ff;'>".$current_page_count."</a></span>";
										}
										$current_page_count++;
									}
									echo "
										</td>
										<td align='center' width='100' height='25' style='border:1px solid black;'>
									";
									if($current_page < ($current_page_count - 1)){
										$page_add = $current_page + 1;
										echo "<a href='db_scanner_results.php?page=".$page_add."' style='color:#9999ff;'>Next</a>";
									}
									echo "
										</td>
										</tr>
										</table></div><br><br>
									";
								}else{
									if($current_page >= 9){
										$count_initial = 1;
										while($count_initial <= 3){
											echo "<span style='margin-right:5px;'><a href='db_scanner_results.php?page=".$current_initial."' style='color:#9999ff;'>".$count_initial."</a></span>";
											$count_initial++;
										}
										echo "... ";
									}
									if($current_page == 7){$modifier = 6;}elseif($current_page == 8){$modifier = 7;}else{$modifier = 5;}
									if($current_page > 6){$current_page_count = $current_page - $modifier;}else{$current_page_count = 1;}
									if($current_page >= 1 && $current_page <= 9){
										while($current_page_count <= 15){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='db_scanner_results.php?page=".$current_page_count."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}elseif($current_page >= $pages - 7){
										$current_page_count = $pages - 12;
										while($current_page_count <= $pages){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='db_scanner_results.php?page=".$current_page_count."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}else{
										while($current_page_count <= ($current_page + 5)){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='db_scanner_results.php?page=".$current_page_count."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}
									if($current_page < ($pages - 7)){
										echo " ...";
										$count_final = $pages - 2;
										while($count_final <= $pages){
											echo "<span style='margin-right:5px;'><a href='db_scanner_results.php?page=".$count_final."' style='color:#9999ff;'>".$count_final."</a></span>";
											$count_final++;
										}
									}
									echo "
										</td>
										<td align='center' width='100' height='25' style='border:1px solid black;'>
									";
									if($current_page < ($current_page_count - 1)){
										$page_add = $current_page + 1;
										echo "<a href='db_scanner_results.php?page=".$page_add."' style='color:#9999ff;'>Next</a>";
									}
									echo "
										</td>
										</tr>
										</table></div><br><br>
									";
								}
							}
							
						}else{
							echo "There are no results to display.";
						}
						
						?>
					</center>
				</div>
			</div>
			<!-- Right content Ends here-->
		</div>
		
		<!-- Content Ends here and footer started-->
  
		<div class="footclear">&nbsp;</div>
		<?php echo $page_load_footer; ?>
		<!-- footer Ends here-->
	</div>
	<!-- Container Ends here-->
</body>

</html>

<?php mysqli_close($con); ?>
