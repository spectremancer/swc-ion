<?php
	session_start();
	require('connect.php');	
	require('session_load.php');
	require('page_load.php');
	$notice = "";
	if($member_admin != 1 && $member_super_admin != 1){
		header('Location: index.php');
	}
	//Check if account is enabled/disabled
	if($member_id != "" && $query_member['status'] == 0){
		header('Location: index.php?action=Logout&code=1');
	}
	
	if($_GET['edit_id']){
		$edit_id = $_GET['edit_id'];
		$group_name = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM members_usergroups WHERE id='$edit_id'"));
		$group_name = $group_name['name'];
	}else{
		header('Location: admin_usergroups.php?errCode=1');
	}
	
	if($_GET['remove']){
		$remove_id = mysqli_real_escape_string($con,$_GET['remove']);
		mysqli_query($con,"UPDATE members SET id_usergroup='0' WHERE id='$remove_id'");
		$remove_handle = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM members WHERE id='$remove_id'"));
		$remove_handle = $remove_handle['handle'];
		$notice = "<div class='error'><font color='blue'>".$remove_handle."</font> has been removed from the usergroup <font color='blue'>".$group_name."</font>.</div>";
		$marker = time();
		$notification = mysqli_real_escape_string($con,"The user <font color='blue'>".$remove_handle."</font> has been removed from the usergroup <font color='blue'>".$group_name."</font> by <font color='blue'>".$member_handle."</font>.");
		mysqli_query($con,"INSERT INTO notifications_admin VALUES ('','$notification','1','$swc_date_time','$marker')");
	}else if($_GET['add_submit']){
		$add_user = mysqli_real_escape_string($con,$_GET['add_user']);
		$query_name = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM members WHERE id='$add_user'"));
		$query_name = $query_name['handle'];
		mysqli_query($con,"UPDATE members SET id_usergroup='$edit_id' WHERE id='$add_user'");
		$notice = "<div class='confirm'><font color='blue'>".$query_name."</font> has been moved to the usergroup <font color='blue'>".$group_name."</font>.</div>";
		$marker = time();
		$notification = mysqli_real_escape_string($con,"The user <font color='blue'>".$query_name."</font> has been added to the usergroup <font color='blue'>".$group_name."</font> by <font color='blue'>".$member_handle."</font>.");
		mysqli_query($con,"INSERT INTO notifications_admin VALUES ('','$notification','1','$swc_date_time','$marker')");
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php require('head.php'); ?>
<?php require('main.css.php'); ?>
</head>

<body>
	<div id="container">
	<!-- Header Start-->
		<?php echo $page_load_header; ?>
		<!-- Header End and Menu Start-->  
		<div id="menu">
			<ul>
				<?php 
					echo $public_links;
					echo $member_links;
					echo $admin_link; 
				?> 
			</ul>
			<?php echo $searchbar; ?>
		<!-- Menu End and Content Start-->
		</div>
		<div id="content">
		<!-- Left content Start-->
			<div id="leftcontent">
			<!-- Navigation Start-->
				<div class="navigation">
					<div class="navhead">Member's Area</div>
					<?php echo $user_panel; ?>						
				</div>
				
				<!-- Dynamically Generated Panels-->
				<?php echo $page_load_side_panels; ?>
			</div>
			
			<!-- Left content ends and right content starts-->
			
			<div id="rightcontent">
				<div id="breadcrumbs"> <a href="admin.php">Admin</a> -> <a href="admin_usergroups.php">Usergroups</a> -> <a href="">Usergroup Members</a></div>
				<!-- Post starts here-->
				<center><h1>Usergroup Members</h1></center>
				<?php echo $notice; ?>
				<div class="postcontent">
					<center>
					<form class="foorm" method="get" action="">
					<input type="hidden" name="edit_id" value="<?php echo $edit_id;?>">
						<table>
							<tr>
								<td align="left">Add User:</td>
								<td align="center"><select name="add_user" style="width:175px;">
									<?php
										$query_memberlist = mysqli_query($con,"SELECT * FROM members WHERE id_usergroup!='$edit_id'");
										while($row = mysqli_fetch_assoc($query_memberlist)){
											echo '
												<option value="'.$row['id'].'">'.$row['handle'].'</option>
											';
										}
									?>
								</select></td>
								<td align="center"><input type="submit" class="button" name="add_submit" value="Add"></td>
							</tr>
						</table>
					</form>
					<hr />
					<br /><br />
					<?php 
						$query_usergroup_members = mysqli_query($con,"SELECT * FROM members WHERE id_usergroup='$edit_id' ORDER BY handle ASC");
						if(mysqli_num_rows($query_usergroup_members) != 0){
							echo "
								<table border='1' class='format_1'>
									<tbody>
									<tr>
										<th width='200'>User</th>
										<th>Action</th>
									</tr>
							";
							$row_color = "rowdark";
							while($row = mysqli_fetch_assoc($query_usergroup_members)){
								echo "
									<tr class=".$row_color.">
										<td align='center'>".$row['handle']."</td>
										<td align='center'><a href='admin_usergroups_members.php?edit_id=".$edit_id."&remove=".$row['id']."'>[Remove]</a></td>
									</tr>
								";
								if($row_color == "rowdark"){
									$row_color = "rowlight";
								}else{
									$row_color = "rowdark";
								}
							}
							echo "
									</tbody>
								</table>
							";
						}else{
							echo "There are no members to display.";
						}
					?>
					</center>
				</div>
			</div>
			<!-- Right content Ends here-->
		</div>
		
		<!-- Content Ends here and footer started-->
  
		<div class="footclear">&nbsp;</div>
		<?php echo $page_load_footer; ?>
		<!-- footer Ends here-->
	</div>
	<!-- Container Ends here-->
</body>

</html>

<?php mysqli_close($con); ?>
