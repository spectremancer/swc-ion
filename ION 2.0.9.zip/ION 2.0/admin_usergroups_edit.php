<?php
	session_start();
	require('connect.php');	
	require('session_load.php');
	require('page_load.php');
	$notice = "";
	if($member_admin != 1 && $member_super_admin != 1){
		header('Location: index.php');
	}
	//Check if account is enabled/disabled
	if($member_id != "" && $query_member['status'] == 0){
		header('Location: index.php?action=Logout&code=1');
	}
	
	if($_GET['edit_id']){
		$edit_id = mysqli_real_escape_string($con,$_GET['edit_id']);
	}else{
		header('Location admin_usergroups.php?errCode=1');
	}
	
	if($_POST['edit_submit']){
		$usergroup = mysqli_real_escape_string($con,$_POST['edit_usergroup']);
		$access_admin = mysqli_real_escape_string($con,$_POST['access_admin']);
		if($access_admin != 1){
			$access_admin = 0;
		}
		$access_clearance = mysqli_real_escape_string($con,$_POST['access_clearance']);
		$access_reports_1 = mysqli_real_escape_string($con,$_POST['access_reports_1']);
		$access_reports_2 = mysqli_real_escape_string($con,$_POST['access_reports_2']);
		$access_reports_3 = mysqli_real_escape_string($con,$_POST['access_reports_3']);
		$access_reports_4 = mysqli_real_escape_string($con,$_POST['access_reports_4']);
		$access_scanner_1 = mysqli_real_escape_string($con,$_POST['access_scanner_1']);
		$access_scanner_2 = mysqli_real_escape_string($con,$_POST['access_scanner_2']);
		$access_scanner_3 = mysqli_real_escape_string($con,$_POST['access_scanner_3']);
		$access_factions_1 = mysqli_real_escape_string($con,$_POST['access_factions_1']);
		$access_factions_2 = mysqli_real_escape_string($con,$_POST['access_factions_2']);
		$access_sentients_1 = mysqli_real_escape_string($con,$_POST['access_sentients_1']);
		$access_sentients_2 = mysqli_real_escape_string($con,$_POST['access_sentients_2']);
		if($usergroup != ""){
			$query_usergroups = mysqli_num_rows(mysqli_query($con,"SELECT * FROM members_usergroups WHERE name='$usergroup' AND id!='$edit_id'"));
			if($query_usergroups == 0){
				$marker = time();
				$notification = "The usergroup <font color='blue'>".$usergroup."</font> has been edited by <font color='blue'>".$member_handle."</font> with a clearance level of ".$access_clearance.".";
					if($access_admin == 1){
						$notification = "".$notification." Admin Access Granted. ";
					}
					if($access_reports_1 == 1 || $access_reports_2 == 1 || $access_reports_3 == 1 || $access_reports_4 == 1){
						$notification = "".$notification." Reports Access Granted. ";
					}
					if($access_scanner_1 == 1 || $access_scanner_2 == 1 || $access_scanner_3 == 1){
						$notification = "".$notification." Scanner Access Granted. ";
					}
					if($access_factions_1 == 1 || $access_factions_2 == 1){
						$notification = "".$notification." Faction Profiles Access Granted. ";
					}
					if($access_sentients_1 == 1 || $access_sentients_2 == 1){
						$notification = "".$notification." Sentient Profiles Access Granted. ";
					}
				$notification = mysqli_real_escape_string($con,$notification);
				mysqli_query($con,"INSERT INTO notifications_admin VALUES ('','$notification','1','$swc_date_time','$marker')");
				mysqli_query($con,"UPDATE members_usergroups SET name='$usergroup', admin='$access_admin', clearance='$access_clearance', 
				db_reports_1='$access_reports_1', db_reports_2='$access_reports_2', db_reports_3='$access_reports_3', db_reports_4='$access_reports_4', db_scanner_1='$access_scanner_1', db_scanner_2='$access_scanner_2', db_scanner_3='$access_scanner_3', 
				db_factions_1='$access_factions_1', db_factions_2='$access_factions_2', db_sentients_1='$access_sentients_1', db_sentients_2='$access_sentients_2' WHERE id='$edit_id'");
				$notice = "<div class='confirm'>The usergroup <font color='blue'>".$usergroup."</font> has been edited.</div>";
			}else{
				$notice = "<div class='error'>A usergroup already exists with that name.</div>";
			}
		}else{
			$notice = "<div class='error'>You must enter a name for the usergroup.</div>";
		}
	}
	
	if($_POST['delete_usergroup']){
		$notice = "<div class='warning'>Are you sure you want to delete this usergroup? <a href='admin_usergroups_edit.php?edit_id=".$edit_id."&delete=1'>[Yes]</a> - <a href='admin_usergroups_edit.php?edit_id=".$edit_id."'>[No]</a></div>";
	}else if($_GET['delete']){
		mysqli_query($con,"UPDATE members SET id_usergroup='0' WHERE id_usergroup='$edit_id'");
		$query_usergroup = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM members_usergroups WHERE id='$edit_id'"));
		$marker = time();
		$notification = mysqli_real_escape_string($con,"The usergroup <font color='blue'>".$query_usergroup['name']."</font> has been deleted by <font color='blue'>".$member_handle."</font>.");
		mysqli_query($con,"INSERT INTO notifications_admin VALUES ('','$notification','1','$swc_date_time','$marker')");
		mysqli_query($con,"DELETE FROM members_usergroups WHERE id='$edit_id'");
		header('Location: admin_usergroups.php?errCode=2');
	}
	
	$query_usergroup_id = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM members_usergroups WHERE id='$edit_id'"));
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php require('head.php'); ?>
<?php require('main.css.php'); ?>
</head>

<body>
	<div id="container">
	<!-- Header Start-->
		<?php echo $page_load_header; ?>
		<!-- Header End and Menu Start-->  
		<div id="menu">
			<ul>
				<?php 
					echo $public_links;
					echo $member_links;
					echo $admin_link; 
				?> 
			</ul>
			<?php echo $searchbar; ?>
		<!-- Menu End and Content Start-->
		</div>
		<div id="content">
		<!-- Left content Start-->
			<div id="leftcontent">
			<!-- Navigation Start-->
				<div class="navigation">
					<div class="navhead">Member's Area</div>
					<?php echo $user_panel; ?>						
				</div>
				
				<!-- Dynamically Generated Panels-->
				<?php echo $page_load_side_panels; ?>
			</div>
			
			<!-- Left content ends and right content starts-->
			
			<div id="rightcontent">
				<div id="breadcrumbs"> <a href="admin.php">Admin</a> -> <a href="admin_usergroups.php">Usergroups</a> -> <a href="">Edit Usergroup</a></div>
				<!-- Post starts here-->
				<center><h1>Edit Usergroup</h1></center>
				<?php echo $notice; ?>
				<div class="postcontent">
					<center>
					<form class="foorm" method="post" action="">
					<table>
						<tr>
							<td align="left">Name: <font color='red'> * </font></td>
							<td align="center"><input type="text" name="edit_usergroup" value="<?php echo $query_usergroup_id['name'];?>"></td>
						</tr>
					</table>
					<br /><br />
					<table>
						<tr>
							<td align="left">Admin Access: </td>
							<td align="center" width="150">
							<?php
								if($query_usergroup_id['admin'] == 1){
									echo '<input type="checkbox" name="access_admin" value="1" CHECKED>';
								}else{
									echo '<input type="checkbox" name="access_admin" value="1">';
								}
							?>
							</td>
						</tr>
						<tr>
							<td align="left">Clearance Level: </td>
							<td align="center" width="150"><select name="access_clearance">
								<?php
									$count = 0;
									WHILE($count <=5){
										if($count == $query_usergroup_id['clearance']){
											echo "<option value='".$count."' SELECTED>Level ".$count."</option>";
										}else{
											echo "<option value='".$count."'>Level ".$count."</option>";
										}
										$count++;
									}
								?>
							</select></td>
						</tr>
					</table>
					<br /><br />
					<table border="1" class="format_1">
						<tr>
							<th colspan="5" align="center">Databases</th>
						</tr>
						<tr>
							<td align="left" style="color:white;">Reports</td>
							<td align="center" style="color:yellow;">Add<br><input type="checkbox" name="access_reports_1" value="1" <?php if($query_usergroup_id['db_reports_1'] == 1){echo "CHECKED";}?>></td>
							<td align="center" style="color:yellow;">Query<br><input type="checkbox" name="access_reports_2" value="1" <?php if($query_usergroup_id['db_reports_2'] == 1){echo "CHECKED";}?>></td>
							<td align="center" style="color:yellow;">Edit<br><input type="checkbox" name="access_reports_3" value="1" <?php if($query_usergroup_id['db_reports_3'] == 1){echo "CHECKED";}?>></td>
							<td align="center" style="color:yellow;">Tasking<br><input type="checkbox" name="access_reports_4" value="1" <?php if($query_usergroup_id['db_reports_4'] == 1){echo "CHECKED";}?>></td>
						</tr>
						<tr>
							<td align="left" style="color:white;">Scanner Data</td>
							<td align="center" style="color:yellow;">Upload<br><input type="checkbox" name="access_scanner_1" value="1" <?php if($query_usergroup_id['db_scanner_1'] == 1){echo "CHECKED";}?>></td>
							<td align="center" style="color:yellow;">Query<br><input type="checkbox" name="access_scanner_2" value="1" <?php if($query_usergroup_id['db_scanner_2'] == 1){echo "CHECKED";}?>></td>
							<td align="center" style="color:yellow;">Edit<br><input type="checkbox" name="access_scanner_3" value="1" <?php if($query_usergroup_id['db_scanner_3'] == 1){echo "CHECKED";}?>></td>
						</tr>
						<tr>
							<td align="left" style="color:white;">Faction Profiles</td>
							<td align="center" style="color:yellow;">Query<br><input type="checkbox" name="access_factions_1" value="1" <?php if($query_usergroup_id['db_factions_1'] == 1){echo "CHECKED";}?>></td>
							<td align="center" style="color:yellow;">Edit<br><input type="checkbox" name="access_factions_2" value="1" <?php if($query_usergroup_id['db_factions_2'] == 1){echo "CHECKED";}?>></td>
						</tr>
						<tr>
							<td align="left" style="color:white;">Sentient Profiles</td>
							<td align="center" style="color:yellow;">Query<br><input type="checkbox" name="access_sentients_1" value="1" <?php if($query_usergroup_id['db_sentients_1'] == 1){echo "CHECKED";}?>></td>
							<td align="center" style="color:yellow;">Edit<br><input type="checkbox" name="access_sentients_2" value="1" <?php if($query_usergroup_id['db_sentients_2'] == 1){echo "CHECKED";}?>></td>
						</tr>
					</table>
					<br /><br />
					<input class="button" type="submit" name="edit_submit" value="Submit">
					</form>
					<br /><hr />
					<form class="foorm" method="post" action="">
					Delete Usergroup? <input class="button" type="submit" name="delete_usergroup" value="Delete">
					</form>
					</center>
				</div>
			</div>
			<!-- Right content Ends here-->
		</div>
		
		<!-- Content Ends here and footer started-->
  
		<div class="footclear">&nbsp;</div>
		<?php echo $page_load_footer; ?>
		<!-- footer Ends here-->
	</div>
	<!-- Container Ends here-->
</body>

</html>

<?php mysqli_close($con); ?>
