<?php
	session_start();
	require('connect.php');	
	require('session_load.php');
	require('page_load.php');
	$notice = "";
	if($member_admin != 1 && $member_super_admin != 1){
		header('Location: index.php');
	}
	//Check if account is enabled/disabled
	if($member_id != "" && $query_member['status'] == 0){
		header('Location: index.php?action=Logout&code=1');
	}
	
	switch ($_GET['errCode']) {
		case 1:
			$notice = "<div class='error'>Invalid usergroup id.</div>";
			break;
		case 2:
			$notice = "<div class='error'>The usergroup has been deleted.</div>";
			break;
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php require('head.php'); ?>
<?php require('main.css.php'); ?>
</head>

<body>
	<div id="container">
	<!-- Header Start-->
		<?php echo $page_load_header; ?>
		<!-- Header End and Menu Start-->  
		<div id="menu">
			<ul>
				<?php 
					echo $public_links;
					echo $member_links;
					echo $admin_link; 
				?> 
			</ul>
			<?php echo $searchbar; ?>
		<!-- Menu End and Content Start-->
		</div>
		<div id="content">
		<!-- Left content Start-->
			<div id="leftcontent">
			<!-- Navigation Start-->
				<div class="navigation">
					<div class="navhead">Member's Area</div>
					<?php echo $user_panel; ?>						
				</div>
				
				<!-- Dynamically Generated Panels-->
				<?php echo $page_load_side_panels; ?>
			</div>
			
			<!-- Left content ends and right content starts-->
			
			<div id="rightcontent">
				<div id="breadcrumbs"> <a href="admin.php">Admin</a> -> <a href="admin_usergroups.php">Usergroups</a></div>
				<!-- Post starts here-->
				<center><h1>Usergroups</h1></center>
				<?php echo $notice; ?>
				<div class="postcontent">
					<center>
					<table>
						<tr>
							<td align="center"><a href="admin_usergroups_add.php">[Add Usergroup]</a></td>
						</tr>
					</table>
					<form class="foorm" method="get" action="admin_admin_usergroups.php">
						<table>
							<tr>
								<td align="left">Search Usergroups:</td>
								<td align="center"><input type="text" name="search_usergroup" value="<?php if($_GET['search_usergroup']){echo $_GET['search_usergroup'];}?>"></td>
								<td align="center"><input type="submit" class="button" name="search_submit" value="Search"></td>
							</tr>
						</table>
					</form>
					<hr />
					<br /><br />
					<?php 
						if($_GET['search_usergroup'] != ""){
							$search_usergroup = mysqli_real_escape_string($con,$_GET['search_usergroup']);
							$query_final = "SELECT * FROM members_usergroups WHERE name LIKE '%$search_usergroup%' ORDER BY name ASC";
						}else{
							$search_usergroup = "";
							$query_final = "SELECT * FROM members_usergroups ORDER BY name ASC";
						}
						if(mysqli_num_rows(mysqli_query($con,$query_final)) != 0){
							
							if(isset($_GET['page'])){
								$page = mysqli_real_escape_string($con,$_GET['page']);
							}else{
								$page = 1;
							}
							$current_page = intval($page);
							
							//GENERATE PAGINATION DATA
							$query_number = mysqli_num_rows(mysqli_query($con,$query_final));
							$per_page = 25;
							$pages = ceil($query_number/$per_page);
							if($page > $pages){$current_page = $pages;}elseif($page < 1){$current_page = 1;}
							$start = abs(($current_page-1)*$per_page);

							$query_string = "".$query_final." LIMIT ".$start.",".$per_page."";
							$query_results = mysqli_query($con,$query_string);
							
							//PAGINATION TOP
							if($query_number > $per_page){
								echo "
									<div style='width:600px;'>
									<table border='1' cellspacing='0' cellpadding='5' style='background-color:#555555;color:white;'>
										<tr>
											<td align='center' width='100' height='25' style='border:1px solid black;'>
								";
								if($current_page > 1){
									$page_subtract = $current_page - 1;
									echo "<a href='admin_usergroups.php?page=".$page_subtract."&search_usergroup=".$search_usergroup."' style='color:#9999ff;'>Back</a>";
								}
								echo "
									</td>
									<td align='center' width='400' height='25' style='border:1px solid black;'>
								";
								
								if($pages <= 20){
									$current_page_count = 1;
									while($current_page_count <= $pages){
										if($current_page_count == $current_page){
											echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
										}else{
											echo "<span style='margin-right:5px;'><a href='admin_usergroups.php?page=".$current_page_count."&search_usergroup=".$search_usergroup."' style='color:#9999ff;'>".$current_page_count."</a></span>";
										}
										$current_page_count++;
									}
									echo "
										</td>
										<td align='center' width='100' height='25' style='border:1px solid black;'>
									";
									if($current_page < ($current_page_count - 1)){
										$page_add = $current_page + 1;
										echo "<a href='admin_usergroups.php?page=".$page_add."&search_usergroup=".$search_usergroup."' style='color:#9999ff;'>Next</a>";
									}
									echo "
										</td>
										</tr>
										</table></div><br><br>
									";
								}else{
									if($current_page >= 9){
										$count_initial = 1;
										while($count_initial <= 3){
											echo "<span style='margin-right:5px;'><a href='admin_usergroups.php?page=".$current_initial."&search_usergroup=".$search_usergroup."' style='color:#9999ff;'>".$count_initial."</a></span>";
											$count_initial++;
										}
										echo "... ";
									}
									if($current_page == 7){$modifier = 6;}elseif($current_page == 8){$modifier = 7;}else{$modifier = 5;}
									if($current_page > 6){$current_page_count = $current_page - $modifier;}else{$current_page_count = 1;}
									if($current_page >= 1 && $current_page <= 9){
										while($current_page_count <= 15){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='admin_usergroups.php?page=".$current_page_count."&search_usergroup=".$search_usergroup."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}elseif($current_page >= $pages - 7){
										$current_page_count = $pages - 12;
										while($current_page_count <= $pages){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='admin_usergroups.php?page=".$current_page_count."&search_usergroup=".$search_usergroup."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}else{
										while($current_page_count <= ($current_page + 5)){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='admin_usergroups.php?page=".$current_page_count."&search_usergroup=".$search_usergroup."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}
									if($current_page < ($pages - 7)){
										echo " ...";
										$count_final = $pages - 2;
										while($count_final <= $pages){
											echo "<span style='margin-right:5px;'><a href='admin_usergroups.php?page=".$count_final."&search_usergroup=".$search_usergroup."' style='color:#9999ff;'>".$count_final."</a></span>";
											$count_final++;
										}
									}
									echo "
										</td>
										<td align='center' width='100' height='25' style='border:1px solid black;'>
									";
									if($current_page < ($current_page_count - 1)){
										$page_add = $current_page + 1;
										echo "<a href='admin_usergroups.php?page=".$page_add."&search_usergroup=".$search_usergroup."' style='color:#9999ff;'>Next</a>";
									}
									echo "
										</td>
										</tr>
										</table></div><br><br>
									";
								}
							}
							
							//OUTPUT DATA
							echo "
								<table border='1' class='format_1'>
									<tbody>
									<tr>
										<th width='200'>Usergroup</th>
										<th width='100'>Members</th>
										<th>Action</th>
									</tr>
							";
							$row_color = "rowdark";
							while($row = mysqli_fetch_assoc($query_results)){
								$query_membercount = mysqli_num_rows(mysqli_query($con,"SELECT * FROM members WHERE id_usergroup='$row[id]'"));
								echo "
									<tr class=".$row_color.">
										<td align='left'>".$row['name']."</td>
										<td align='center'>".$query_membercount."</td>
										<td align='center'><a href='admin_usergroups_members.php?edit_id=".$row['id']."'>[Members]</a> - <a href='admin_usergroups_edit.php?edit_id=".$row['id']."'>[Edit]</a></td>
									</tr>
								";
								if($row_color == "rowdark"){
									$row_color = "rowlight";
								}else{
									$row_color = "rowdark";
								}
							}
							echo "
									</tbody>
								</table>
							";
							
							//PAGINATION BOTTOM
							if($query_number > $per_page){
								echo "
									<br><br>
									<div style='width:600px;'>
									<table border='1' cellspacing='0' cellpadding='5' style='background-color:#555555;color:white;'>
										<tr>
											<td align='center' width='100' height='25' style='border:1px solid black;'>
								";
								if($current_page > 1){
									$page_subtract = $current_page - 1;
									echo "<a href='admin_usergroups.php?page=".$page_subtract."&search_usergroup=".$search_usergroup."' style='color:#9999ff;'>Back</a>";
								}
								echo "
									</td>
									<td align='center' width='400' height='25' style='border:1px solid black;'>
								";
								
								if($pages <= 20){
									$current_page_count = 1;
									while($current_page_count <= $pages){
										if($current_page_count == $current_page){
											echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
										}else{
											echo "<span style='margin-right:5px;'><a href='admin_usergroups.php?page=".$current_page_count."&search_usergroup=".$search_usergroup."' style='color:#9999ff;'>".$current_page_count."</a></span>";
										}
										$current_page_count++;
									}
									echo "
										</td>
										<td align='center' width='100' height='25' style='border:1px solid black;'>
									";
									if($current_page < ($current_page_count - 1)){
										$page_add = $current_page + 1;
										echo "<a href='admin_usergroups.php?page=".$page_add."&search_usergroup=".$search_usergroup."' style='color:#9999ff;'>Next</a>";
									}
									echo "
										</td>
										</tr>
										</table></div><br><br>
									";
								}else{
									if($current_page >= 9){
										$count_initial = 1;
										while($count_initial <= 3){
											echo "<span style='margin-right:5px;'><a href='admin_usergroups.php?page=".$current_initial."&search_usergroup=".$search_usergroup."' style='color:#9999ff;'>".$count_initial."</a></span>";
											$count_initial++;
										}
										echo "... ";
									}
									if($current_page == 7){$modifier = 6;}elseif($current_page == 8){$modifier = 7;}else{$modifier = 5;}
									if($current_page > 6){$current_page_count = $current_page - $modifier;}else{$current_page_count = 1;}
									if($current_page >= 1 && $current_page <= 9){
										while($current_page_count <= 15){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='admin_usergroups.php?page=".$current_page_count."&search_usergroup=".$search_usergroup."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}elseif($current_page >= $pages - 7){
										$current_page_count = $pages - 12;
										while($current_page_count <= $pages){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='admin_usergroups.php?page=".$current_page_count."&search_usergroup=".$search_usergroup."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}else{
										while($current_page_count <= ($current_page + 5)){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='admin_usergroups.php?page=".$current_page_count."&search_usergroup=".$search_usergroup."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}
									if($current_page < ($pages - 7)){
										echo " ...";
										$count_final = $pages - 2;
										while($count_final <= $pages){
											echo "<span style='margin-right:5px;'><a href='admin_usergroups.php?page=".$count_final."&search_usergroup=".$search_usergroup."' style='color:#9999ff;'>".$count_final."</a></span>";
											$count_final++;
										}
									}
									echo "
										</td>
										<td align='center' width='100' height='25' style='border:1px solid black;'>
									";
									if($current_page < ($current_page_count - 1)){
										$page_add = $current_page + 1;
										echo "<a href='admin_usergroups.php?page=".$page_add."&search_usergroup=".$search_usergroup."' style='color:#9999ff;'>Next</a>";
									}
									echo "
										</td>
										</tr>
										</table></div><br><br>
									";
								}
							}
							
						}else{
							echo "There are no usergroups to display.";
						}
					?>
					</center>
				</div>
			</div>
			<!-- Right content Ends here-->
		</div>
		
		<!-- Content Ends here and footer started-->
  
		<div class="footclear">&nbsp;</div>
		<?php echo $page_load_footer; ?>
		<!-- footer Ends here-->
	</div>
	<!-- Container Ends here-->
</body>

</html>

<?php mysqli_close($con); ?>
