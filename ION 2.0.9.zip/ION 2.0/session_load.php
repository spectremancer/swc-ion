<?php
require('connect.php');
date_default_timezone_set("America/Chicago");
$member_id = $_SESSION['id'];
$member_handle = "";
$query_member = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM members WHERE id='$member_id'"));
$member_handle = $query_member['handle'];
$_SESSION['handle'] = $query_member['handle'];

//Load SWC Date
$html = file_get_contents('http://www.swcombine.com/rules/cgt.php?size=12');

$pattern = '/var clockYear  \= ([0-9]{2});/';
preg_match_all($pattern, $html, $year);

$pattern = '/var clockDay   \= ([0-9]{1,3});/';
preg_match_all($pattern, $html, $day);

$pattern = '/var clockHour  \= ([0-9]{1,2});/';
preg_match_all($pattern, $html, $hour);

$pattern = '/var clockMinute \= ([0-9]{1,2});/';
preg_match_all($pattern, $html, $minute);

$pattern = '/var clockSecond \= ([0-9]{1,2});/';
preg_match_all($pattern, $html, $second);

$swc_year = $year[1][0];
$swc_day = str_pad($day[1][0],3,'0',STR_PAD_LEFT);
$swc_hour = str_pad($hour[1][0],2,'0',STR_PAD_LEFT);
$swc_minute = str_pad($minute[1][0],2,'0',STR_PAD_LEFT);
$swc_second = str_pad($second[1][0],2,'0',STR_PAD_LEFT);
$swc_date_time = "Y".$swc_year." D".$swc_day." ".$swc_hour.":".$swc_minute."";

//Load Member Profile
$query_verify = mysqli_query($con, "SELECT * FROM members WHERE handle='$member_handle'");
$query_verify = mysqli_fetch_assoc($query_verify);

//Load Member Accounts
$member_acct_credit = $query_verify['acct_credit'];
if($member_acct_credit == "Unlimited"){
	$member_expire = "Never";
	$member_acct_status = "<font color='green'>Active</font>";
}else if($member_acct_credit > 0){
	$member_expire = "";
	$member_acct_status = "<font color='green'>Active</font>";
}else{
	$member_expire = date("M Y");
	$member_expire = "01 ".$member_expire."";
	$member_acct_status = "<font color='red'>Disabled</font>";
}

//Last Login Date & Email
$member_last_login_date = $query_verify['date_login'];
$member_email = $query_verify['email'];

//Usergroup
$member_usergroup_id = $query_verify['id_usergroup'];

//Notification/Log Markers
$member_marker_notifications = $query_verify['notifications_members'];
$member_marker_logs = $query_verify['notifications_admin'];

//Load Members Clearances & Accesses
if($member_usergroup_id == 0){
	$query_access = mysqli_query($con, "SELECT * FROM members_access WHERE id='$member_id'");
	$query_access = mysqli_fetch_assoc($query_access);
	$member_admin = $query_access['admin'];
	$member_clearance = $query_access['clearance'];
	$member_db_reports_1 = $query_access['db_reports_1'];	$member_db_reports_2 = $query_access['db_reports_2'];	$member_db_reports_3 = $query_access['db_reports_3'];
	$member_db_reports_4 = $query_access['db_reports_4'];
	$member_db_scanner_1 = $query_access['db_scanner_1'];	$member_db_scanner_2 = $query_access['db_scanner_2'];	$member_db_scanner_3 = $query_access['db_scanner_3'];
	$member_db_factions_1 = $query_access['db_factions_1'];	$member_db_factions_2 = $query_access['db_factions_2'];	$member_db_factions_3 = $query_access['db_factions_3'];
	$member_db_sentients_1 = $query_access['db_sentients_1'];	$member_db_sentients_2 = $query_access['db_sentients_2'];	$member_db_sentients_3 = $query_access['db_sentients_3'];
	$member_usergroup = "N/A";
}else if($member_usergroup_id != 0){
	$query_access = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM members_usergroups WHERE id='$member_usergroup_id'"));
	$member_admin = $query_access['admin'];	$member_clearance = $query_access['clearance'];	$member_db_reports_1 = $query_access['db_reports_1'];	$member_db_reports_2 = $query_access['db_reports_2'];	$member_db_reports_3 = $query_access['db_reports_3'];
	$member_db_reports_4 = $query_access['db_reports_4'];	$member_db_scanner_1 = $query_access['db_scanner_1'];	$member_db_scanner_2 = $query_access['db_scanner_2'];	$member_db_scanner_3 = $query_access['db_scanner_3'];	$member_db_factions_1 = $query_access['db_factions_1'];	$member_db_factions_2 = $query_access['db_factions_2'];	$member_db_factions_3 = $query_access['db_factions_3'];	$member_db_sentients_1 = $query_access['db_sentients_1'];	$member_db_sentients_2 = $query_access['db_sentients_2'];	$member_db_sentients_3 = $query_access['db_sentients_3'];
	$member_usergroup = $query_access['name'];
}
$query_super_admin = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM site_settings"));
$query_super_admin = $query_super_admin['super_admin'];
if($member_id == $query_super_admin){
	$member_super_admin = 1;
}else{
	$member_super_admin = 0;
}

function paginate($item_per_page, $current_page, $total_records, $total_pages, $page_url)
{
    $pagination = '';
    if($total_pages > 0 && $total_pages != 1 && $current_page <= $total_pages){ //verify total pages and current page number
        $pagination .= '<ul class="pagination">';
        
        $right_links    = $current_page + 3; 
        $previous       = $current_page - 3; //previous link 
        $next           = $current_page + 1; //next link
        $first_link     = true; //boolean var to decide our first link
        
        if($current_page > 1){
            $previous_link = ($previous==0)?1:$previous;
            $pagination .= '<li class="first"><a href="'.$page_url.'?page=1" title="First">&laquo;</a></li>'; //first link
            $pagination .= '<li><a href="'.$page_url.'?page='.$previous_link.'" title="Previous">&lt;</a></li>'; //previous link
                for($i = ($current_page-2); $i < $current_page; $i++){ //Create left-hand side links
                    if($i > 0){
                        $pagination .= '<li><a href="'.$page_url.'?page='.$i.'">'.$i.'</a></li>';
                    }
                }   
            $first_link = false; //set first link to false
        }
        
        if($first_link){ //if current active page is first link
            $pagination .= '<li class="first active">'.$current_page.'</li>';
        }elseif($current_page == $total_pages){ //if it's the last active link
            $pagination .= '<li class="last active">'.$current_page.'</li>';
        }else{ //regular current link
            $pagination .= '<li class="active">'.$current_page.'</li>';
        }
                
        for($i = $current_page+1; $i < $right_links ; $i++){ //create right-hand side links
            if($i<=$total_pages){
                $pagination .= '<li><a href="'.$page_url.'?page='.$i.'">'.$i.'</a></li>';
            }
        }
        if($current_page < $total_pages){ 
                $next_link = ($i > $total_pages)? $total_pages : $i;
                $pagination .= '<li><a href="'.$page_url.'?page='.$next_link.'" >&gt;</a></li>'; //next link
                $pagination .= '<li class="last"><a href="'.$page_url.'?page='.$total_pages.'" title="Last">&raquo;</a></li>'; //last link
        }
        
        $pagination .= '</ul>'; 
    }
    return $pagination; //return pagination links
}

//PAGINATION EXAMPLE
/*
<?php
$db_username        = 'root'; //database username
$db_password        = ''; //dataabse password
$db_name            = 'test'; //database name
$db_host            = 'localhost'; //hostname or IP
$item_per_page      = 5; //item to display per page
$page_url           = "http://localhost/ajax-pagination/";

$mysqli_conn = new mysqli($db_host, $db_username, $db_password,$db_name); //connect to MySql
if ($mysqli_conn->connect_error) { //Output any connection error
    die('Error : ('. $mysqli_conn->connect_errno .') '. $mysqli_conn->connect_error);
}

if(isset($_GET["page"])){ //Get page number from $_GET["page"]
    $page_number = filter_var($_GET["page"], FILTER_SANITIZE_NUMBER_INT, FILTER_FLAG_STRIP_HIGH); //filter number
    if(!is_numeric($page_number)){die('Invalid page number!');} //incase of invalid page number
}else{
    $page_number = 1; //if there's no page number, set it to 1
}


$results = $mysqli_conn->query("SELECT COUNT(*) FROM paginate"); //get total number of records from database
$get_total_rows = $results->fetch_row(); //hold total records in variable

$total_pages = ceil($get_total_rows[0]/$item_per_page); //break records into pages

################# Display Records per page ############################
$page_position = (($page_number-1) * $item_per_page); //get starting position to fetch the records
//Fetch a group of records using SQL LIMIT clause
$results = $mysqli_conn->query("SELECT id, name, message FROM paginate ORDER BY id ASC LIMIT $page_position, $item_per_page");

//Display records fetched from database.

echo '<ul class="contents">';
while($row = $results->fetch_assoc()) {
    echo '<li>';
    echo  $row["id"]. '. <strong>' .$row["name"].'</strong> &mdash; '.$row["message"];
    echo '</li>';
}  
echo '</ul>';
################### End displaying Records #####################

//create pagination 
echo '<div align="center">';
// We call the pagination function here. 
echo paginate($item_per_page, $page_number, $get_total_rows[0], $total_pages, $page_url);
echo '</div>';
*/

?>
