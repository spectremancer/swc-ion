<?php
require('connect.php');
$site_variables = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM site_settings WHERE id='1'"));
$site_version = $site_variables['site_version'];
$site_lockdown = $site_variables['lockdown'];

if(!$_GET && !$_POST){
	$string = '<?xml version="1.0" encoding="UTF-8"?>
<parameters>
	<vars>
		<version>'.$site_version.'</version>
		<lockdown>'.$site_lockdown.'</lockdown>
	</vars>
</parameters>
	';
	
	echo $string;
}

?>