<?php
	session_start();
	require('connect.php');	
	require('session_load.php');
	require('page_load.php');
	$notice = "";
	if($member_admin != 1 && $member_super_admin != 1){
		header('Location: index.php');
	}
	//Check if account is enabled/disabled
	if($member_id != "" && $query_member['status'] == 0){
		header('Location: index.php?action=Logout&code=1');
	}
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php require('head.php'); ?>
<?php require('main.css.php'); ?>
</head>

<body>
	<div id="container">
	<!-- Header Start-->
		<?php echo $page_load_header; ?>
		<!-- Header End and Menu Start-->  
		<div id="menu">
			<ul>
				<?php 
					echo $public_links;
					echo $member_links;
					echo $admin_link; 
				?> 
			</ul>
			<?php echo $searchbar; ?>
		<!-- Menu End and Content Start-->
		</div>
		<div id="content">
		<!-- Left content Start-->
			<div id="leftcontent">
			<!-- Navigation Start-->
				<div class="navigation">
					<div class="navhead">Member's Area</div>
					<?php echo $user_panel; ?>						
				</div>
				
				<!-- Dynamically Generated Panels-->
				<?php echo $page_load_side_panels; ?>
			</div>
			
			<!-- Left content ends and right content starts-->
			
			<div id="rightcontent">
				<div id="breadcrumbs"> <a href="admin.php">Admin</a> -> <a href="admin_logs.php">Logs</a></div>
				<!-- Post starts here-->
				<center><h1>Logs</h1></center>
				<?php echo $notice; ?>
				<div class="postcontent">
					<center>
					<form class="foorm" method="get" action="admin_logs.php">
						<table>
							<tr>
								<td align="left">Search Logs:</td>
								<td align="center"><input type="text" name="search_logs" value="<?php if($_GET['search_logs']){echo $_GET['search_logs'];}?>"></td>
								<td align="center"><input type="submit" class="button" name="search_submit" value="Search"></td>
							</tr>
						</table>
					</form>
					<hr />
					<br /><br />
					<?php 
						if($_GET['search_logs'] != ""){
							$search_logs = mysqli_real_escape_string($con,$_GET['search_logs']);
							$query_final = "SELECT * FROM notifications_admin WHERE (notification LIKE '%$search_logs%') OR (timestamp LIKE '%$search_logs%') ORDER BY marker DESC";
						}else{
							$search_logs = "";
							$query_final = "SELECT * FROM notifications_admin ORDER BY marker DESC";				
						}
						if(mysqli_num_rows(mysqli_query($con,$query_final)) != 0){
							
							if(isset($_GET['page'])){
								$page = mysqli_real_escape_string($con,$_GET['page']);
							}else{
								$page = 1;
							}
							$current_page = intval($page);
							
							//GENERATE PAGE LINKS
							$query_number = mysqli_num_rows(mysqli_query($con,$query_final));
							$per_page = 50;
							$pages = ceil($query_number/$per_page);
							if($page > $pages){$current_page = $pages;}elseif($page < 1){$current_page = 1;}
							$start = abs(($current_page-1)*$per_page);

							$query_string = "".$query_final." LIMIT ".$start.",".$per_page."";
							$query_results = mysqli_query($con,$query_string);
								
							//PAGINATION TOP
							if($query_number > $per_page){
								echo "
									<div style='width:600px;'>
									<table border='1' cellspacing='0' cellpadding='5' style='background-color:#555555;color:white;'>
										<tr>
											<td align='center' width='100' height='25' style='border:1px solid black;'>
								";
								if($current_page > 1){
									$page_subtract = $current_page - 1;
									echo "<a href='admin_logs.php?page=".$page_subtract."&search_logs=".$search_logs."' style='color:#9999ff;'>Back</a>";
								}
								echo "
									</td>
									<td align='center' width='400' height='25' style='border:1px solid black;'>
								";
								
								if($pages <= 20){
									$current_page_count = 1;
									while($current_page_count <= $pages){
										if($current_page_count == $current_page){
											echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
										}else{
											echo "<span style='margin-right:5px;'><a href='admin_logs.php?page=".$current_page_count."&search_logs=".$search_logs."' style='color:#9999ff;'>".$current_page_count."</a></span>";
										}
										$current_page_count++;
									}
									echo "
										</td>
										<td align='center' width='100' height='25' style='border:1px solid black;'>
									";
									if($current_page < ($current_page_count - 1)){
										$page_add = $current_page + 1;
										echo "<a href='admin_logs.php?page=".$page_add."&search_logs=".$search_logs."' style='color:#9999ff;'>Next</a>";
									}
									echo "
										</td>
										</tr>
										</table></div><br><br>
									";
								}else{
									if($current_page >= 9){
										$count_initial = 1;
										while($count_initial <= 3){
											echo "<span style='margin-right:5px;'><a href='admin_logs.php?page=".$current_initial."&search_logs=".$search_logs."' style='color:#9999ff;'>".$count_initial."</a></span>";
											$count_initial++;
										}
										echo "... ";
									}
									if($current_page == 7){$modifier = 6;}elseif($current_page == 8){$modifier = 7;}else{$modifier = 5;}
									if($current_page > 6){$current_page_count = $current_page - $modifier;}else{$current_page_count = 1;}
									if($current_page >= 1 && $current_page <= 9){
										while($current_page_count <= 15){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='admin_logs.php?page=".$current_page_count."&search_logs=".$search_logs."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}elseif($current_page >= $pages - 7){
										$current_page_count = $pages - 12;
										while($current_page_count <= $pages){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='admin_logs.php?page=".$current_page_count."&search_logs=".$search_logs."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}else{
										while($current_page_count <= ($current_page + 5)){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='admin_logs.php?page=".$current_page_count."&search_logs=".$search_logs."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}
									if($current_page < ($pages - 7)){
										echo " ...";
										$count_final = $pages - 2;
										while($count_final <= $pages){
											echo "<span style='margin-right:5px;'><a href='admin_logs.php?page=".$count_final."&search_logs=".$search_logs."' style='color:#9999ff;'>".$count_final."</a></span>";
											$count_final++;
										}
									}
									echo "
										</td>
										<td align='center' width='100' height='25' style='border:1px solid black;'>
									";
									if($current_page < ($current_page_count - 1)){
										$page_add = $current_page + 1;
										echo "<a href='admin_logs.php?page=".$page_add."&search_logs=".$search_logs."' style='color:#9999ff;'>Next</a>";
									}
									echo "
										</td>
										</tr>
										</table></div><br><br>
									";
								}
							}
							
							echo "
								<table border='1' class='format_1'>
									<tbody>
									<tr>
										<th width='25'>#</th>
										<th width='25'>Cat.</th>
										<th width='100'>Date-Time</th>
										<th width='500'>Notification</th>
									</tr>
							";
							$row_color = "rowdark";
							$count = $start + 1;
							while($row = mysqli_fetch_assoc($query_results)){
								if($row['category'] == 0){
									$category = "<img src='./images/notifications/user.png' height='22' width='22'>";
								}else if($row['category'] == 1){
									$category = "<img src='./images/notifications/usergroups.png' height='22' width='22'>";
								}else if($row['category'] == 2){
									$category = "<img src='./images/notifications/search.png' height='22' width='22'>";
								}else if($row['category'] == 3){
									$category = "<img src='./images/notifications/comms.png' height='22' width='22'>";
								}else if($row['category'] == 4){
									$category = "<img src='./images/notifications/report.png' height='22' width='22'>";
								}else if($row['category'] == 5){
									$category = "<img src='./images/notifications/profile.png' height='22' width='22'>";
								}else if($row['category'] == 6){
									$category = "<img src='./images/notifications/scan.png' height='22' width='22'>";
								}else if($row['category'] == 7){
									$category = "<img src='./images/notifications/edit.png' height='22' width='22'>";
								}else if($row['category'] == 8){
									$category = "<img src='./images/notifications/system.png' height='22' width='22'>";
								}
								if($row['marker'] > $member_marker_logs){
									echo "
										<tr style='background-color:yellow;'>
											<td align='center'>".$count."</td>
											<td align='center'>".$category."</td>
											<td align='center'>".$row['timestamp']."</td>
											<td align='left'>".$row['notification']."</td>
										</tr>
									";
								}else{
									echo "
										<tr class=".$row_color.">
											<td align='center'>".$count."</td>
											<td align='center'>".$category."</td>
											<td align='center'>".$row['timestamp']."</td>
											<td align='left'>".$row['notification']."</td>
										</tr>
									";
								}
								if($row_color == "rowdark"){
									$row_color = "rowlight";
								}else{
									$row_color = "rowdark";
								}
								$count++;
							}
							echo "
									</tbody>
								</table>
							";
							$marker = time();
							mysqli_query($con,"UPDATE members SET notifications_admin='$marker' WHERE id='$member_id'");
							
							//PAGINATION BOTTOM
							if($query_number > $per_page){
								echo "
									<br><br>
									<div style='width:600px;'>
									<table border='1' cellspacing='0' cellpadding='5' style='background-color:#555555;color:white;'>
										<tr>
											<td align='center' width='100' height='25' style='border:1px solid black;'>
								";
								if($current_page > 1){
									$page_subtract = $current_page - 1;
									echo "<a href='admin_logs.php?page=".$page_subtract."&search_logs=".$search_logs."' style='color:#9999ff;'>Back</a>";
								}
								echo "
									</td>
									<td align='center' width='400' height='25' style='border:1px solid black;'>
								";
								
								if($pages <= 20){
									$current_page_count = 1;
									while($current_page_count <= $pages){
										if($current_page_count == $current_page){
											echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
										}else{
											echo "<span style='margin-right:5px;'><a href='admin_logs.php?page=".$current_page_count."&search_logs=".$search_logs."' style='color:#9999ff;'>".$current_page_count."</a></span>";
										}
										$current_page_count++;
									}
									echo "
										</td>
										<td align='center' width='100' height='25' style='border:1px solid black;'>
									";
									if($current_page < ($current_page_count - 1)){
										$page_add = $current_page + 1;
										echo "<a href='admin_logs.php?page=".$page_add."&search_logs=".$search_logs."' style='color:#9999ff;'>Next</a>";
									}
									echo "
										</td>
										</tr>
										</table></div><br><br>
									";
								}else{
									if($current_page >= 9){
										$count_initial = 1;
										while($count_initial <= 3){
											echo "<span style='margin-right:5px;'><a href='admin_logs.php?page=".$count_initial."&search_logs=".$search_logs."' style='color:#9999ff;'>".$count_initial."</a></span>";
											$count_initial++; //page=".$current_initial."
										}
										echo "... ";
									}
									if($current_page == 7){$modifier = 6;}elseif($current_page == 8){$modifier = 7;}else{$modifier = 5;}
									if($current_page > 6){$current_page_count = $current_page - $modifier;}else{$current_page_count = 1;}
									if($current_page >= 1 && $current_page <= 9){
										while($current_page_count <= 15){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='admin_logs.php?page=".$current_page_count."&search_logs=".$search_logs."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}elseif($current_page >= $pages - 7){
										$current_page_count = $pages - 12;
										while($current_page_count <= $pages){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='admin_logs.php?page=".$current_page_count."&search_logs=".$search_logs."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}else{
										while($current_page_count <= ($current_page + 5)){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='admin_logs.php?page=".$current_page_count."&search_logs=".$search_logs."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}
									if($current_page < ($pages - 7)){
										echo " ...";
										$count_final = $pages - 2;
										while($count_final <= $pages){
											echo "<span style='margin-right:5px;'><a href='admin_logs.php?page=".$count_final."&search_logs=".$search_logs."' style='color:#9999ff;'>".$count_final."</a></span>";
											$count_final++;
										}
									}
									echo "
										</td>
										<td align='center' width='100' height='25' style='border:1px solid black;'>
									";
									if($current_page < ($current_page_count - 1)){
										$page_add = $current_page + 1;
										echo "<a href='admin_logs.php?page=".$page_add."&search_logs=".$search_logs."' style='color:#9999ff;'>Next</a>";
									}
									echo "
										</td>
										</tr>
										</table></div><br><br>
									";
								}
							}
							
						}else{
							echo "There are no logs to display.";
						}
					?>
					</center>
				</div>
			</div>
			<!-- Right content Ends here-->
		</div>
		
		<!-- Content Ends here and footer started-->
  
		<div class="footclear">&nbsp;</div>
		<?php echo $page_load_footer; ?>
		<!-- footer Ends here-->
	</div>
	<!-- Container Ends here-->
</body>

</html>

<?php mysqli_close($con); ?>
