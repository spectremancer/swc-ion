<?php
	session_start();
	require('connect.php');	
	require('session_load.php');
	require('page_load.php');
	$notice = "";
	if($member_admin != 1 && $member_super_admin != 1){
		header('Location: index.php');
	}
	
	//Check if account is enabled/disabled
	if($member_id != "" && $query_member['status'] == 0){
		header('Location: index.php?action=Logout&code=1');
	}
	
	if($_GET['action'] == "lock"){
		mysqli_query($con,"UPDATE site_settings SET lockdown='1'");
		$notice = '<div class="warning">The system has been locked. Only administrators can access the system.</div>';
		$notification = "A system lockdown has been initiated by <font color='blue'>".$member_handle."</font>.";
		$marker = time();
		$notification = mysqli_real_escape_string($con,$notification);
		mysqli_query($con,"INSERT INTO notifications_admin VALUES ('','$notification','8','$swc_date_time','$marker')");
	}else if($_GET['action'] == "unlock"){
		mysqli_query($con,"UPDATE site_settings SET lockdown='0'");
		$notice = '<div class="warning">The system has been unlocked. Activities can resume as normal.</div>';
		$notification = "A system lockdown has been terminated by <font color='blue'>".$member_handle."</font>.";
		$marker = time();
		$notification = mysqli_real_escape_string($con,$notification);
		mysqli_query($con,"INSERT INTO notifications_admin VALUES ('','$notification','8','$swc_date_time','$marker')");
	}
	
	//Update Check
	$query_key = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM site_settings WHERE id='1'"));
	$query_key = $query_key['software_key'];
	
	$url = "http://afr-cpr.com/update/version_new.xml";

	
	$xml = simplexml_load_file($url) or die("Error: Cannot create object");
	foreach($xml->update as $update){
		$new_version = $update->version;
		$file_url = $update->file_url;
	}
	if($new_version > $page_load_site_version){
		$notice = "<div class='warning'>A new software update is available</div>";
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="www.w3.org/1999/xhtml">

<head>
<?php require('head.php'); ?>
<?php require('main.css.php'); ?>
</head>

<body>
	<div id="container">
	<!-- Header Start-->
		<?php echo $page_load_header; ?>
		<!-- Header End and Menu Start-->  
		<div id="menu">
			<ul>
				<?php 
					echo $public_links;
					echo $member_links;
					echo $admin_link; 
				?> 
			</ul>
			<?php echo $searchbar; ?>
		<!-- Menu End and Content Start-->
		</div>
		<div id="content">
		<!-- Left content Start-->
			<div id="leftcontent">
			<!-- Navigation Start-->
				<div class="navigation">
					<div class="navhead">Member's Area</div>
					<?php echo $user_panel;?>
				</div>
				
				<!-- Dynamically Generated Panels-->
				<?php echo $page_load_side_panels; ?>
			</div>
			
			<!-- Left content ends and right content starts-->
			
			<div id="rightcontent">
				<div id="breadcrumbs"> <a href="admin.php">Admin</a></div>
				<!-- Post starts here-->
				<center><h1>Admin Panel</h1></center>
				<?php echo $notice; ?>
				<div class="postcontent">
					<center>
						<h2>Core Functions</h2>
						<table border="0">
							<tbody>
							<tr class="rowdark">
								<td width="100" height="100" align="center"><a href="admin_users.php"><img src="./images/icons/user.png"><br>Users</a></td>
								<td width="100" height="100" align="center"><a href="admin_usergroups.php"><img src="./images/icons/usergroup.png"><br>Usergroups</a></td>
								<td width="100" height="100" align="center">
									<?php 
										$query_lockdown = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM site_settings WHERE id='1'"));
										$page_load_site_lockdown = $query_lockdown['lockdown'];
										if($page_load_site_lockdown == 0){
											echo '
												<a href="admin.php?action=lock"><img src="./images/icons/lock_open.png"><br>Lock Site</a>
											';
										}else if($page_load_site_lockdown == 1){
											echo '
												<a href="admin.php?action=unlock"><img src="./images/icons/lock_close.png"><br>Unlock Site</a>
											';
										}
									?>
								</td>
								<td width="100" height="100" align="center">
									<a href="admin_logs.php"><img src="./images/icons/logs.png"><br>Logs
										<?php 
											$query_logs = mysqli_query($con,"SELECT * FROM notifications_admin WHERE marker>'$member_marker_logs'");
											$new_count = mysqli_num_rows($query_logs);
											if($new_count != 0){
												echo "(".$new_count." new)";
											}
										?>
									</a>
								</td>
							</tr>
							<tr class="rowlight">
								
								<td width="100" height="100" align="center"><a href="#"><img src="./images/icons/database.png"><br><font color="red">Database</font></a></td>
								<td width="100" height="100" align="center"><a href="admin_update.php"><img src="./images/icons/update.png"><br>Update</a></td>
								<td width="100" height="100" align="center"><a href="#"><img src="./images/icons/modules.png"><br><font color="red">Modules</font></a></td>
								<td width="100" height="100" align="center"><a href="admin_site_settings.php"><img src="./images/icons/settings.png"><br>Site Settings</a></td>
								
							</tr>
							<tr class="rowdark">
								<td width="100" height="100" align="center"><a href="#"><img src="./images/icons/globe.png"><br><font color="red">Scan Coverage</font></a></td>
								<td width="100" height="100" align="center"><a href="#"><img src="./images/icons/entity.png"><br><font color="red">Entity Bank</font></a></td>
								<td width="100" height="100" align="center"><a href="#"><img src="./images/icons/news.png"><br><font color="red">Newsfeed</font></a></td>
								<td width="100" height="100" align="center"><a href="#"><img src="./images/icons/export.png"><br><font color="red">Exports</font></a></td>
							
							</tr>
							</tbody>
						</table>
					</center>
				</div>
			</div>
			<!-- Right content Ends here-->
		</div>
		
		<!-- Content Ends here and footer started-->
  
		<div class="footclear">&nbsp;</div>
		<?php echo $page_load_footer; ?>
		<!-- footer Ends here-->
	</div>
	<!-- Container Ends here-->
</body>

</html>

<?php mysqli_close($con); ?>
