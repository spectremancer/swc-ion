<?php
	session_start();
	require('connect.php');	
	require('session_load.php');
	require('page_load.php');
	$notice = "";
	
	//Check if account is enabled/disabled
	if($member_id != "" && $query_member['status'] == 0){
		header('Location: index.php?action=Logout&code=1');
	}elseif($member_db_scanner_1 != 1 && $member_db_scanner_2 != 1 && $member_db_scanner_3 != 1){
		header('Location: index.php');
	}
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php require('head.php');?>
<?php require('main.css.php');?>
</head>

<body>
	<div id="container">
	<!-- Header Start-->
		<?php echo $page_load_header; ?>
		<!-- Header End and Menu Start-->  
		<div id="menu">
			<ul>
				<?php 
					echo $public_links;
					echo $member_links;
					echo $admin_link; 
				?> 
			</ul>
			<?php echo $searchbar; ?>
		<!-- Menu End and Content Start-->
		</div>
		<div id="content">
		<!-- Left content Start-->
			<div id="leftcontent">
			<!-- Navigation Start-->
				<div class="navigation">
					<div class="navhead">Member's Area</div>
					<?php echo $user_panel;?>
				</div>
				
				<!-- Dynamically Generated Panels-->
				<?php echo $page_load_side_panels; ?>
			</div>
			
			<!-- Left content ends and right content starts-->
			
			<div id="rightcontent">
				<div id="breadcrumbs"> <a href="db_scanner.php">Scanner Data</a></div>
				<!-- Post starts here-->
				<center><h1>Scanner Data</h1></center>
				<?php echo $notice; ?>
				<div class="postcontent">
					<center>
						<table border="0" class="format_1">
							<tr class="rowdark">
								<?php if($member_clearance >= 1 && $member_db_scanner_2 == 1){ echo "<td width='100' height='100' align='center'><a href='db_scanner_search.php'><img src='./images/icons/scan_data.png'><br>Scan Data</a></td>"; }?>
								<?php if($member_clearance >= 1 && $member_db_scanner_1 == 1){ echo "<td width='100' height='100' align='center'><a href='db_scanner_inventory.php'><img src='./images/icons/inventory_report.png'><br>Inventory Report</a></td>"; }?>
								<?php if($member_clearance >= 1 && $member_db_scanner_1 == 1){ echo "<td width='100' height='100' align='center'><a href='db_scanner_upload.php'><img src='./images/icons/upload_xml.png'><br>Upload XML File</a></td>"; }?>
							</tr>
						</table>
						<br><br>
						<?php
							$total_ships = mysqli_num_rows(mysqli_query($con,"SELECT * FROM tool_entity_records_ship"));
							$total_vehicles = mysqli_num_rows(mysqli_query($con,"SELECT * FROM tool_entity_records_vehicle"));
							$total_stations = mysqli_num_rows(mysqli_query($con,"SELECT * FROM tool_entity_records_station"));
							$total_facilities = mysqli_num_rows(mysqli_query($con,"SELECT * FROM tool_entity_records_facility"));
						?>
						<table border="0">
							<tr>
								<th colspan="2"><u>Collection Statistics</u></th>
							</tr>
							<tr>
								<td width='120' align="left">Ship Records:</td>
								<td width='60' align="right"><?php echo number_format($total_ships); ?></td>
							</tr>
							<tr>
								<td width='120' align="left">Vehicle Records:</td>
								<td width='60' align="right"><?php echo number_format($total_vehicles); ?></td>
							</tr>
							<tr>
								<td width='120' align="left">Station Records:</td>
								<td width='60' align="right"><?php echo number_format($total_stations); ?></td>
							</tr>
							<tr>
								<td width='120' align="left">Facility Records:</td>
								<td width='60' align="right"><?php echo number_format($total_facilities); ?></td>
							</tr>
						</table>
					</center>
				</div>
			</div>
			<!-- Right content Ends here-->
		</div>
		
		<!-- Content Ends here and footer started-->
  
		<div class="footclear">&nbsp;</div>
		<?php echo $page_load_footer; ?>
		<!-- footer Ends here-->
	</div>
	<!-- Container Ends here-->
</body>

</html>

<?php mysqli_close($con); ?>
