<?php

$query_settings = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM site_settings"));

//Site Settings
$page_load_site_title = $query_settings['site_title'];
$page_load_site_subtitle = $query_settings['site_subtitle'];
$page_load_site_name = $query_settings['site_name'];
$page_load_site_banner = $query_settings['site_banner'];
$page_load_site_acronym = $query_settings['site_acronym'];
$page_load_site_footer = $query_settings['site_footer'];
$page_load_site_lockdown = $query_settings['lockdown'];
$page_load_site_version = $query_settings['site_version'];
$page_load_site_results_scanner = $query_settings['results_scanner'];

//Check Lockdown status
if($member_id != "" && $page_load_site_lockdown == 1 && $member_admin == 0 && $member_super_admin == 0){
	header('Location: index.php?action=Logout&code=2');
}

//Module Settings
if($member_handle != "" || $member_id != ""){
	$query_mod_agent_tracker = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM site_modules WHERE id=1"));
		if($query_modules['active'] == 1){
			$mod_agent_tracker = "";
		}else{
			$mod_agent_tracker = "";
		}
	$query_mod_messages = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM site_modules WHERE id=2"));
		if($query_modules['active'] == 1){
			$mod_messages = "
				<li><a href='./messages.php'>Messages</a></li>
			";
		}else{
			$mod_messages = "";
		}
	$query_mod_satnet = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM site_modules WHERE id=3"));
		if($query_modules['active'] == 1){
			$mod_satnet = "";
		}else{
			$mod_satnet = "";
		}
	$query_mod_subscriptions = mysqli_fetch_assoc(mysqli_query($con, "SELECT * FROM site_modules WHERE id=4"));
		if($query_modules['active'] == 1){
			$mod_subscriptions = '
				<div class="navigation">
					<div class="navhead">Account Info</div>
						<center>
						<table class="format_1">
							<tbody>
							<tr class="rowdark">
								<td>Status:</td><td align="center"><font color="green">'.$member_acct_status.'</font></td>
							</tr>
							<tr class="rowlight">
								<td>Credit:</td><td align="center">'.$member_acct_credit.'</td>
							</tr>
							<tr class="rowdark">
								<td>Expires:</td><td align="center">'.$member_expire.'</td>
							</tr>
							<tr class="rowlight">
								<td colspan="2" align="center"><a href="http://www.swcombine.com/members/credits/?receiver=Sha`kage&amount=3000000&communication=Monthly+subscription+to+Cognizance+1.0" target="_blank">Send Payment</a></td>
							</tr>
							<tbody>
						</table>
						</center>
				</div>
			';
		}else{
			$mod_subscriptions = "";
		}
}else{
	$mod_agent_tracker = "";
	$mod_messages = "";
	$mod_satnet = "";
	$mod_subscriptions = "";
}

$page_load_header = '
	<div id="header">
		<div id="headtop"> <img src="./images/clock.gif" alt="SWC DTG" />Year '.$swc_year.' Day '.$swc_day.' '.$swc_hour.':'.$swc_minute.':'.$swc_second.'</div>
		<div id="headbottom" style="background: url('.$page_load_site_banner.') no-repeat;">
			<h1>'.$page_load_site_name.'</h1>
			<h2>'.$page_load_site_subtitle.'</h2>
		</div>
	</div>
';


if($member_handle != "" || $member_id != ""){
//Tool Link
	$member_links = '
		<li><a href="./settings.php">Settings</a></li>
	';
	
//Database Panel
if($member_db_reports_1 == 1 || $member_db_reports_2 == 1 || $member_db_reports_3 == 1 || $member_db_reports_4 == 1){
	$link_reports = '<li><a href="db_reports.php">Reports</a></li>';
}else{
	$link_reports = "";
}

if($member_db_scanner_1 == 1 || $member_db_scanner_2 == 1 || $member_db_scanner_3 == 1){
	$link_scanner = '<li><a href="db_scanner.php">Scanner Data</a></li>';
}else{
	$link_scanner = "";
}

if($member_db_factions_1 == 1 || $member_db_factions_2 == 1){
	$link_factions = '<li><a href="#">Faction Records</a></li>';
}else{
	$link_factions = "";
}

if($member_db_sentients_1 == 1 || $member_db_sentients_2 == 1){
	$link_sentients = '<li><a href="#">Sentient Records</a></li>';
}else{
	$link_sentients = "";
}

$test_string = "".$link_reports."".$link_scanner."".$link_factions."".$link_sentients."";
if($test_string != ""){
	$db_panel = '
		<div class="navigation">
			<div class="navhead">Database</div>
			<ul class="navmenu">
				'.$link_reports.'
				'.$link_scanner.'
				'.$link_factions.'
				'.$link_sentients.'
			</ul>
		</div>
	';
}else{
	$db_panel = "";
}

//Comm Relay Panel
	$notification_cats = "";
	$cats_true = 0;
	if($member_db_reports_1 == 1 || $member_db_reports_2 == 1 || $member_db_reports_3 == 1 || $member_db_reports_4 == 1){if($cats_true == 0){$notification_cats = "(category=4"; $cats_true = 1;}else{$notification_cats = "".$notification_cats." OR category=4"; $cats_true = 1;}}
	if($member_db_scanner_1 == 1 || $member_db_scanner_2 == 1 || $member_db_scanner_3 == 1){if($cats_true == 0){$notification_cats = "(category=6"; $cats_true = 1;}else{$notification_cats = "".$notification_cats." OR category=6"; $cats_true = 1;}}
	if($member_db_factions_1 == 1 || $member_db_factions_2 == 1){if($cats_true == 0){$notification_cats = "(category=9"; $cats_true = 1;}else{$notification_cats = "".$notification_cats." OR category=9"; $cats_true = 1;}}
	if($member_db_sentients_1 == 1 || $member_db_sentients_2 == 1){if($cats_true == 0){$notification_cats = "(category=5"; $cats_true = 1;}else{$notification_cats = "".$notification_cats." OR category=5"; $cats_true = 1;}}
	if($cats_true == 1){$notification_cats = "".$notification_cats.") AND ";}
	
	$query_new_notifications = mysqli_num_rows(mysqli_query($con,"SELECT * FROM notifications_members WHERE ".$notification_cats." clearance<='$member_clearance' AND marker>'$member_marker_notifications'"));
	if($query_new_notifications != 0){
		$comm_panel = '	
			<div class="navigation"> <!--This shows only upon login-->
				<div class="navhead">Comm Relay</div>
				<ul class="navmenu">
					'.$mod_messages.'
					<li><a href="notifications.php" title="'.$query_new_notifications.' new notifications" style="color:yellow;">Notifications</a></li>
				</ul>
			</div>
		';
	}else{
		$comm_panel = '	
			<div class="navigation"> <!--This shows only upon login-->
				<div class="navhead">Comm Relay</div>
				<ul class="navmenu">
					'.$mod_messages.'
					<li><a href="notifications.php" title="No new notifications">Notifications</a></li>
				</ul>
			</div>
		';
	}

}else{
	$member_links = "";
	$db_panel = "";
	$comm_panel = "";
}

//Merge Panels
$page_load_side_panels = "
	".$db_panel."
	".$comm_panel."
	".$mod_subscriptions."
";

//Searchbar
$searchbar = '
	<div class="search">
		<form method="post" action="#">
			<input class="inputbutton" type="button" value="Search" />
			<input class="inputtext" type="text" size="15" />
		</form>	
	</div>
';

//Admin Link
if($member_admin == 1 || $member_super_admin == 1){$admin_link = '<li><a href="./admin.php">Admin</a></li>';}else{$admin_link = "";}

//Public Links
$public_links = '
	<li><a href="./index.php">Index</a></li>
';

//User Panel
if($member_handle == "" || $member_id == ""){
	$user_panel = '
		<form class="loginform" method="post" action="./index.php">
			<label>User ID</label>
			<input name="input_username" value="" type="text" size="15" />
			<label>Password</label>
			<input name="input_password" value="" type="password" size="15" />
			<br />
			<center><input class="button" name="submit" type="submit" value="Submit" /></center>
		</form>
	';
}else{
	$user_panel = '
		<center>
		<table class="format_1">
			<tbody>
			<tr class="rowdark">
				<td>User:</td><td align="center">'.$member_handle.'</td>
			</tr>
			<tr class="rowlight">
				<td>Group:</td><td align="center">'.$member_usergroup.'</td>
			</tr>
			<tr class="rowdark">
				<td>IP:</td><td align="center">'.$_SERVER['REMOTE_ADDR'].'</td>
			</tr>
			<tbody>
		</table>
		</center>								
		
		<form class="foorm" name="form_logout" method="get" action="./index.php">
		<center><input class="button" type="submit" name="action" value="Logout"><input type="hidden" name="code" value="0"></center>
		</form>
	';
}

//Footer
$page_load_footer = '
		<div id="footer">
			<h2>'.$page_load_site_footer.'Version '.$page_load_site_version.'</h2>
		</div>
';
?>
