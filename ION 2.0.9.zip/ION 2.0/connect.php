<?php

/* DATABASE CONNECT */
	$db_host = "localhost";
	$db_username = "ftc_admin";
	$db_pass = "123Xep624";
	$db_name = "cognizance";

	$con = mysqli_connect($db_host, $db_username, $db_pass, $db_name) or die(mysqli_error());
?>
