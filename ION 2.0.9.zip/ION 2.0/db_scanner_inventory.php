<?php
	session_start();
	require('connect.php');	
	require('session_load.php');
	require('page_load.php');
	$notice = "";
	
	//Check if account is enabled/disabled
	if($member_id != "" && $query_member['status'] == 0){
		header('Location: index.php?action=Logout&code=1');
	}elseif($member_db_scanner_2 != 1 && $member_db_scanner_3 != 1){
		header('Location: index.php');
	}
	
	if($_GET){
		$search_from = mysqli_real_escape_string($con,$_GET['search_from']);
		if($search_from == ""){$search_from = 0;}
		$search_to = mysqli_real_escape_string($con,$_GET['search_to']);
		if($search_to == ""){$search_to = 99999;}
		$search_owner = mysqli_real_escape_string($con,$_GET['search_owner']);
		$search_reason = mysqli_real_escape_string($con,$_GET['search_reason']);
		if($search_reason == "" && $member_admin != 1){
			$notice = "<div class='error'>You must submit a reason for the query</div>";
		}else{
			if($search_owner == ""){
				$notice = "<div class='error'>The \"Owner\" field cannot be blank</div>";
			}else{
				$notice = "<div class='confirm'>Displaying inventory report for \"".$search_owner."\"</div>";
			}
			if($search_reason == "" && $member_admin == 1){
				$search_reason = "[No reason provided]";
			}
		}
		
	}else{
		$search_from = "0";
		$search_to = "99999";
		$search_owner = "";
		$search_reason = "";
	}
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php require('head.php');?>
<?php require('main.css.php');?>
</head>

<body>
	<div id="container">
	<!-- Header Start-->
		<?php echo $page_load_header; ?>
		<!-- Header End and Menu Start-->  
		<div id="menu">
			<ul>
				<?php 
					echo $public_links;
					echo $member_links;
					echo $admin_link; 
				?> 
			</ul>
			<?php echo $searchbar; ?>
		<!-- Menu End and Content Start-->
		</div>
		<div id="content">
		<!-- Left content Start-->
			<div id="leftcontent">
			<!-- Navigation Start-->
				<div class="navigation">
					<div class="navhead">Member's Area</div>
					<?php echo $user_panel;?>
				</div>
				
				<!-- Dynamically Generated Panels-->
				<?php echo $page_load_side_panels; ?>
			</div>
			
			<!-- Left content ends and right content starts-->
			
			<div id="rightcontent">
				<div id="breadcrumbs"> <a href="db_scanner.php">Scanner Data</a> -> <a href="db_scanner_inventory.php">Run Inventory Report</a></div>
				<!-- Post starts here-->
				<center><h1>Run Inventory Report</h1></center>
				<?php echo $notice; ?>
				<div class="postcontent">
					<center>
						<br><br>
						<form action="db_scanner_inventory.php" method="get">
						<table border="0" class="format_1">
							<tr>
								<td width='75' style="color:white;">From Date:</td>
								<td width='75'><input type="text" name="search_from" style="width:75px;" value="" placeholder="YYDDD"></td>
								<td width='75' style="color:white;">To Date:</td>
								<td width='75'><input type="text" name="search_to" style="width:75px;" value="" placeholder="YYDDD"></td>						
							</tr>
							<tr>
								<td width='75' style="color:white;">Owner: <font color="red">*</font></td>
								<td width='225' colspan="3"><input type="text" name="search_owner" style="width:225px;" value="<?php echo $search_owner;?>" placeholder="(Required)"></td>
							</tr>
							<tr>
								<td width='75' style="color:white;">Reason: <font color="red">*</font></td>
								<td width='225' colspan="3"><input type="text" name="search_reason" style="width:225px;" value="<?php echo $search_reason;?>" placeholder="(Required)"></td>
							</tr>
							<tr>
								<td colspan="4" align="center"><input type="submit" name="search_submit" value="Run" style="width:100px;height:20px;"></td>
							</tr>
						</table>
						</form>
						<br><br><br><br>
						
						<?php
						if($search_owner != "" && ($search_reason != "" || $member_admin == 1)){
							
								echo "<h2>Results for ".$search_owner."</h2><br><br>";
								echo "<table class='format_1'><tr><th colspan='2' style='width:500px;'>Ships</th></tr>";
								$query_types = mysqli_query($con,"SELECT * FROM tool_entity_types WHERE type_category='ship'");
								while($row = mysqli_fetch_assoc($query_types)){
									$type_name = $row['type_name'];
									$query_data = mysqli_num_rows(mysqli_query($con,"SELECT * FROM tool_entity_records_ship WHERE owner='$search_owner' AND type='$type_name' AND date>'$search_from' AND date<'$search_to' AND clearance<='$member_clearance'"));
									if($query_data != 0){
										echo "<tr><td style='width:350px;' align='left'><a href='db_scanner_search.php?action=1&search_owner=".urlencode($search_owner)."&search_type=".urlencode($type_name)."&search_from=".$search_from."&search_to=".$search_to."'>".$type_name."</a></td><td style='width:150px;color:white;' align='left'>".$query_data."</td></tr>";
									}
								}
								echo "</table><br><br>";
								
								echo "<table class='format_1'><tr><th colspan='2' style='width:500px;'>Vehicles</th></tr>";
								$query_types = mysqli_query($con,"SELECT * FROM tool_entity_types WHERE type_category='vehicle'");
								while($row = mysqli_fetch_assoc($query_types)){
									$type_name = $row['type_name'];
									$query_data = mysqli_num_rows(mysqli_query($con,"SELECT * FROM tool_entity_records_vehicle WHERE owner='$search_owner' AND type='$type_name' AND date>'$search_from' AND date<'$search_to' AND clearance<='$member_clearance'"));
									if($query_data != 0){
										echo "<tr><td style='width:350px;' align='left'><a href='db_scanner_search.php?action=1&search_owner=".urlencode($search_owner)."&search_type=".urlencode($type_name)."&search_from=".$search_from."&search_to=".$search_to."'>".$type_name."</a></td><td style='width:150px;color:white;' align='left'>".$query_data."</td></tr>";
									}
								}
								echo "</table><br><br>";
								
								echo "<table class='format_1'><tr><th colspan='2' style='width:500px;'>Stations</th></tr>";
								$query_types = mysqli_query($con,"SELECT * FROM tool_entity_types WHERE type_category='station'");
								while($row = mysqli_fetch_assoc($query_types)){
									$type_name = $row['type_name'];
									$query_data = mysqli_num_rows(mysqli_query($con,"SELECT * FROM tool_entity_records_station WHERE owner='$search_owner' AND type='$type_name' AND date>'$search_from' AND date<'$search_to' AND clearance<='$member_clearance'"));
									if($query_data != 0){
										echo "<tr><td style='width:350px;' align='left'><a href='db_scanner_search.php?action=1&search_owner=".urlencode($search_owner)."&search_type=".urlencode($type_name)."&search_from=".$search_from."&search_to=".$search_to."'>".$type_name."</a></td><td style='width:150px;color:white;' align='left'>".$query_data."</td></tr>";
									}
								}
								echo "</table><br><br>";
								
								echo "<table class='format_1'><tr><th colspan='2' style='width:500px;'>Facilities</th></tr>";
								$query_types = mysqli_query($con,"SELECT * FROM tool_entity_types WHERE type_category='facility'");
								while($row = mysqli_fetch_assoc($query_types)){
									$type_name = $row['type_name'];
									$query_data = mysqli_num_rows(mysqli_query($con,"SELECT * FROM tool_entity_records_facility WHERE owner='$search_owner' AND type='$type_name' AND date>'$search_from' AND date<'$search_to' AND clearance<='$member_clearance'"));
									if($query_data != 0){
										echo "<tr><td style='width:350px;' align='left'><a href='db_scanner_search.php?action=1&search_owner=".urlencode($search_owner)."&search_type=".urlencode($type_name)."&search_from=".$search_from."&search_to=".$search_to."'>".$type_name."</a></td><td style='width:150px;color:white;' align='left'>".$query_data."</td></tr>";
									}
								}
								echo "</table>";
								
								$marker = time();
								$notification = "The user <font color='blue'>".$member_handle."</font> ran an inventory report for <font color='blue'>".$search_owner."</font> between the dates ".$search_from." and ".$search_to.".<br><br>Reason: ".$search_reason."";
								$notification = mysqli_real_escape_string($con,$notification);
								mysqli_query($con,"INSERT INTO notifications_admin VALUES ('','$notification','2','$swc_date_time','$marker')");
						}
						?>
					</center>
				</div>
			</div>
			<!-- Right content Ends here-->
		</div>
		
		<!-- Content Ends here and footer started-->
  
		<div class="footclear">&nbsp;</div>
		<?php echo $page_load_footer; ?>
		<!-- footer Ends here-->
	</div>
	<!-- Container Ends here-->
</body>

</html>

<?php mysqli_close($con); ?>
