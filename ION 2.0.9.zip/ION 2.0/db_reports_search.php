<?php
	session_start();
	require('connect.php');	
	require('session_load.php');
	require('page_load.php');
	$notice = "";
	if($_GET['action']){
		if($_GET['action'] == 1){
			$notice = "<div class='confirm'>The report has been submitted.</div>";
		}
	}
	
	//Check if account is enabled/disabled
	if($member_id != "" && $query_member['status'] == 0){
		header('Location: index.php?action=Logout&code=1');
	}elseif($member_db_reports_1 != 1 && $member_db_reports_2 != 1 && $member_db_reports_3 != 1){
		header('Location: index.php');
	}
	
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php require('head.php');?>
<?php require('main.css.php');?>
</head>

<body>
	<div id="container">
	<!-- Header Start-->
		<?php echo $page_load_header; ?>
		<!-- Header End and Menu Start-->  
		<div id="menu">
			<ul>
				<?php 
					echo $public_links;
					echo $member_links;
					echo $admin_link; 
				?> 
			</ul>
			<?php echo $searchbar; ?>
		<!-- Menu End and Content Start-->
		</div>
		<div id="content">
		<!-- Left content Start-->
			<div id="leftcontent">
			<!-- Navigation Start-->
				<div class="navigation">
					<div class="navhead">Member's Area</div>
					<?php echo $user_panel;?>
				</div>
				
				<!-- Dynamically Generated Panels-->
				<?php echo $page_load_side_panels; ?>
			</div>
			
			<!-- Left content ends and right content starts-->
			
			<div id="rightcontent">
				<div id="breadcrumbs"> <a href="db_reports.php">Reports</a> -> <a href="db_reports_search.php">Search Reports</a></div>
				<!-- Post starts here-->
				<center><h1>Search Reports</h1></center>
				<?php echo $notice; ?>
				<div class="postcontent">
					<center>
						<form action="db_reports_search.php" method="get">
						<table border="0"><tr><td width="100" style="color:white;">Search:</td><td width="400"><input type="text" name="search_reports" style="width:395px;" value="<?php if($_POST['search_reports']){echo $_POST['search_reports'];}?>"></td><td width="100"><input type="submit" name="search_submit" value="Submit"></td></tr></table>
						</form>
						
						<?php 
						if($_GET['search_reports'] != ""){
							$search_reports = mysqli_real_escape_string($con,$_GET['search_reports']);
							$query_final = "SELECT * FROM tool_reports WHERE ((subject LIKE '%$search_reports%') OR (content LIKE '%$search_reports%') OR (report_serial LIKE '%$search_reports%') OR (task_serial LIKE '%$search_reports%') OR (date LIKE '%$search_reports%') OR (time LIKE '%$search_reports%')) AND (clearance<='$member_clearance' OR member_id='$member_id') ORDER BY date DESC, time DESC";
						}else{
							$search_reports = "";
							$query_final = "SELECT * FROM tool_reports WHERE  (clearance<='$member_clearance' OR member_id='$member_id') ORDER BY date DESC, time DESC";				
						}
						if(mysqli_num_rows(mysqli_query($con,$query_final)) != 0){
							
							if(isset($_GET['page'])){
								$page = mysqli_real_escape_string($con,$_GET['page']);
							}else{
								$page = 1;
							}
							$current_page = intval($page);
							
							//GENERATE PAGE LINKS
							$query_number = mysqli_num_rows(mysqli_query($con,$query_final));
							$per_page = 50;
							$pages = ceil($query_number/$per_page);
							if($page > $pages){$current_page = $pages;}elseif($page < 1){$current_page = 1;}
							$start = abs(($current_page-1)*$per_page);

							$query_string = "".$query_final." LIMIT ".$start.",".$per_page."";
							$query_results = mysqli_query($con,$query_string);
								
							//PAGINATION TOP
							if($query_number > $per_page){
								echo "
									<div style='width:600px;'>
									<table border='1' cellspacing='0' cellpadding='5' style='background-color:#555555;color:white;'>
										<tr>
											<td align='center' width='100' height='25' style='border:1px solid black;'>
								";
								if($current_page > 1){
									$page_subtract = $current_page - 1;
									echo "<a href='db_reports_search.php?page=".$page_subtract."&search_reports=".$search_reports."' style='color:#9999ff;'>Back</a>";
								}
								echo "
									</td>
									<td align='center' width='400' height='25' style='border:1px solid black;'>
								";
								
								if($pages <= 20){
									$current_page_count = 1;
									while($current_page_count <= $pages){
										if($current_page_count == $current_page){
											echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
										}else{
											echo "<span style='margin-right:5px;'><a href='db_reports_search.php?page=".$current_page_count."&search_reports=".$search_reports."' style='color:#9999ff;'>".$current_page_count."</a></span>";
										}
										$current_page_count++;
									}
									echo "
										</td>
										<td align='center' width='100' height='25' style='border:1px solid black;'>
									";
									if($current_page < ($current_page_count - 1)){
										$page_add = $current_page + 1;
										echo "<a href='db_reports_search.php?page=".$page_add."&search_reports=".$search_reports."' style='color:#9999ff;'>Next</a>";
									}
									echo "
										</td>
										</tr>
										</table></div><br><br>
									";
								}else{
									if($current_page >= 9){
										$count_initial = 1;
										while($count_initial <= 3){
											echo "<span style='margin-right:5px;'><a href='db_reports_search.php?page=".$count_initial."&search_reports=".$search_reports."' style='color:#9999ff;'>".$count_initial."</a></span>";
											$count_initial++; //page=".$current_initial."
										}
										echo "... ";
									}
									if($current_page == 7){$modifier = 6;}elseif($current_page == 8){$modifier = 7;}else{$modifier = 5;}
									if($current_page > 6){$current_page_count = $current_page - $modifier;}else{$current_page_count = 1;}
									if($current_page >= 1 && $current_page <= 9){
										while($current_page_count <= 15){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='db_reports_search.php?page=".$current_page_count."&search_reports=".$search_reports."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}elseif($current_page >= $pages - 7){
										$current_page_count = $pages - 12;
										while($current_page_count <= $pages){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='db_reports_search.php?page=".$current_page_count."&search_reports=".$search_reports."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}else{
										while($current_page_count <= ($current_page + 5)){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='db_reports_search.php?page=".$current_page_count."&search_reports=".$search_reports."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}
									if($current_page < ($pages - 7)){
										echo " ...";
										$count_final = $pages - 2;
										while($count_final <= $pages){
											echo "<span style='margin-right:5px;'><a href='db_reports_search.php?page=".$count_final."&search_reports=".$search_reports."' style='color:#9999ff;'>".$count_final."</a></span>";
											$count_final++;
										}
									}
									echo "
										</td>
										<td align='center' width='100' height='25' style='border:1px solid black;'>
									";
									if($current_page < ($current_page_count - 1)){
										$page_add = $current_page + 1;
										echo "<a href='db_reports_search.php?page=".$page_add."&search_reports=".$search_reports."' style='color:#9999ff;'>Next</a>";
									}
									echo "
										</td>
										</tr>
										</table></div><br><br>
									";
								}
							}
							
							echo "
								<table border='1' class='format_1'>
									<tbody>
									<tr>
										<th width='25'>#</th>
										<th width='175'>Serial</th>
										<th width='400'>Subject</th>
									</tr>
							";
							$row_color = "rowdark";
							$count = $start + 1;
							while($row = mysqli_fetch_assoc($query_results)){
								echo "
									<tr class=".$row_color.">
										<td align='center'>".$count."</td>
										<td align='left'><a href='db_reports_view.php?report_serial=".$row['report_serial']."'>".$row['report_serial']."</a></td>
										<td align='left'><a href='db_reports_view.php?report_serial=".$row['report_serial']."'>".$row['subject']."</a></td>
									</tr>
								";
								if($row_color == "rowdark"){
									$row_color = "rowlight";
								}else{
									$row_color = "rowdark";
								}
								$count++;
							}
							echo "
									</tbody>
								</table>
							";
							
							//PAGINATION BOTTOM
							if($query_number > $per_page){
								echo "
									<br><br>
									<div style='width:600px;'>
									<table border='1' cellspacing='0' cellpadding='5' style='background-color:#555555;color:white;'>
										<tr>
											<td align='center' width='100' height='25' style='border:1px solid black;'>
								";
								if($current_page > 1){
									$page_subtract = $current_page - 1;
									echo "<a href='db_reports_search.php?page=".$page_subtract."&search_reports=".$search_reports."' style='color:#9999ff;'>Back</a>";
								}
								echo "
									</td>
									<td align='center' width='400' height='25' style='border:1px solid black;'>
								";
								
								if($pages <= 20){
									$current_page_count = 1;
									while($current_page_count <= $pages){
										if($current_page_count == $current_page){
											echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
										}else{
											echo "<span style='margin-right:5px;'><a href='db_reports_search.php?page=".$current_page_count."&search_reports=".$search_reports."' style='color:#9999ff;'>".$current_page_count."</a></span>";
										}
										$current_page_count++;
									}
									echo "
										</td>
										<td align='center' width='100' height='25' style='border:1px solid black;'>
									";
									if($current_page < ($current_page_count - 1)){
										$page_add = $current_page + 1;
										echo "<a href='db_reports_search.php?page=".$page_add."&search_reports=".$search_reports."' style='color:#9999ff;'>Next</a>";
									}
									echo "
										</td>
										</tr>
										</table></div><br><br>
									";
								}else{
									if($current_page >= 9){
										$count_initial = 1;
										while($count_initial <= 3){
											echo "<span style='margin-right:5px;'><a href='db_reports_search.php?page=".$current_count."&search_reports=".$search_reports."' style='color:#9999ff;'>".$count_initial."</a></span>";
											$count_initial++;
										}
										echo "... ";
									}
									if($current_page == 7){$modifier = 6;}elseif($current_page == 8){$modifier = 7;}else{$modifier = 5;}
									if($current_page > 6){$current_page_count = $current_page - $modifier;}else{$current_page_count = 1;}
									if($current_page >= 1 && $current_page <= 9){
										while($current_page_count <= 15){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='db_reports_search.php?page=".$current_page_count."&search_reports=".$search_reports."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}elseif($current_page >= $pages - 7){
										$current_page_count = $pages - 12;
										while($current_page_count <= $pages){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='db_reports_search.php?page=".$current_page_count."&search_reports=".$search_reports."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}else{
										while($current_page_count <= ($current_page + 5)){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='db_reports_search.php?page=".$current_page_count."&search_reports=".$search_reports."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}
									if($current_page < ($pages - 7)){
										echo " ...";
										$count_final = $pages - 2;
										while($count_final <= $pages){
											echo "<span style='margin-right:5px;'><a href='db_reports_search.php?page=".$count_final."&search_reports=".$search_reports."' style='color:#9999ff;'>".$count_final."</a></span>";
											$count_final++;
										}
									}
									echo "
										</td>
										<td align='center' width='100' height='25' style='border:1px solid black;'>
									";
									if($current_page < ($current_page_count - 1)){
										$page_add = $current_page + 1;
										echo "<a href='db_reports_search.php?page=".$page_add."&search_reports=".$search_reports."' style='color:#9999ff;'>Next</a>";
									}
									echo "
										</td>
										</tr>
										</table></div><br><br>
									";
								}
							}
							
						}else{
							echo "There are no reports to display.";
						}
					?>
					</center>
				</div>
			</div>
			<!-- Right content Ends here-->
		</div>
		
		<!-- Content Ends here and footer started-->
  
		<div class="footclear">&nbsp;</div>
		<?php echo $page_load_footer; ?>
		<!-- footer Ends here-->
	</div>
	<!-- Container Ends here-->
</body>

</html>

<?php mysqli_close($con); ?>
