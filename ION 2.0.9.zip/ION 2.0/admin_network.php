<?php
	session_start();
	require('connect.php');	
	require('session_load.php');
	require('page_load.php');
	$notice = "";
	if($member_admin != 1 && $member_super_admin != 1){
		header('Location: index.php');
	}
	//Check if account is enabled/disabled
	if($member_id != "" && $query_member['status'] == 0){
		header('Location: index.php?action=Logout&code=1');
	}
	
	if($_POST['add_node']){
		$node_name = mysqli_real_escape_string($con,trim($_POST['node_name']));
		$node_url = mysqli_real_escape_string($con,trim($_POST['node_url']));
		if($node_name != "" && $node_url != ""){
			if(filter_var($node_url, FILTER_VALIDATE_URL) == True){
				mysqli_query($con,"INSERT INTO site_network VALUES ('','$node_name','$node_url')");
				$marker = time();
				$notification = "The network node <font color='blue'>".$node_name."</font> has been added by <font color='blue'>".$member_handle."</font>.";
				$notification = mysqli_real_escape_string($con,$notification);
				mysqli_query($con,"INSERT INTO notifications_admin VALUES ('','$notification','8','$swc_date_time','$marker')");
				$notice = "<div class='confirm'>The node \"".$node_name."\" has been added</div>";
			}else{
				$notice = "<div class='error'>You have submitted an invalid url. Try again.</div>";
			}
		}else{
			$notice = "<div class='error'>You must submit both a name and a url to add a network node</div>";
		}
	}
	
	if($_GET['delete']){
		$node_id = mysqli_real_escape_string($con,$_GET['delete']);
		$node_name = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM site_network WHERE id='$node_id'"));
		$node_name = $node_name['name'];
		if($_GET['confirm'] == 0){
			$notice = "<div class='warning'>Are you sure you want to delete this node? <a href='admin_network.php?delete=".$node_id."&confirm=1'>[Yes]</a> - <a href='admin_network.php'>[No]</a></div>";
		}elseif($_GET['confirm'] == 1){
			$marker = time();
			$notification = "The network node <font color='blue'>".$node_name."</font> has been deleted by <font color='blue'>".$member_handle."</font>.";
			$notification = mysqli_real_escape_string($con,$notification);
			mysqli_query($con,"INSERT INTO notifications_admin VALUES ('','$notification','8','$swc_date_time','$marker')");
			mysqli_query($con,"DELETE FROM site_network WHERE id='$node_id'");
			$notice = "<div class='error'>The node \"".$node_name."\" has been deleted</div>";
		}
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php require('head.php'); ?>
<?php require('main.css.php'); ?>
</head>

<body>
	<div id="container">
	<!-- Header Start-->
		<?php echo $page_load_header; ?>
		<!-- Header End and Menu Start-->  
		<div id="menu">
			<ul>
				<?php 
					echo $public_links;
					echo $member_links;
					echo $admin_link; 
				?> 
			</ul>
			<?php echo $searchbar; ?>
		<!-- Menu End and Content Start-->
		</div>
		<div id="content">
		<!-- Left content Start-->
			<div id="leftcontent">
			<!-- Navigation Start-->
				<div class="navigation">
					<div class="navhead">Member's Area</div>
					<?php echo $user_panel; ?>						
				</div>
				
				<!-- Dynamically Generated Panels-->
				<?php echo $page_load_side_panels; ?>
			</div>
			
			<!-- Left content ends and right content starts-->
			
			<div id="rightcontent">
				<div id="breadcrumbs"> <a href="admin.php">Admin</a> -> <a href="admin_network.php">Network</a></div>
				<!-- Post starts here-->
				<center><h1>Network</h1></center>
				<?php echo $notice; ?>
				<div class="postcontent">
					<center>
					<a href="admin_network_add.php">[Add Network Node]</a><br><br>
					<table border="0" class="format_1">
						<tr>
							<th style="border:1px solid white;width:190px;" align="center">Node Name</th>
							<th style="border:1px solid white;width:300px;" align="center">Node URL</th>
							<th style="border:1px solid white;width:90px;" align="center">Connection</th>
							<th style="border:1px solid white;width:70px;" align="center">Action</th>
						</tr>
						<?php
							$query_network = mysqli_query($con,"SELECT * FROM site_network ORDER BY name");
							if(mysqli_num_rows($query_network) != 0){
								while($row = mysqli_fetch_assoc($query_network)){
									$version = "";
									$lockdown = "";
									echo "<tr><td style='color:white;'>".$row['name']."</td><td style='color:white;'>".$row['url']."</td><td align='center'>";
									
									$url = "".$row['url']."/api.php";
									$xml = simplexml_load_file($url);
									foreach($xml->vars as $vars){
										$version = trim($vars->version);
										$lockdown = $vars->lockdown;
									}
									if($version != "" && $lockdown == 0){
										echo "<font color='green'><b>Success</b></font>";
									}elseif($version != "" && $lockdown == 1){
										echo "<font color='yellow'><b>Locked</b></font>";
									}else{
										echo "<font color='red'><b>Failed</b></font>";
									}
									echo "</td><td align='center'><a href='admin_network.php?delete=".$row['id']."&confirm=0'>[Delete]</a></td></tr>";
								}
							}else{
								echo "<tr><td align='center' colspan='4'><font color='red'>There aren't any network nodes to display</font></td></tr>";
							}
						?>
					</table>
					</center>
				</div>
			</div>
			<!-- Right content Ends here-->
		</div>
		
		<!-- Content Ends here and footer started-->
  
		<div class="footclear">&nbsp;</div>
		<?php echo $page_load_footer; ?>
		<!-- footer Ends here-->
	</div>
	<!-- Container Ends here-->
</body>

</html>

<?php mysqli_close($con); ?>
