<?php
	session_start();
	require('connect.php');	
	
	mysqli_query($con,"
	ALTER TABLE `members_usergroups` ADD `db_comms_1` ENUM('0','1') NOT NULL DEFAULT '0';
	ALTER TABLE `members_usergroups` ADD `db_comms_2` ENUM('0','1') NOT NULL DEFAULT '0';
	ALTER TABLE `members_usergroups` ADD `db_comms_3` ENUM('0','1') NOT NULL DEFAULT '0';
	ALTER TABLE `members_usergroups` DROP COLUMN `db_comms`;
");
	
	require('session_load.php');
	require('page_load.php');
	$notice = "";
	if($member_admin != 1 && $member_super_admin != 1){
		header('Location: index.php');
	}
	//Check if account is enabled/disabled
	if($member_id != "" && $query_member['status'] == 0){
		header('Location: index.php?action=Logout&code=1');
	}
	
	if($_POST['add_submit']){
		$usergroup = mysqli_real_escape_string($con,$_POST['add_usergroup']);
		$access_admin = mysqli_real_escape_string($con,$_POST['access_admin']);
		if($access_admin != 1){
			$access_admin = 0;
		}
		$access_clearance = mysqli_real_escape_string($con,$_POST['access_clearance']);
		$access_reports_1 = mysqli_real_escape_string($con,$_POST['access_reports_1']);
		$access_reports_2 = mysqli_real_escape_string($con,$_POST['access_reports_2']);
		$access_reports_3 = mysqli_real_escape_string($con,$_POST['access_reports_3']);
		$access_reports_4 = mysqli_real_escape_string($con,$_POST['access_reports_4']);
		$access_reports_5 = mysqli_real_escape_string($con,$_POST['access_reports_5']);
		$access_scanner_1 = mysqli_real_escape_string($con,$_POST['access_scanner_1']);
		$access_scanner_2 = mysqli_real_escape_string($con,$_POST['access_scanner_2']);
		$access_scanner_3 = mysqli_real_escape_string($con,$_POST['access_scanner_3']);
		$access_scanner_4 = mysqli_real_escape_string($con,$_POST['access_scanner_4']);
		$access_factions_1 = mysqli_real_escape_string($con,$_POST['access_factions_1']);
		$access_factions_2 = mysqli_real_escape_string($con,$_POST['access_factions_2']);
		$access_factions_3 = mysqli_real_escape_string($con,$_POST['access_factions_3']);
		$access_factions_4 = mysqli_real_escape_string($con,$_POST['access_factions_4']);
		$access_sentients_1 = mysqli_real_escape_string($con,$_POST['access_sentients_1']);
		$access_sentients_2 = mysqli_real_escape_string($con,$_POST['access_sentients_2']);
		$access_sentients_3 = mysqli_real_escape_string($con,$_POST['access_sentients_3']);
		$access_sentients_4 = mysqli_real_escape_string($con,$_POST['access_sentients_4']);
		if($usergroup != ""){
			$query_usergroups = mysqli_num_rows(mysqli_query($con,"SELECT * FROM members_usergroups WHERE name='$usergroup'"));
			if($query_usergroups == 0){
				$marker = time();
				$notification = "The usergroup <font color='blue'>".$usergroup."</font> has been added by <font color='blue'>".$member_handle."</font> with a clearance level of ".$access_clearance.".";
					if($access_admin == 1){
						$notification = "".$notification." Admin Access Granted. ";
					}
					if($access_reports_1 == 1 || $access_reports_2 == 1 || $access_reports_3 == 1 || $access_reports_4 == 1 || $access_reports_5 == 1){
						$notification = "".$notification." Reports Access Granted. ";
					}
					if($access_scanner_1 == 1 || $access_scanner_2 == 1 || $access_scanner_3 == 1 || $access_scanner_4 == 1){
						$notification = "".$notification." Scanner Access Granted. ";
					}
					if($access_factions_1 == 1 || $access_factions_2 == 1 || $access_factions_3 == 1 || $access_factions_4 == 1){
						$notification = "".$notification." Faction Profiles Access Granted. ";
					}
					if($access_sentients_1 == 1 || $access_sentients_2 == 1 || $access_sentients_3 == 1 || $access_sentients_4 == 1){
						$notification = "".$notification." Sentient Profiles Access Granted. ";
					}
				$notification = mysqli_real_escape_string($con,$notification);
				mysqli_query($con,"INSERT INTO notifications_admin VALUES ('','$notification','1','$swc_date_time','$marker')");
				mysqli_query($con,"INSERT INTO members_usergroups VALUES ('','$usergroup','$access_admin','$access_clearance','$access_reports_1','$access_reports_2','$access_reports_3','$access_reports_4','$access_reports_5',
				'$access_scanner_1','$access_scanner_2','$access_scanner_3','$access_scanner_4','$access_factions_1','$access_factions_2','$access_factions_3','$access_factions_4','$access_sentients_1','$access_sentients_2,'$access_sentients_3,'$access_sentients_4')");
				$notice = "<div class='confirm'>The usergroup <font color='blue'>".$usergroup."</font> has been added.</div>";
			}else{
				$notice = "<div class='error'>A usergroup already exists with that name.</div>";
			}
		}else{
			$notice = "<div class='error'>You must enter a name for the new usergroup.</div>";
		}
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php require('head.php'); ?>
<?php require('main.css.php'); ?>
</head>

<body>
	<div id="container">
	<!-- Header Start-->
		<?php echo $page_load_header; ?>
		<!-- Header End and Menu Start-->  
		<div id="menu">
			<ul>
				<?php 
					echo $public_links;
					echo $member_links;
					echo $admin_link; 
				?> 
			</ul>
			<?php echo $searchbar; ?>
		<!-- Menu End and Content Start-->
		</div>
		<div id="content">
		<!-- Left content Start-->
			<div id="leftcontent">
			<!-- Navigation Start-->
				<div class="navigation">
					<div class="navhead">Member's Area</div>
					<?php echo $user_panel; ?>						
				</div>
				
				<!-- Dynamically Generated Panels-->
				<?php echo $page_load_side_panels; ?>
			</div>
			
			<!-- Left content ends and right content starts-->
			
			<div id="rightcontent">
				<div id="breadcrumbs"> <a href="admin.php">Admin</a> -> <a href="admin_usergroups.php">Usergroups</a> -> <a href="admin_usergroups_add.php">Add Usergroup</a></div>
				<!-- Post starts here-->
				<center><h1>Add Usergroup</h1></center>
				<?php echo $notice; ?>
				<div class="postcontent">
					<center>
					<form class="foorm" method="post" action="admin_usergroups_add.php">
					<table>
						<tr>
							<td align="left">Name: <font color="red">* </font></td>
							<td align="center"><input type="text" name="add_usergroup" value=""></td>
						</tr>
					</table>
					<br /><br />
					<table>
						<tr>
							<td align="left">Admin Access: </td>
							<td align="center" width="150"><input type="checkbox" name="access_admin" value="1"></td>
						</tr>
						<tr>
							<td align="left">Clearance Level: </td>
							<td align="center" width="150"><select name="access_clearance">
								<option value="0" SELECTED>Level 0</option>
								<option value="1">Level 1</option>
								<option value="2">Level 2</option>
								<option value="3">Level 3</option>
								<option value="4">Level 4</option>
								<option value="5">Level 5</option>
							</select></td>
						</tr>
					</table>
					<br /><br />
					<table border="1" class="format_1" style="color:white;">
						<tr>
							<th colspan="6" align="center">Databases</th>
						</tr>
						<tr>
							<td align="left" style="color:white;">Reports</td>
							<td align="center" style="color:yellow;width:120;">Add<br><input type="checkbox" name="access_reports_1" value="1"></td>
							<td align="center" style="color:yellow;width:120;">Query<br><input type="checkbox" name="access_reports_2" value="1"></td>
							<td align="center" style="color:yellow;width:120;">Edit<br><input type="checkbox" name="access_reports_3" value="1"></td>
							<td align="center" style="color:yellow;width:120;">Export<br><input type="checkbox" name="access_reports_4" value="1"></td>
							<td align="center" style="color:yellow;width:120;">Task<br><input type="checkbox" name="access_reports_5" value="1"></td>
						</tr>
						<tr>
							<td align="left" style="color:white;">Scanner Data</td>
							<td align="center" style="color:yellow;width:120;">Add<br><input type="checkbox" name="access_scanner_1" value="1"></td>
							<td align="center" style="color:yellow;width:120;">Query<br><input type="checkbox" name="access_scanner_2" value="1"></td>
							<td align="center" style="color:yellow;width:120;">Edit<br><input type="checkbox" name="access_scanner_3" value="1"></td>
							<td align="center" style="color:yellow;width:120;">Export<br><input type="checkbox" name="access_scanner_4" value="1"></td>
							<td align="center" style="color:yellow;width:120;"></td>
						</tr>
						<tr>
							<td align="left" style="color:white;">Faction Profiles</td>
							<td align="center" style="color:yellow;width:120;">Add<br><input type="checkbox" name="access_factions_1" value="1"></td>
							<td align="center" style="color:yellow;width:120;">Query<br><input type="checkbox" name="access_factions_2" value="1"></td>
							<td align="center" style="color:yellow;width:120;">Edit<br><input type="checkbox" name="access_factions_3" value="1"></td>
							<td align="center" style="color:yellow;width:120;">Export<br><input type="checkbox" name="access_factions_4" value="1"></td>
							<td align="center" style="color:yellow;width:120;"></td>
						</tr>
						<tr>
							<td align="left" style="color:white;">Sentient Profiles</td>
							<td align="center" style="color:yellow;width:120;">Add<br><input type="checkbox" name="access_sentients_1" value="1"></td>
							<td align="center" style="color:yellow;width:120;">Query<br><input type="checkbox" name="access_sentients_2" value="1"></td>
							<td align="center" style="color:yellow;width:120;">Edit<br><input type="checkbox" name="access_sentients_3" value="1"></td>
							<td align="center" style="color:yellow;width:120;">Export<br><input type="checkbox" name="access_sentients_4" value="1"></td>
							<td align="center" style="color:yellow;width:120;"></td>
						</tr>
					</table>
					<br /><br />
					<input class="button" type="submit" name="add_submit" value="Submit">
					</form>
					</center>
				</div>
			</div>
			<!-- Right content Ends here-->
		</div>
		
		<!-- Content Ends here and footer started-->
  
		<div class="footclear">&nbsp;</div>
		<?php echo $page_load_footer; ?>
		<!-- footer Ends here-->
	</div>
	<!-- Container Ends here-->
</body>

</html>

<?php mysqli_close($con); ?>
