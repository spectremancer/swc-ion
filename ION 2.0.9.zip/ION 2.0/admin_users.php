<?php
	session_start();
	require('connect.php');	
	require('session_load.php');
	require('page_load.php');
	$notice = "";
	if($member_admin != 1 && $member_super_admin != 1){
		header('Location: index.php');
	}
	//Check if account is enabled/disabled
	if($member_id != "" && $query_member['status'] == 0){
		header('Location: index.php?action=Logout&code=1');
	}
		
	
	if($_GET['lock']){
		$query_super_admin = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM site_settings"));
		$query_super_admin = $query_super_admin['super_admin'];
		if($_GET['lock'] == $query_super_admin){
			header('Location: admin_users.php?errCode=3');
			break;
		}
		
		$lock_id = mysqli_real_escape_string($con,$_GET['lock']);
		$lock_handle = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM members WHERE id='$lock_id'"));
		$lock_handle = $lock_handle['handle'];
		mysqli_query($con,"UPDATE members SET status='0' WHERE id='$lock_id'");
		$notice = "<div class='warning'>The account <font color='blue'>".$lock_handle."</font> has been disabled.</div>";
	}else if($_GET['unlock']){
		$unlock_id = mysqli_real_escape_string($con,$_GET['unlock']);
		$unlock_handle = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM members WHERE id='$unlock_id'"));
		$unlock_handle = $unlock_handle['handle'];
		mysqli_query($con,"UPDATE members SET status='1' WHERE id='$unlock_id'");
		$notice = "<div class='warning'>The account <font color='blue'>".$unlock_handle."</font> has been enabled.</div>";
	}
	
	switch ($_GET['errCode']) {
		case 1:
			$notice = "<div class='confirm'>The user has been deleted.</div>";
			break;
		case 2:
			$notice = "<div class='error'>You cannot edit the Super Admin account.</div>";
			break;
		case 3:
			$notice = "<div class='error'>You cannot lock the Super Admin account.</div>";
			break;
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php require('head.php'); ?>
<?php require('main.css.php'); ?>
</head>

<body>
	<div id="container">
	<!-- Header Start-->
		<?php echo $page_load_header; ?>
		<!-- Header End and Menu Start-->  
		<div id="menu">
			<ul>
				<?php 
					echo $public_links;
					echo $member_links;
					echo $admin_link; 
				?> 
			</ul>
			<?php echo $searchbar; ?>
		<!-- Menu End and Content Start-->
		</div>
		<div id="content">
		<!-- Left content Start-->
			<div id="leftcontent">
			<!-- Navigation Start-->
				<div class="navigation">
					<div class="navhead">Member's Area</div>
					<?php echo $user_panel; ?>
				</div>
				
				<!-- Dynamically Generated Panels-->
				<?php echo $page_load_side_panels; ?>
			</div>
			
			<!-- Left content ends and right content starts-->
			
			<div id="rightcontent">
				<div id="breadcrumbs"> <a href="admin.php">Admin</a> -> <a href="admin_users.php">User Admin</a></div>
				<!-- Post starts here-->
				<center><h1>User Administration</h1></center>
				<?php echo $notice; ?>
				<div class="postcontent">
					<center>
					<table>
						<tr>
							<td align="center"><a href="admin_users_add.php">[Add User]</a></td>
						</tr>
					</table>
					<form class="foorm" method="get" action="admin_users.php">
						<table>
							<tr>
								<td align="left">Search Users:</td>
								<td align="center"><input type="text" name="search_user" value="<?php if($_GET['search_user']){echo $_GET['search_user'];}?>"></td>
								<td align="center"><input type="submit" class="button" name="search_submit" value="Search"></td>
							</tr>
						</table>
					</form>
					<hr />
					<br /><br />
					<?php 
						if($_GET['search_user'] != ""){
							$search_user = mysqli_real_escape_string($con,$_GET['search_user']);
							$query_final = "SELECT * FROM members WHERE (handle LIKE '%$search_user%') OR (email LIKE '%$search_user%') ORDER BY handle ASC";
						}else{
							$search_user = "";
							$query_final = "SELECT * FROM members ORDER BY handle ASC";
						}
						if(mysqli_num_rows(mysqli_query($con,$query_final)) != 0){
							
							if(isset($_GET['page'])){
								$page = mysqli_real_escape_string($con,$_GET['page']);
							}else{
								$page = 1;
							}
							$current_page = intval($page);
							
							//GENERATE PAGINATION DATA
							$query_number = mysqli_num_rows(mysqli_query($con,$query_final));
							$per_page = 25;
							$pages = ceil($query_number/$per_page);
							if($page > $pages){$current_page = $pages;}elseif($page < 1){$current_page = 1;}
							$start = abs(($current_page-1)*$per_page);

							$query_string = "".$query_final." LIMIT ".$start.",".$per_page."";
							$query_results = mysqli_query($con,$query_string);
							
							//PAGINATION TOP
							if($query_number > $per_page){
								echo "
									<div style='width:600px;'>
									<table border='1' cellspacing='0' cellpadding='5' style='background-color:#555555;color:white;'>
										<tr>
											<td align='center' width='100' height='25' style='border:1px solid black;'>
								";
								if($current_page > 1){
									$page_subtract = $current_page - 1;
									echo "<a href='admin_users.php?page=".$page_subtract."&search_users=".$search_users."' style='color:#9999ff;'>Back</a>";
								}
								echo "
									</td>
									<td align='center' width='400' height='25' style='border:1px solid black;'>
								";
								
								if($pages <= 20){
									$current_page_count = 1;
									while($current_page_count <= $pages){
										if($current_page_count == $current_page){
											echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
										}else{
											echo "<span style='margin-right:5px;'><a href='admin_users.php?page=".$current_page_count."&search_users=".$search_users."' style='color:#9999ff;'>".$current_page_count."</a></span>";
										}
										$current_page_count++;
									}
									echo "
										</td>
										<td align='center' width='100' height='25' style='border:1px solid black;'>
									";
									if($current_page < ($current_page_count - 1)){
										$page_add = $current_page + 1;
										echo "<a href='admin_users.php?page=".$page_add."&search_users=".$search_users."' style='color:#9999ff;'>Next</a>";
									}
									echo "
										</td>
										</tr>
										</table></div><br><br>
									";
								}else{
									if($current_page >= 9){
										$count_initial = 1;
										while($count_initial <= 3){
											echo "<span style='margin-right:5px;'><a href='admin_users.php?page=".$current_initial."&search_users=".$search_users."' style='color:#9999ff;'>".$count_initial."</a></span>";
											$count_initial++;
										}
										echo "... ";
									}
									if($current_page == 7){$modifier = 6;}elseif($current_page == 8){$modifier = 7;}else{$modifier = 5;}
									if($current_page > 6){$current_page_count = $current_page - $modifier;}else{$current_page_count = 1;}
									if($current_page >= 1 && $current_page <= 9){
										while($current_page_count <= 15){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='admin_users.php?page=".$current_page_count."&search_users=".$search_users."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}elseif($current_page >= $pages - 7){
										$current_page_count = $pages - 12;
										while($current_page_count <= $pages){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='admin_users.php?page=".$current_page_count."&search_users=".$search_users."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}else{
										while($current_page_count <= ($current_page + 5)){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='admin_users.php?page=".$current_page_count."&search_users=".$search_users."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}
									if($current_page < ($pages - 7)){
										echo " ...";
										$count_final = $pages - 2;
										while($count_final <= $pages){
											echo "<span style='margin-right:5px;'><a href='admin_users.php?page=".$count_final."&search_users=".$search_users."' style='color:#9999ff;'>".$count_final."</a></span>";
											$count_final++;
										}
									}
									echo "
										</td>
										<td align='center' width='100' height='25' style='border:1px solid black;'>
									";
									if($current_page < ($current_page_count - 1)){
										$page_add = $current_page + 1;
										echo "<a href='admin_users.php?page=".$page_add."&search_users=".$search_users."' style='color:#9999ff;'>Next</a>";
									}
									echo "
										</td>
										</tr>
										</table></div><br><br>
									";
								}
							}
							
							//OUTPUT DATA							
							echo "
								<table border='1' class='format_1'>
									<tbody>
									<tr>
										<th width='100'>Username</th>
										<th width='100'>Usergroup</th>
										<th width='125'>Email</th>
										<th width='90'>Login IP</th>
										<th width='90'>Login Date</th>
										<th width='60'>Status</th>
										<th>Action</th>
									</tr>
							";
							$row_color = "rowdark";
							while($row = mysqli_fetch_assoc($query_results)){
								$temp_id_usergroup = $row['id_usergroup'];
								$query_target_usergroup = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM members_usergroups WHERE id='$temp_id_usergroup'"));
								if($row['status'] == 1){
									$status_color = "green";
									$status = "Enabled";
								}else{
									$status_color = "red";
									$status = "Disabled";
								}
								if($row['status'] == 1){
									$lock = "<a href='admin_users.php?lock=".$row['id']."'>[Lock]</a>";
								}else{
									$lock = "<a href='admin_users.php?unlock=".$row['id']."'>[Unlock]</a>";
								}
								echo "
									<tr class=".$row_color.">
										<td align='left'>".$row['handle']."</td>
										<td align='center'><a href='admin_usergroups_edit.php?edit_id=".$query_target_usergroup['id']."'>".$query_target_usergroup['name']."</a></td>
										<td align='left'>".$row['email']."</td>
										<td align='center'>".$row['last_login_ip']."</td>
										<td align='center'>".$row['date_login']." ".$row['time_login']."</td>
										<td align='center'><font color='".$status_color."'>".$status."</font></td>
										<td align='center'><a href='admin_users_edit.php?id=".$row['id']."'>[Edit]</a><br />".$lock."</td>
									</tr>
								";
								if($row_color == "rowdark"){
									$row_color = "rowlight";
								}else{
									$row_color = "rowdark";
								}
							}
							echo "
									</tbody>
								</table>
							";
							
							//PAGINATION BOTTOM
							if($query_number > $per_page){
								echo "
									<br><br>
									<div style='width:600px;'>
									<table border='1' cellspacing='0' cellpadding='5' style='background-color:#555555;color:white;'>
										<tr>
											<td align='center' width='100' height='25' style='border:1px solid black;'>
								";
								if($current_page > 1){
									$page_subtract = $current_page - 1;
									echo "<a href='admin_users.php?page=".$page_subtract."&search_users=".$search_users."' style='color:#9999ff;'>Back</a>";
								}
								echo "
									</td>
									<td align='center' width='400' height='25' style='border:1px solid black;'>
								";
								
								if($pages <= 20){
									$current_page_count = 1;
									while($current_page_count <= $pages){
										if($current_page_count == $current_page){
											echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
										}else{
											echo "<span style='margin-right:5px;'><a href='admin_users.php?page=".$current_page_count."&search_users=".$search_users."' style='color:#9999ff;'>".$current_page_count."</a></span>";
										}
										$current_page_count++;
									}
									echo "
										</td>
										<td align='center' width='100' height='25' style='border:1px solid black;'>
									";
									if($current_page < ($current_page_count - 1)){
										$page_add = $current_page + 1;
										echo "<a href='admin_users.php?page=".$page_add."&search_users=".$search_users."' style='color:#9999ff;'>Next</a>";
									}
									echo "
										</td>
										</tr>
										</table></div><br><br>
									";
								}else{
									if($current_page >= 9){
										$count_initial = 1;
										while($count_initial <= 3){
											echo "<span style='margin-right:5px;'><a href='admin_users.php?page=".$current_initial."&search_users=".$search_users."' style='color:#9999ff;'>".$count_initial."</a></span>";
											$count_initial++;
										}
										echo "... ";
									}
									if($current_page == 7){$modifier = 6;}elseif($current_page == 8){$modifier = 7;}else{$modifier = 5;}
									if($current_page > 6){$current_page_count = $current_page - $modifier;}else{$current_page_count = 1;}
									if($current_page >= 1 && $current_page <= 9){
										while($current_page_count <= 15){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='admin_users.php?page=".$current_page_count."&search_users=".$search_users."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}elseif($current_page >= $pages - 7){
										$current_page_count = $pages - 12;
										while($current_page_count <= $pages){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='admin_users.php?page=".$current_page_count."&search_users=".$search_users."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}else{
										while($current_page_count <= ($current_page + 5)){
											if($current_page_count == $current_page){
												echo "<span style='margin-right:5px;'><b>".$current_page_count."</b></span>";
											}else{
												echo "<span style='margin-right:5px;'><a href='admin_users.php?page=".$current_page_count."&search_users=".$search_users."' style='color:#9999ff;'>".$current_page_count."</a></span>";
											}
											$current_page_count++;
										}
									}
									if($current_page < ($pages - 7)){
										echo " ...";
										$count_final = $pages - 2;
										while($count_final <= $pages){
											echo "<span style='margin-right:5px;'><a href='admin_users.php?page=".$count_final."&search_users=".$search_users."' style='color:#9999ff;'>".$count_final."</a></span>";
											$count_final++;
										}
									}
									echo "
										</td>
										<td align='center' width='100' height='25' style='border:1px solid black;'>
									";
									if($current_page < ($current_page_count - 1)){
										$page_add = $current_page + 1;
										echo "<a href='admin_users.php?page=".$page_add."&search_users=".$search_users."' style='color:#9999ff;'>Next</a>";
									}
									echo "
										</td>
										</tr>
										</table></div><br><br>
									";
								}
							}
						}else{
							echo "There are no users to display.";
						}
					?>
					</center>
				</div>
			</div>
			<!-- Right content Ends here-->
		</div>
		
		<!-- Content Ends here and footer started-->
  
		<div class="footclear">&nbsp;</div>
		<?php echo $page_load_footer; ?>
		<!-- footer Ends here-->
	</div>
	<!-- Container Ends here-->
</body>

</html>

<?php mysqli_close($con); ?>
