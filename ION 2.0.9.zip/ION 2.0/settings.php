<?php
	session_start();
	require('connect.php');	
	require('session_load.php');
	require('page_load.php');
	$notice = "";
	
	if($member_id == "" || $member_handle == ""){
		header('Location: index.php');
	}
	
	//Check if account is enabled/disabled
	if($member_id != "" && $query_member['status'] == 0){
		header('Location: index.php?action=Logout&code=1');
	}
	
	if($_POST['update_submit']){
		$new_email = mysqli_real_escape_string($con,$_POST['update_email']);
		$new_password = mysqli_real_escape_string($con,$_POST['update_password']);
		$new_password_repeat = mysqli_real_escape_string($con,$_POST['update_password_repeat']);
		$old_password = mysqli_real_escape_string($con,$_POST['old_password']);
		if (!filter_var($new_email, FILTER_VALIDATE_EMAIL) === false) {
			if(strlen($new_password) >= 8){
				if($new_password == $new_password_repeat){
					$new_password_hash = md5(md5("xjke5p".$new_password."jruc3e"));
					$old_password_hash = md5(md5("xjke5p".$old_password."jruc3e"));
					$query_password = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM members WHERE id='$member_id'"));
					$password_real = $query_password['password'];
					if($old_password_hash == $password_real){
						mysqli_query($con,"UPDATE members SET password='$new_password_hash', email='$new_email' WHERE id='$member_id'");
						$notice = "<div class='confirm'>Account has been updated!</div>";
					}else{
						$notice = "<div class='error'>Old password is incorrect!</div>";
					}
				}else{
					$notice = "<div class='error'>New password and confirm password did not match!</div>";
				}
			}else if(strlen($new_password) >= 1 && strlen($new_password) <= 7){
				$notice = "<div class='error'>New password must be at least 8 characters long!</div>";
			}else if($new_password == ""){
				$old_password_hash = md5(md5("xjke5p".$old_password."jruc3e"));
				$query_password = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM members WHERE id='$member_id'"));
				$password_real = $query_password['password'];
				if($old_password_hash == $password_real){
					mysqli_query($con,"UPDATE members SET email='$new_email' WHERE id='$member_id'");
					$notice = "<div class='confirm'>Account has been updated!</div>";
				}else{
					$notice = "<div class='error'>Old password is incorrect!</div>";
				}
			}
		} else {
			$notice = "<div class='error'>Email entered is not a valid email address format!</div>";
		}
		
	}
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php require('head.php'); ?>
<?php require('main.css.php'); ?>
</head>

<body>
	<div id="container">
	<!-- Header Start-->
		<?php echo $page_load_header; ?>
		<!-- Header End and Menu Start-->  
		<div id="menu">
			<ul>
				<?php 
					echo $public_links;
					echo $member_links;
					echo $admin_link; 
				?> 
			</ul>
			<?php echo $searchbar; ?>
		<!-- Menu End and Content Start-->
		</div>
		<div id="content">
		<!-- Left content Start-->
			<div id="leftcontent">
			<!-- Navigation Start-->
				<div class="navigation">
					<div class="navhead">Member's Area</div>
					<?php echo $user_panel; ?>
				</div>
				
				<!-- Dynamically Generated Panels-->
				<?php echo $page_load_side_panels; ?>
			</div>
			
			<!-- Left content ends and right content starts-->
			
			<div id="rightcontent">
				<div id="breadcrumbs"> <a href="">Settings</a></div>
				<!-- Post starts here-->
				<center><h1>Settings</h1></center>
				<?php echo $notice; ?>
				<div class="postcontent">
					<center>
					<h2>Account Details</h2>

						<form class="foorm" method="post" action="">
							<table border="1" cellspacing="4" style="color:white;font-size:16px;">
								<tr>
									<td align="left">Username:</td>
									<td align="left"><i><?php echo $member_handle; ?></i></td>
								</tr>
								<tr>
									<td align="left">Email:</td>
									<td align="left"><input type="text" name="update_email" value="<?php echo $member_email; ?>"></td>
								</tr>
								<tr>
									<td align="left">New Password:</td>
									<td align="left"><input type="password" name="update_password" value=""></td>
								</tr>
								<tr>
									<td align="left">Confirm Password:</td>
									<td align="left"><input type="password" name="update_password_repeat" value=""></td>
								</tr>
								<tr>
									<td align="center" colspan="2"><hr /></td>
								</tr>
								<tr>
									<td align="left">Old Password:</td>
									<td align="left"><input type="password" name="old_password" value=""></td>
								</tr>
								<tr>
									<td align="center" colspan="2"><hr /><input type="submit" class="button" name="update_submit" value="Submit"></td>
								</tr>
							</table>
						</form>
					</center>
				</div>
			</div>
			<!-- Right content Ends here-->
		</div>
		
		<!-- Content Ends here and footer started-->
  
		<div class="footclear">&nbsp;</div>
		<?php echo $page_load_footer; ?>
		<!-- footer Ends here-->
	</div>
	<!-- Container Ends here-->
</body>

</html>

<?php mysqli_close($con); ?>
