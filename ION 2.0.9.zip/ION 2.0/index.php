<?php
	session_start();
	require('connect.php');
	$ip = $_SERVER['REMOTE_ADDR'];
	
	//Load SWC Date
	$html = file_get_contents('http://www.swcombine.com/rules/cgt.php?size=12');

	$pattern = '/var clockYear  \= ([0-9]{2});/';
	preg_match_all($pattern, $html, $year);

	$pattern = '/var clockDay   \= ([0-9]{1,3});/';
	preg_match_all($pattern, $html, $day);

	$pattern = '/var clockHour  \= ([0-9]{1,2});/';
	preg_match_all($pattern, $html, $hour);

	$pattern = '/var clockMinute \= ([0-9]{1,2});/';
	preg_match_all($pattern, $html, $minute);

	$pattern = '/var clockSecond \= ([0-9]{1,2});/';
	preg_match_all($pattern, $html, $second);

	$swc_year = $year[1][0];
	$swc_day = str_pad($day[1][0],3,'0',STR_PAD_LEFT);
	$swc_hour = str_pad($hour[1][0],2,'0',STR_PAD_LEFT);
	$swc_minute = str_pad($minute[1][0],2,'0',STR_PAD_LEFT);
	$swc_second = str_pad($second[1][0],2,'0',STR_PAD_LEFT);
	$swc_date_time = "Y".$swc_year." D".$swc_day." ".$swc_hour.":".$swc_minute."";

	if(isset($_POST['submit']) && !empty($_POST['submit'])){
		$username = mysqli_real_escape_string($con,$_POST['input_username']);
		$password = mysqli_real_escape_string($con,$_POST['input_password']);
		$swc_date = "Y".$swc_year." D".$swc_day."";
		$swc_time = "".$swc_hour.":".$swc_minute."";
		if($username && $password){
			$query = mysqli_query($con,"SELECT * FROM members WHERE handle='$username'");
			$query = mysqli_fetch_assoc($query);
			$id = $query['id'];
			$usergroup_id = $query['id_usergroup'];
			
			//Check if account is enabled/disabled
			if($query['status'] == 0){
				header('Location: index.php?action=Logout&code=1');
			}
			//Check if site is locked
			$query_lock = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM site_settings WHERE id=1"));
			$check_lock = $query_lock['lockdown'];
			$check_super_admin = $query_lock['super_admin'];

			if($query_lock == 1){
				$query_usergroup = mysqli_fetch_assoc(mysqli_query($con,"SELECT * FROM members_usergroups WHERE id='$usergroup_id'"));
				if($query_usergroup['admin'] != 1 && ($check_super_admin != $id)){
					header('Location: index.php?action=Logout&code=2');
				}
			}
	
			$handle = $query['handle'];
			$password_real = $query['password'];
			$password_input = md5(md5("xjke5p".$password."jruc3e"));
			if($password_input == $password_real){
				mysqli_query($con,"UPDATE members SET last_login_ip='$ip', date_login='$swc_date', time_login='$swc_time' WHERE id='$id'");
				$_SESSION['id'] = $id;
				$_SESSION['handle'] = $handle;
				$notification = "The user <font color='blue'>".$handle."</font> has logged in from <font color='blue'>".$ip."</font>";
				$marker = time();
				$notification = mysqli_real_escape_string($con,$notification);
				mysqli_query($con,"INSERT INTO notifications_admin VALUES ('','$notification','0','$swc_date_time','$marker')");
				$notice = "<div class='confirm'>You have logged in as ".$handle."</div>";
			}else{
				$notice = "<div class='error'>Incorrect username/password.</div>";
			}
		}else{
			$notice = "<div class='error'>Incorrect username/password.</div>";
		}
	}else{
		$notice = "";
	}
	
	if($_GET['action'] == "Logout"){
		$_SESSION = array();
		// If it's desired to kill the session, also delete the session cookie.
		// Note: This will destroy the session, and not just the session data!
		if (ini_get("session.use_cookies")) {
			$params = session_get_cookie_params();
			setcookie(session_name(), '', time() - 42000,
				$params["path"], $params["domain"],
				$params["secure"], $params["httponly"]
			);
		}
		// Finally, destroy the session.
		session_destroy();
		if($_GET['code']){
			if($_GET['code'] == 0){
				$notice = "<div class='confirm'>You have logged out.</div>";
			}else if($_GET['code'] == 1){
				$notice = "<div class='warning'>Your account is disabled.</div>";
			}else if($_GET['code'] == 2){
				$notice = "<div class='warning'>The system is under lockdown. Admin action is required.</div>";
			}
		}
	}
	
	require('session_load.php');
	require('page_load.php');
?>

<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">

<head>
<?php require('head.php'); ?>
<?php require('main.css.php'); ?>
</head>

<body>
	<div id="container">
	<!-- Header Start-->
		<?php echo $page_load_header; ?>
		<!-- Header End and Menu Start-->  
		<div id="menu">
			<ul>
				<?php 
					echo $public_links;
					echo $member_links;
					echo $admin_link; 
				?> 
			</ul>
			<?php echo $searchbar; ?>
		<!-- Menu End and Content Start-->
		</div>
		<div id="content">
		<!-- Left content Start-->
			<div id="leftcontent">
			<!-- Navigation Start-->
				<div class="navigation">
					<div class="navhead">Member's Area</div>
					<?php echo $user_panel; ?>
				</div>
				
				<!-- Dynamically Generated Panels-->
				<?php echo $page_load_side_panels; ?>
			</div>
			
			<!-- Left content ends and right content starts-->
			
			<div id="rightcontent">
				<div id="breadcrumbs"> <a href="">Index</a></div>
				<!-- Post starts here-->
				<center><h1>News and Updates</h1></center>
				<?php echo $notice; ?>
				<?php
					$query_articles = mysqli_query($con,"SELECT * FROM site_news ORDER BY id DESC LIMIT 0,5");
					if(mysqli_num_rows($query_articles) != 0){
						while($row = mysqli_fetch_assoc($query_articles)){
							echo '
								<div class="postcontent">
									<h1 class="posthead">'.$row['subject'].'</h1>
									'.$row['content'].'
									<hr>
									<div class="postfooter"> <span class="date">Year '.$row['year'].' Day '.$row['day'].' '.$row['time'].'</span></div>
								</div>
							';
						}
					}else{
						echo '
							<center><div style="border:1px solid #777777;"><font color="red">There are no posts to display.</font></div></center>
						';
					}
				?>
			</div>
			<!-- Right content Ends here-->
		</div>
		
		<!-- Content Ends here and footer started-->
  
		<div class="footclear">&nbsp;</div>
		<?php echo $page_load_footer; ?>
		<!-- footer Ends here-->
	</div>
	<!-- Container Ends here-->
</body>

</html>

<?php mysqli_close($con); ?>
